# Sample integration validation

Validation date: 2026-09-28. This test used nine development PDFs in
`data/sample_pdfs/` and the configuration in `configs/sample.json`.

## Execution and outcomes

- Fresh native-text extraction ran on the development Mac: **41.48 seconds** summed
  per-paper time, including first-paper initialization. All nine papers succeeded.
- Input preparation ran locally using the pinned model tokenizer. Seven papers
  fit in one input; two used 34 and 39 section/block segments respectively.
- The official `python -m batill embed` implementation ran on one 16GB V100 via a
  temporary compute detour (job 4737177). No model inference ran on the Mac.
- Embedding time summed across the nine papers: **72.98 seconds**;
  per-paper range **3.82–12.55 seconds**. These times include
  encoding and per-paper serialization, not initial model loading.
- Total scheduled job elapsed time: **2 minutes 2 seconds**, including loading and
  final validation.
- The exported matrix is **9 × 2560**, finite and L2-normalized. IDs, row order,
  prepared-input checksums, configuration, aggregation and matrix checksum passed
  validation both before and after transfer.
- Results were installed at `outputs/sample/embeddings/`, the same location used
  by a local invocation. Relative file references remained valid after transfer.
- All **13 synthetic tests** passed. They include interrupted inference recovery,
  cache reuse without model loading, corruption detection and numerical attention
  checks. `Pipeline.ipynb` was syntax-validated and remains unexecuted.

## Reproducibility

Model: `Qwen/Qwen3-Embedding-4B`.

Revision: `5cf2132abc99cad020ac570b19d031efec650f2b`.

Prepared corpus ID: `6f1e91999b513d1e96f4b1ce078da2597e8507b9e215db65b3fd1cdf6fa403fb`.

Extraction environment: Marker `2.0.0` on the Mac.

Inference environment:

- PyTorch: `2.7.1+cu126`
- Transformers: `5.16.1`
- Sentence Transformers: `5.7.0`
- Device: CUDA; precision: FP16
- Attention: `batill_sdpa_repeat_kv` with efficient SDPA
- CUDA allocator: expandable segments; generation KV cache disabled

Per-paper execution provenance remains in the output manifest. The test demonstrates
functional extraction, embedding and output portability. It does not establish the
scientific quality of the representation or guarantee that other hardware/backends
can fit the same context length. Extraction omissions, unmarked inline formulas,
section segmentation and thematic validity still require review.

## Multi-GPU preparation (not an inference benchmark)

The independent-worker implementation was tested with 300 synthetic papers for
unique coverage and deterministic partitioning, plus concurrent fake-model workers,
ordered merging, incomplete/corrupt result rejection, empty workers and cached restarts.
Lightweight Python subprocesses tested isolated device-visibility environments and
termination of peers after failure. These tests used temporary directories that were
removed afterward. No real model was loaded, no GPU job was submitted, and no existing
sample outputs were changed. Four-GPU throughput has not been measured.

## Sample cleanup

On 2026-09-29, sample PDFs, generated results and the sample configuration were
archived outside the repository in `../batill_recovery/` and removed from the
active project. The integration results above are historical validation evidence.
The active notebook now uses `configs/pipeline.json`.
