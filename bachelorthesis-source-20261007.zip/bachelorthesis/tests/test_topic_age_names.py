"""Expression-only labels must follow v2 ranks and attach to exact memberships."""

import numpy as np
import pandas as pd
import pytest

from batill.storage import write_json
from batill.topic_age_names import attach_names, expression_names, workbook_term_settings
from batill.topic_analysis import build_vocabulary, topic_terms
from batill.topic_explorer import ranked_terms


@pytest.fixture
def data():
    health = ('hospital care. patient safety. clinical trials. medical treatment. '
              'primary care. health insurance. nursing homes. healthcare spending. specialist services.')
    finance = ('fund returns. equity funds. capital markets. investment returns. '
               'financial performance. corporate governance. portfolio companies. asset management. buyout funds.')
    papers = pd.DataFrame({'paper_id': list('abcdef'), 'text': [health] * 3 + [finance] * 3})
    labels = np.array([0, 0, 0, 1, 1, 1])
    settings = {'ranking': 'tfidf_contrast', 'min_df': 3, 'max_df': .9,
                'min_cluster_papers': 2, 'min_cluster_fraction': 0.0}
    return papers, labels, settings


def test_labels_use_exact_top_eight_expressions_not_top_eight_mixed_terms(data):
    papers, labels, settings = data
    names, evidence = expression_names(papers, labels, analysis='abstracts',
                                       solution='example', settings=settings)
    vocabulary = build_vocabulary(papers, min_df=3, max_df=.9)
    terms = topic_terms(vocabulary, labels, top_n=len(vocabulary['terms']), min_cluster_fraction=0.0)
    for row in names.itertuples():
        expected = ranked_terms({'labels': labels, 'terms': terms}, row.cluster,
                                 'tfidf_contrast', 'expression', 8).term.tolist()
        assert row.topic_name == ' · '.join(expected)
        assert row.phrase_count == 8
        assert all(len(term.split()) == 2 for term in expected)
    assert len(evidence) == 16
    assert evidence.score.gt(0).all()


def test_names_cannot_be_attached_to_different_memberships(data):
    papers, labels, settings = data
    names, _ = expression_names(papers, labels, analysis='abstracts', solution='example', settings=settings)
    members = pd.DataFrame({'analysis': 'abstracts', 'solution': 'example', 'cluster': labels,
                            'stable_id': papers.paper_id, 'assigned': True,
                            'topic_name': 'old', 'display_cluster': 'old'})
    attached = attach_names(members, names)
    np.testing.assert_array_equal(attached.cluster, labels)
    assert attached.loc[attached.cluster.eq(0), 'topic_name'].nunique() == 1
    members.loc[0, 'stable_id'] = 'different paper'
    with pytest.raises(ValueError, match='exact age-analysis memberships'):
        attach_names(members, names)


def test_settings_read_from_v2_cells_without_executing_them(tmp_path):
    path = tmp_path / 'workbook.ipynb'
    write_json(path, {'cells': [{'cell_type': 'code', 'source': [
        "RANKING = 'c_tf_idf'\nMIN_CLUSTER_PAPERS = 4\nMIN_CLUSTER_FRACTION = 0.02\n",
        "analysis = analyse_partition(context, labels, min_df=5, max_df=.8, "
        "min_cluster_papers=MIN_CLUSTER_PAPERS, min_cluster_fraction=MIN_CLUSTER_FRACTION)\n",
        "raise AssertionError('Notebook source must not execute')\n"]}]})
    assert workbook_term_settings(path) == {'ranking': 'c_tf_idf', 'min_cluster_papers': 4,
                                           'min_cluster_fraction': .02, 'min_df': 5, 'max_df': .8}
