"""Scope filtering preserves paper identity and never changes stored data."""
import numpy as np
import pandas as pd
import pytest

from batill.selection import filter_analysis_corpus
from batill.storage import write_json


def test_hash_filter_preserves_order_paper_ids_and_vectors(tmp_path):
    papers = pd.DataFrame({'Key': ['a' * 64, 'b' * 64, 'c' * 64],
                           'Paper ID': ['P001', 'P002', 'P003'], 'Title': ['Same title'] * 3})
    vectors = np.arange(9).reshape(3, 3)
    path = tmp_path / 'exclusions.json'
    write_json(path, {'schema_version': 1, 'papers': [
        {'pdf_sha256': 'b' * 64, 'exclude': True, 'reason': 'scope'},
        {'pdf_sha256': 'c' * 64, 'exclude': False, 'reason': 'kept after review'},
        {'pdf_sha256': 'd' * 64, 'exclude': True, 'reason': 'absent in this corpus'},
    ]})
    selected, result, audit, summary = filter_analysis_corpus(papers, vectors, path)
    assert selected['Paper ID'].tolist() == ['P001', 'P003']
    assert selected.index.tolist() == [0, 1]
    np.testing.assert_array_equal(result, vectors[[0, 2]])
    assert summary['unmatched_exclusions'] == ['d' * 64]
    assert summary['excluded_papers'] == 1 and summary['retained_papers'] == 2
    assert audit.status.tolist() == ['excluded', 'kept_by_decision', 'not_in_loaded_corpus']
    selected.loc[0, 'Title'] = 'Changed'
    result[0, 0] = -1
    assert papers.loc[0, 'Title'] == 'Same title' and vectors[0, 0] == 0


def test_invalid_or_ambiguous_filter_inputs_rejected(tmp_path):
    papers = pd.DataFrame({'Key': ['a' * 64, 'b' * 64]})
    entry = {'pdf_sha256': 'a' * 64, 'exclude': True, 'reason': 'scope'}
    path = tmp_path / 'exclusions.json'
    write_json(path, {'schema_version': 1, 'papers': [entry, entry]})
    with pytest.raises(ValueError, match='Duplicate'):
        filter_analysis_corpus(papers, np.ones((2, 3)), path)
    with pytest.raises(ValueError, match='aligned'):
        filter_analysis_corpus(papers, np.ones((3, 3)), path)
    write_json(path, {'schema_version': 1, 'papers': [{**entry, 'exclude': 'yes'}]})
    with pytest.raises(ValueError, match='boolean'):
        filter_analysis_corpus(papers, np.ones((2, 3)), path)


def test_duplicate_filter_preserves_canonical_vectors_and_scope(tmp_path):
    from batill.selection import deduplicate_pdf_corpus
    from batill.storage import write_json, fingerprint
    papers = pd.DataFrame({'Key': ['a', 'b', 'c', 'd'],
                           'Paper ID': ['P001', 'P002', 'P003', 'P004']})
    vectors = np.eye(4)
    config = {'schema_version': 1, 'duplicate_pdfs': [
        {'duplicate_key': 'b', 'canonical_key': 'a'},
        {'duplicate_key': 'c', 'canonical_key': 'd'}]}
    write_json(tmp_path / 'pdf_duplicates.json', config)
    selected, x, info = deduplicate_pdf_corpus(
        papers, vectors, tmp_path / 'scope.json', {'selection_id': 'scope'})
    assert selected['Paper ID'].tolist() == ['P001', 'P004']
    np.testing.assert_array_equal(x, vectors[[0, 3]])
    assert info['scope_selection_id'] == 'scope'
    assert info['selection_id'] == fingerprint(['a', 'd'])
    assert info['duplicate_pdfs_removed'] == 2
    with pytest.raises(ValueError, match='canonical PDF is absent'):
        deduplicate_pdf_corpus(papers.iloc[1:], vectors[1:], tmp_path / 'scope.json',
                              {'selection_id': 'scope'})
