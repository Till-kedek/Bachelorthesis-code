"""Synthetic graph construction and optional real Leiden integration checks."""
import numpy as np
import pytest

from batill.graph_clustering import similarity_graph, leiden_partition, leiden_sweep, leiden_tables


def test_union_mutual_weights_and_isolates():
    x = np.array([[1., 0.], [.99, .1], [.7, .7], [-1., 0.]])
    original = x.copy()
    union = similarity_graph(x, neighbours=1)
    mutual = similarity_graph(x, neighbours=1, mutual=True)
    np.testing.assert_array_equal(x, original)
    assert union['edges'].tolist() == [[0, 1], [1, 2]]
    assert mutual['edges'].tolist() == [[0, 1]]
    for (a, b), w in zip(union['edges'], union['weights']):
        assert a != b and w > 0
        assert w == pytest.approx(np.dot(x[a], x[b]) / np.linalg.norm(x[a]) / np.linalg.norm(x[b]))
    assert union['diagnostics']['isolated_papers'] == 1
    assert union['diagnostics']['components'] == 2
    assert len(union['components']) == len(x)
    assert similarity_graph(x, neighbours=100)['neighbours'] == 3


def test_graph_rejects_bad_inputs_and_applies_threshold():
    with pytest.raises(ValueError):
        similarity_graph(np.zeros((3, 2)))
    with pytest.raises(ValueError):
        similarity_graph(np.eye(3), neighbours=0)
    with pytest.raises(ValueError):
        similarity_graph(np.eye(3), min_similarity=-.1)
    g = similarity_graph([[1, 0], [0, 1]], neighbours=1)
    assert len(g['edges']) == 0 and g['diagnostics']['isolated_papers'] == 2


def test_real_leiden_partition_sweep_and_tables():
    pytest.importorskip('igraph')
    pytest.importorskip('leidenalg')
    import pandas as pd
    x = np.array([[1., 0.], [1., .02], [1., .04], [0., 1.], [.02, 1.], [.04, 1.]])
    graph = similarity_graph(x, neighbours=2, min_similarity=.9)
    result = leiden_partition(graph, resolution=1., seed=42)
    np.testing.assert_array_equal(result['labels'], [1, 1, 1, 2, 2, 2])
    np.testing.assert_array_equal(result['labels'], leiden_partition(graph, seed=42)['labels'])
    diagnostics, results = leiden_sweep(graph, [.5, 1.], seeds=[42, 43])
    assert diagnostics['within_target'].all()
    assert (diagnostics['singletons'] == 0).all()
    assert (diagnostics['seed_stability_ARI'] == 1).all()
    papers = pd.DataFrame({'Paper ID': [f'P{i}' for i in range(6)], 'Key': range(6),
        'Title': [f'Title {i}' for i in range(6)], 'source_filename': ['a.pdf'] * 6, 'segments': [2] * 6})
    summary, members = leiden_tables(graph, results[1.], papers, representatives=1)
    assert summary['Cluster'].tolist() == ['L1', 'L2']
    assert summary['Papers'].tolist() == [3, 3]
    assert members['Key'].tolist() == list(range(6))
    assert summary.iloc[0]['Representative papers'].startswith('P1:')
    with pytest.raises(ValueError, match='no positive edges'):
        leiden_partition(similarity_graph(np.eye(3)))


def test_arange_sweep_supports_decimal_lookup_and_preserves_fit():
    pytest.importorskip('leidenalg')
    graph = similarity_graph([[1., 0.], [1., .02], [1., .04],
                              [0., 1.], [.02, 1.], [.04, 1.]], neighbours=2)
    diagnostics, results = leiden_sweep(graph, list(np.arange(.1, 1., .05)), seeds=[42, 43])
    assert len(results) == 18 and 1.0 not in results
    for resolution in [.15, .5, .95]:
        fit = results[resolution]
        assert fit['resolution'] == resolution
        direct = leiden_partition(graph, resolution, fit['seed'])
        np.testing.assert_array_equal(fit['labels'], direct['labels'])
    assert diagnostics.resolution.tolist() == list(results)


@pytest.mark.parametrize('resolutions', [[], [0], [float('nan')], [float('inf')], [.15, .15000000000000002]])
def test_sweep_rejects_invalid_or_equivalent_resolutions(resolutions):
    with pytest.raises(ValueError, match='Resolutions must be unique'):
        leiden_sweep({}, resolutions)


@pytest.mark.parametrize('filename,count,stop', [
    ('Clustering PDFs.ipynb', 5, 'PDF_TOPIC_EXPORT ='),
    ('Clustering Abstracts.ipynb', 6, 'ABSTRACT_INPUT_ID ='),
])
def test_notebook_selectors_accept_existing_unrounded_sweep(filename, count, stop):
    """Rerunning a selection cell must work with an older live kernel's keys."""
    import json
    from pathlib import Path
    notebook = json.loads((Path(__file__).resolve().parents[1] / filename).read_text())
    ns = {'np': np, 'leiden_results': {
        r: {'labels': np.arange(count)} for r in np.arange(.1, 1., .05)},
        'kmeans_results': {count: {}}}
    def selection_code(variable, marker):
        return next(''.join(cell['source']).split(marker)[0] for cell in notebook['cells']
                    if cell['cell_type'] == 'code'
                    and any(line.startswith(variable + ' =') for line in cell['source']))

    for marker, variable in [
        ('leiden_selected =', 'LEIDEN_INSPECT_RESOLUTION'),
        ('required_columns =', 'LEIDEN_PLOT_RESOLUTION'),
        (stop, 'TOPIC_LEIDEN_RESOLUTION'),
    ]:
        code = selection_code(variable, marker)
        exec(code, ns)
        assert ns[variable] in ns['leiden_results']
    code = selection_code('LEIDEN_INSPECT_RESOLUTION', 'leiden_selected =')
    ns['SELECTED_LEIDEN_RESOLUTION'] = .95
    exec(code, ns)
    assert np.isclose(ns['LEIDEN_INSPECT_RESOLUTION'], .95, rtol=0, atol=1e-12)
    ns['SELECTED_LEIDEN_RESOLUTION'] = 1.
    with pytest.raises(ValueError, match='Available fitted resolutions'):
        exec(code, ns)


def test_resolution_selection_plot_keeps_corpora_and_metrics_on_correct_axes():
    import pandas as pd
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from batill.graph_clustering import plot_leiden_resolution_selection
    pdfs = pd.DataFrame({'resolution': [1., .9, .95], 'clusters': [5, 5, 5],
        'cosine_silhouette': [.176, .172, .172], 'seed_stability_ARI': [.73, .93, .97]})
    abstracts = pd.DataFrame({'resolution': [.3, .5], 'clusters': [4, 6],
        'cosine_silhouette': [.08, .04], 'seed_stability_ARI': [-.1, .9]})
    fig, axes = plot_leiden_resolution_selection(
        {'PDFs': pdfs, 'Abstracts': abstracts}, {'PDFs': .9500000000000003, 'Abstracts': .5})
    np.testing.assert_array_equal(axes['silhouette'].lines[0].get_ydata(), [.172, .172, .176])
    np.testing.assert_array_equal(axes['stability'].lines[0].get_ydata(), [.93, .97, .73])
    np.testing.assert_array_equal(axes['stability'].lines[1].get_ydata(), [-.1, .9])
    assert axes['stability'].get_ylim()[0] < -.1
    assert any('5 clusters' in text.get_text() and '0.950' not in text.get_text() for text in fig.texts)
    plt.close(fig)
    with pytest.raises(ValueError, match='selected resolution'):
        plot_leiden_resolution_selection({'PDFs': pdfs}, {'PDFs': .85})
