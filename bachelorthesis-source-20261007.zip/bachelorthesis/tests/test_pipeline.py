"""Synthetic tests only: no PDFs, network calls or real models."""

from types import SimpleNamespace

import numpy as np
import pytest

from batill.documents import html_text, normalize_document, embedding_blocks
from batill.embedding import EmbeddingConfig, prepare_inputs, prepare_corpus, embed_corpus
from batill.extraction import discover_pdfs, extract_papers
from batill.storage import read_json


@pytest.fixture(autouse=True)
def synthetic_runtime_versions(monkeypatch):
    # Tests must work without installing torch or either model library.
    monkeypatch.setattr("batill.embedding.version", lambda name: "synthetic-test")


class CharacterTokenizer:
    def encode(self, text, add_special_tokens=True):
        return list(text) + ([1, 2] if add_special_tokens else [])


def raw_document():
    return {"children": [{"id": "/page/0", "children": [
        {"id": "/page/0/Title/0", "block_type": "Title", "html": "<h1>Paper</h1>"},
        {"id": "/page/0/SectionHeader/1", "block_type": "SectionHeader", "html": "<h2>Results</h2>"},
        {"id": "/page/0/Text/2", "block_type": "Text", "html": "<p>Growth <math>x^2</math>.</p>",
         "section_hierarchy": {"1": "/page/0/SectionHeader/1"}},
        {"id": "/page/0/SectionHeader/3", "block_type": "SectionHeader", "html": "<h2>References</h2>"},
        {"id": "/page/0/Text/4", "block_type": "Text", "html": "A citation",
         "section_hierarchy": {"1": "/page/0/SectionHeader/3"}},
        {"id": "/page/0/PageFooter/5", "block_type": "PageFooter", "html": "1"},
    ]}]}


def document():
    return normalize_document(raw_document(), pdf_sha256="sha", source_filename="test.pdf")


def test_math_tables_structure_and_reference_exclusion():
    doc = document()
    assert all(b["page"] == 1 for b in doc["blocks"])
    included = embedding_blocks(doc)
    assert len(included) == 3
    assert included[-1]["section"] == ["Results"]
    assert "$x^2$" in included[-1]["text"]
    assert "$$a=b$$" in html_text('<math display="block">a=b</math>')
    assert html_text('<table><tr><td>A</td><td>B</td></tr></table>') == 'A | B'
    assert doc["blocks"][4]["exclusion_reason"] == "reference_section"


def test_short_paper_single_input_and_oversized_block_lossless():
    tokenizer = CharacterTokenizer()
    config = EmbeddingConfig(max_tokens=256, instruction="Map topics", math_policy="preserve")
    doc = document()
    assert len(prepare_inputs(doc, tokenizer, config)) == 1
    doc["blocks"][2]["text"] = "mathematics α β and economics. " * 100
    segments = prepare_inputs(doc, tokenizer, config)
    assert len(segments) > 1
    assert all(s["token_count"] <= 256 for s in segments)
    for block in embedding_blocks(doc):
        ranges = [source for s in segments for source in s["sources"] if source["block_id"] == block["id"]]
        assert ranges[0]["start"] == 0
        assert ranges[-1]["end"] == len(block["text"])
        assert all(a["end"] == b["start"] for a, b in zip(ranges, ranges[1:]))
        reconstructed = ''.join(block["text"][r["start"]:r["end"]] for r in ranges)
        assert reconstructed == block["text"]


def test_empty_papers_require_explicit_skip_and_are_recorded(tmp_path):
    from batill.embedding import load_plans
    empty = {**document(), 'pdf_sha256': 'empty', 'source_filename': 'empty.pdf', 'blocks': []}
    config = EmbeddingConfig(max_tokens=512)
    args = ([document(), empty], CharacterTokenizer(), config, 'test', tmp_path)
    with pytest.raises(ValueError, match='empty.pdf'):
        prepare_corpus(*args)
    assert not (tmp_path / 'manifest.json').exists()
    with pytest.warns(UserWarning, match='Excluding 1'):
        plans = prepare_corpus(*args, skip_empty=True)
    assert [p['pdf_sha256'] for p in plans] == ['sha']
    assert load_plans(tmp_path) == plans
    report = read_json(tmp_path / 'preparation_report.json')
    assert report['selected_count'] == 2 and report['usable_count'] == 1
    assert report['excluded'][0]['pdf_sha256'] == 'empty'
    assert read_json(tmp_path / 'manifest.json')['excluded'] == report['excluded']


def test_all_empty_and_nonempty_preparation_errors_still_fail(tmp_path):
    config = EmbeddingConfig(max_tokens=512)
    empty = {**document(), 'blocks': []}
    with pytest.warns(UserWarning), pytest.raises(ValueError, match='No usable documents'):
        prepare_corpus([empty], CharacterTokenizer(), config, 'test', tmp_path, skip_empty=True)
    assert not (tmp_path / 'manifest.json').exists()
    broken = {**document(), 'title': 'x' * 1000}
    with pytest.raises(ValueError, match='insufficient space'):
        prepare_corpus([broken], CharacterTokenizer(), config, 'test', tmp_path, skip_empty=True)
    assert not (tmp_path / 'manifest.json').exists()


def test_extraction_deduplicates_caches_and_invalidates_options(tmp_path):
    pdfs = tmp_path / "pdfs"
    pdfs.mkdir()
    (pdfs / "a.pdf").write_bytes(b"synthetic bytes, never parsed as PDF")
    (pdfs / "b.PDF").write_bytes((pdfs / "a.pdf").read_bytes())
    records = discover_pdfs(pdfs)
    assert [r["duplicate"] for r in records] == [False, True]
    calls = []

    def fake_converter(path):
        calls.append(path)
        return SimpleNamespace(model_dump=lambda **_: raw_document())

    destination = tmp_path / "out"
    report = extract_papers(records, destination, converter=fake_converter, extractor_version="test")
    assert report[0]["status"] == "extracted"
    assert report[1]["status"] == "duplicate_skipped"
    again = extract_papers(records, destination, converter=fake_converter, extractor_version="test")
    assert again[0]["status"] == "cached"
    assert len(calls) == 1
    extract_papers(records, destination, config={"mode": "other"}, converter=fake_converter, extractor_version="test")
    assert len(calls) == 2
    (pdfs / "a.pdf").write_bytes(b"changed")
    assert extract_papers(records[:1], destination, converter=fake_converter, extractor_version="test")[0]["status"] == "error"


def test_embeddings_normalized_and_cached(tmp_path):
    config = EmbeddingConfig(max_tokens=256, instruction="Map topics", embedding_dimension=2)
    tokenizer = CharacterTokenizer()
    plans = prepare_corpus([document()], tokenizer, config, "fixed-commit", tmp_path)
    calls = []

    def encode(texts, **kwargs):
        calls.append(texts)
        assert kwargs["prompt"] == ""
        return np.array([[0.6, 0.8] for _ in texts])

    model = SimpleNamespace(tokenizer=tokenizer, max_seq_length=256, encode=encode,
                            _batill_embedding_config=plans[0]['config'])
    destination = embed_corpus(plans, model, tmp_path)
    with np.load(destination / "embeddings.npz", allow_pickle=False) as data:
        np.testing.assert_allclose(np.linalg.norm(data['embeddings'], axis=1), 1)
        assert data['pdf_sha256'].tolist() == ['sha']
    assert read_json(destination / 'manifest.json')['rows'][0]['title'] == 'Paper'
    assert embed_corpus(plans, model, tmp_path) == destination
    assert len(calls) == 1


def test_truncation_and_empty_corpus_rejected(tmp_path):
    config = EmbeddingConfig(max_tokens=256, instruction="Map topics", embedding_dimension=2)
    tokenizer = CharacterTokenizer()
    plans = prepare_corpus([document()], tokenizer, config, "fixed-commit", tmp_path)
    model = SimpleNamespace(tokenizer=tokenizer, max_seq_length=10,
                            _batill_embedding_config=plans[0]['config'])
    with pytest.raises(ValueError, match="truncate"):
        embed_corpus(plans, model, tmp_path)
    with pytest.raises(ValueError, match="No prepared"):
        embed_corpus([], model, tmp_path)
    model._batill_embedding_config = {}
    with pytest.raises(ValueError, match="does not match"):
        embed_corpus(plans, model, tmp_path)


def test_formula_filter_preserves_prose_currency_and_originals(tmp_path):
    doc = document()
    doc['blocks'][2]['html'] = '<p>Returns rose 5%, from $10 to $20, following <math>x^2</math>.</p>'
    doc['blocks'][2]['text'] = html_text(doc['blocks'][2]['html'])
    doc['blocks'].append({'id': 'eq', 'type': 'Equation', 'page': 1, 'section': ['Results'],
                          'text': '$$y=x$$', 'html': '<math>y=x</math>', 'include': True})
    filtered = embedding_blocks(doc, 'omit')
    text = '\n'.join(b['text'] for b in filtered)
    assert '$10' in text and '$20' in text and '5%' in text
    assert '[FORMULA]' in text and 'x^2' not in text and 'y=x' not in text
    assert doc['blocks'][-1]['text'] == '$$y=x$$'
    plans = prepare_corpus([doc], CharacterTokenizer(), EmbeddingConfig(max_tokens=512), 'test', tmp_path)
    readable = tmp_path / 'readable' / 'sha.input-1.txt'
    assert readable.read_text() == plans[0]['segments'][0]['text']
    assert 'bbox' not in readable.read_text()


def test_portable_outputs_validate_and_resume_without_loading_model(tmp_path, monkeypatch):
    import shutil
    from batill.pipeline import embed, validate_outputs
    from batill.embedding import load_plans
    from batill.storage import write_json
    config = EmbeddingConfig(max_tokens=512, embedding_dimension=2)
    source = tmp_path / 'machine_a'
    plans = prepare_corpus([document()], CharacterTokenizer(), config, 'test-revision', source / 'prepared')
    model = SimpleNamespace(tokenizer=CharacterTokenizer(), max_seq_length=512,
                            encode=lambda texts, **kwargs: np.array([[0.6, 0.8] for _ in texts]),
                            _batill_embedding_config=plans[0]['config'])
    embed_corpus(plans, model, source / 'embeddings')
    target = tmp_path / 'machine_b'
    shutil.copytree(source, target)
    monkeypatch.setattr('batill.pipeline.load_model', lambda *a, **k: pytest.fail('A model must not load for imported vectors'))
    assert embed(target) == target / 'embeddings'
    assert validate_outputs(target)['papers'] == 1
    assert load_plans(target / 'prepared')[0]['id'] == plans[0]['id']
    manifest = read_json(target / 'embeddings/manifest.json')
    assert manifest['rows'][0]['embedding_path'].startswith('papers/')
    # Detect a corrupted payload even if the matrix itself has not changed.
    path = target / 'embeddings' / manifest['rows'][0]['embedding_path']
    payload = read_json(path)
    payload['paper_vector'] = [1, 0]
    write_json(path, payload)
    with pytest.raises(ValueError, match='aggregation'):
        validate_outputs(target)


def test_changed_prepared_text_and_matrix_rejected(tmp_path):
    from batill.pipeline import validate_outputs
    from batill.embedding import load_plans
    from batill.storage import write_json
    plans = prepare_corpus([document()], CharacterTokenizer(),
                           EmbeddingConfig(max_tokens=512, embedding_dimension=2), 'test', tmp_path / 'prepared')
    model = SimpleNamespace(tokenizer=CharacterTokenizer(), max_seq_length=512,
                            encode=lambda texts, **kwargs: np.array([[1., 0.] for _ in texts]),
                            _batill_embedding_config=plans[0]['config'])
    embed_corpus(plans, model, tmp_path / 'embeddings')
    matrix = tmp_path / 'embeddings/embeddings.npz'
    matrix.write_bytes(b'damaged')
    with pytest.raises(ValueError, match='checksum'):
        validate_outputs(tmp_path)
    plan_path = tmp_path / 'prepared/inputs' / f"{plans[0]['id']}.json"
    changed = read_json(plan_path)
    changed['segments'][0]['text'] += ' altered'
    write_json(plan_path, changed)
    with pytest.raises(ValueError, match='checksum'):
        load_plans(tmp_path / 'prepared')


def test_partial_failure_preserves_first_paper_and_resumes(tmp_path):
    from copy import deepcopy
    second = deepcopy(document())
    second['pdf_sha256'] = 'sha2'
    config = EmbeddingConfig(max_tokens=512, embedding_dimension=2)
    plans = prepare_corpus([document(), second], CharacterTokenizer(), config, 'test', tmp_path / 'prepared')
    calls = []
    def interrupted_encode(texts, **kwargs):
        calls.append(texts)
        if len(calls) == 2:
            raise RuntimeError('simulated GPU failure')
        return np.array([[0., 1.] for _ in texts])
    model = SimpleNamespace(tokenizer=CharacterTokenizer(), max_seq_length=512, encode=interrupted_encode,
                            _batill_embedding_config=plans[0]['config'])
    with pytest.raises(RuntimeError, match='simulated'):
        embed_corpus(plans, model, tmp_path / 'embeddings')
    assert (tmp_path / 'embeddings/papers' / f"{plans[0]['id']}.json").exists()
    embed_corpus(plans, model, tmp_path / 'embeddings')
    assert len(calls) == 3  # First paper was not recomputed.
