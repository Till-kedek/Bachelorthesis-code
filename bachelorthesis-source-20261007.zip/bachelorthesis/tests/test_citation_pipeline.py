"""End-to-end reference retrieval/export using synthetic API responses only."""
import networkx as nx
import pandas as pd
from scipy.sparse import load_npz

from batill.citation_pipeline import finish_citation_graph


def test_finish_graph_exports_doi_version_link_and_coverage(tmp_path):
    class API:
        used_cache_files = set()

        def references(self, paper_id):
            if paper_id == 'a':
                yield [{'citedPaper': {'paperId': 'published-b', 'externalIds': {'DOI': '10.1234/b'}}},
                       {'citedPaper': {'paperId': 'outside', 'externalIds': {'DOI': '10.1234/outside'}}},
                       {'citedPaper': None}]
            else:
                yield []

    papers = pd.DataFrame({'Key': ['a' * 64, 'b' * 64, 'c' * 64],
                           'paper_id': ['P001', 'P002', 'P003'], 'query_title': ['A', 'B', 'C']})
    matches = papers.assign(s2_id=['a', 'b', ''], s2_title=['A', 'B', ''],
        doi=['10.1234/a', '10.1234/b', ''], s2_doi=['', '', ''],
        approved=[True, True, False], match_status=['approved', 'approved', 'unmatched'],
        reference_count=[3, 0, None], review_version_status=['', 'same_work_version_not_verified', ''])
    matches.attrs['review_config_id'] = 'test-review'
    job = {'papers': papers, 'matches': matches, 'output_dir': tmp_path,
           'review_audit': pd.DataFrame(), 'exclusions': pd.DataFrame(), 'selection': {'selection_id': 'test'}}
    result = finish_citation_graph(job, API())
    assert result['summary']['approved_matches'] == 2
    assert result['summary']['complete_api_reference_lists'] == 2
    assert result['summary']['internal_citation_edges'] == 1
    assert result['summary']['edges_using_only_doi_alias'] == 1
    assert result['edges'].iloc[0].target_match_method == 'exact_unique_doi'
    assert result['graph'].has_edge('a' * 64, 'b' * 64)
    assert load_npz(tmp_path / 'adjacency.npz')[0, 1] == 1
    assert nx.read_graphml(tmp_path / 'citation_graph.graphml').number_of_nodes() == 3
    assert (tmp_path / 'retrieval_status.csv').exists()


def test_conflicting_s2_id_and_doi_does_not_create_false_edge(tmp_path):
    from batill.citation_graph import export_citation_graph
    papers = pd.DataFrame({'Key': ['a', 'b', 'c'], 'paper_id': ['P001', 'P002', 'P003'],
                           'query_title': ['A', 'B', 'C']})
    matches = papers.assign(s2_id=['sa', 'sb', 'sc'], doi=['10.1234/a', '10.1234/b', '10.1234/c'],
                            approved=True, match_status='approved')
    status = pd.DataFrame(columns=['Key', 'status', 'unresolved_reference_ids'])
    references = pd.DataFrame([{'source_s2_id': 'sa', 'target_s2_id': 'sb', 'cited_doi': '10.1234/c'}])
    api = type('API', (), {'used_cache_files': set()})()
    _, edges, _, summary = export_citation_graph(papers, matches, status, references, tmp_path, {}, api)
    assert edges.empty
    assert summary['reference_identity_conflicts'] == 1
