"""Final inputs must exclude rejected IDs and never fall back to the old corpus."""
import numpy as np
import pandas as pd
import pytest

from batill.abstract_final import resolve_final_inputs
from batill.storage import file_hash, write_json
from batill.topic_age_v2 import _dated_memberships, bin_tables


@pytest.fixture
def final_root(tmp_path):
    source = tmp_path / 'final.csv'
    audit = tmp_path / 'decisions.csv'
    pd.DataFrame({'paper_id': ['kept_a', 'kept_b']}).to_csv(source, index=False)
    pd.DataFrame({'paper_id': ['kept_a', 'kept_b', 'removed'],
                  'retained': [True, True, False]}).to_csv(audit, index=False)
    config = {'schema_version': 1, 'papers': 2, 'source_csv': 'final.csv',
              'run_dir': 'vectors', 'screening_decisions': 'decisions.csv',
              'input_hashes': {p.name: file_hash(p) for p in (source, audit)}}
    write_json(tmp_path / 'configs/abstract_final_input.json', config)
    return tmp_path, config


def test_pinned_inputs_are_independent_of_active_pointer(final_root):
    root, _ = final_root
    write_json(root / 'configs/abstract_analysis_input.json', {'invalid': 'unrelated legacy pointer'})
    assert resolve_final_inputs(root) == (root / 'vectors', root / 'final.csv')


def test_missing_final_config_never_falls_back(tmp_path):
    with pytest.raises(FileNotFoundError):
        resolve_final_inputs(tmp_path)


def test_changed_input_is_rejected(final_root):
    root, _ = final_root
    (root / 'final.csv').write_text('paper_id\nremoved\n')
    with pytest.raises(ValueError, match='changed or missing'):
        resolve_final_inputs(root)


def test_matching_size_and_updated_hash_cannot_admit_excluded_id(final_root):
    root, config = final_root
    pd.DataFrame({'paper_id': ['kept_a', 'removed']}).to_csv(root / 'final.csv', index=False)
    config['input_hashes']['final.csv'] = file_hash(root / 'final.csv')
    write_json(root / 'configs/abstract_final_input.json', config)
    with pytest.raises(ValueError, match='approved screening decisions'):
        resolve_final_inputs(root)


def test_age_bins_follow_actual_final_partition_count():
    config = {'reference_year': 2026, 'minimum_year': 1800,
              'periods': [{'label': 'older', 'start': 1800, 'end': 2019},
                          {'label': 'recent', 'start': 2020, 'end': 2026}]}
    papers = pd.DataFrame({'paper_id': list('abcdefg'), 'title': 'Paper',
                           'year': [1999, 2020, 2021, 2022, 2023, 2024, 2025]})
    spec = {'analysis': 'abstracts', 'solution': 'leiden_r0.45',
            'label': 'Final abstracts', 'clusters': 'actual', 'resolution': .45}
    members = _dated_memberships(papers, np.arange(1, 8), spec, config)
    counts, _ = bin_tables(members, config['periods'])
    assert len(counts) == 14
    assert counts.papers.sum() == 7
    np.testing.assert_allclose(counts.groupby('period').share_pct.sum(), 100)
    assert set(members.paper_id) == set(papers.paper_id)
