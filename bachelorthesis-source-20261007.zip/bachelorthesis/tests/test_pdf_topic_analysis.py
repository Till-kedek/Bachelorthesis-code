"""Guard the handoff: exact PDF identities, original IDs, and no fallback fits."""
import json
from pathlib import Path

import numpy as np
import pandas as pd
import pytest
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_samples
from sklearn.metrics.pairwise import cosine_distances

import batill.pdf_topic_analysis as pdf_topics
from batill.graph_clustering import similarity_graph
from batill.storage import file_hash, fingerprint, write_json


@pytest.fixture
def exported(tmp_path, monkeypatch):
    vectors = np.repeat(np.eye(5), 3, axis=0)
    keys = [f'{i:064x}' for i in range(len(vectors))]
    papers = pd.DataFrame({'pdf_sha256': keys,
                           'paper_id': [f'P{i + 1:03d}' for i in range(len(keys))]})
    source_papers = papers.rename(columns={'pdf_sha256': 'Key', 'paper_id': 'Paper ID'})
    selection = {'selection_id': fingerprint(keys), 'config_id': 'scope',
                 'retained_papers': len(keys)}
    monkeypatch.setattr(pdf_topics, 'load_pdf_topic_corpus',
        lambda *args: (papers, vectors, None, None, selection, None))
    input_dir = tmp_path / 'input'
    for name in ('embeddings/embeddings.npz', 'embeddings/manifest.json', 'prepared/manifest.json'):
        path = input_dir / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(name)
    exclusions = tmp_path / 'exclusions.json'
    exclusions.write_text('{}')
    source = tmp_path / 'Clustering PDFs.ipynb'
    source.write_text(json.dumps({'cells': [{'cell_type': 'code', 'source': ['source fit']}]}))
    model = KMeans(n_clusters=5, n_init=1, random_state=42).fit(vectors)
    km = {'model': model, 'labels': model.labels_, 'seed': 42,
          'silhouettes': silhouette_samples(cosine_distances(vectors), model.labels_, metric='precomputed')}
    leiden = {'labels': np.repeat(np.arange(1, 6), 3), 'resolution': .875, 'seed': 42, 'quality': 1.}
    destination = tmp_path / 'snapshot'
    input_id = pdf_topics.pdf_partition_input_id(keys, vectors)
    export_args = dict(kmeans_result=km, leiden_result=leiden,
        embedding_graph=similarity_graph(vectors, neighbours=2),
        fit_input_ids={name: input_id for name in pdf_topics.SOLUTIONS},
        input_dir=input_dir, exclusion_file=exclusions, source_notebook=source, settings={})
    pdf_topics.export_pdf_topic_partitions(destination, source_papers, vectors, **export_args)
    return dict(destination=destination, papers=papers, embeddings=vectors,
                input_dir=input_dir, exclusion_file=exclusions, selection=selection,
                source_papers=source_papers, export_args=export_args)


def load(fixture):
    return pdf_topics.load_pdf_topic_partitions(**{key: fixture[key] for key in (
        'destination', 'papers', 'embeddings', 'input_dir', 'exclusion_file', 'selection')})


def change_manifest(fixture, change):
    path = fixture['destination'] / 'partition_manifest.json'
    manifest = json.loads(path.read_text())
    change(manifest)
    write_json(path, manifest)


def change_assignments(fixture, change):
    path = fixture['destination'] / 'assignments.csv'
    table = pd.read_csv(path, dtype={'pdf_sha256': str})
    change(table).to_csv(path, index=False)
    change_manifest(fixture, lambda m: m.update(assignments_sha256=file_hash(path)))


def test_roundtrip_preserves_both_memberships_without_fitting(exported, monkeypatch):
    def forbidden(*args, **kwargs):
        raise AssertionError('Topic loading must never fit clusters')
    monkeypatch.setattr(KMeans, 'fit', forbidden)
    monkeypatch.setattr('batill.graph_clustering.leiden_partition', forbidden)
    solutions, manifest = load(exported)
    assert manifest['source_kind'] == 'pdf_text_embeddings'
    assert np.array_equal(solutions['kmeans_k5']['labels'], exported['export_args']['kmeans_result']['labels'])
    assert np.array_equal(solutions['embedding_leiden_k5']['labels'], np.repeat(np.arange(1, 6), 3))
    assert set(solutions['kmeans_k5']['labels']) == set(range(5))


def test_assignment_rows_are_aligned_by_hash_not_position(exported):
    before, _ = load(exported)
    change_assignments(exported, lambda table: table.sample(frac=1, random_state=7))
    after, _ = load(exported)
    for name in before:
        np.testing.assert_array_equal(before[name]['labels'], after[name]['labels'])


def test_missing_export_does_not_create_replacement_clusters(exported):
    (exported['destination'] / 'assignments.csv').unlink()
    with pytest.raises(FileNotFoundError, match='never creates replacement'):
        load(exported)


@pytest.mark.parametrize('mutation', ['citation', 'scope', 'vectors', 'checksum', 'method'])
def test_incompatible_provenance_is_rejected(exported, mutation):
    if mutation == 'citation':
        change_manifest(exported, lambda m: m.update(source_kind='direct_citations'))
    elif mutation == 'scope':
        exported['exclusion_file'].write_text('{"changed": true}')
    elif mutation == 'vectors':
        exported['embeddings'] = exported['embeddings'].copy()
        exported['embeddings'][0, 0] = .9
    elif mutation == 'method':
        change_manifest(exported, lambda m: m['solutions']['embedding_leiden_k5']['graph'].update(kind='direct_citations'))
    else:
        path = exported['destination'] / 'assignments.csv'
        path.write_text(path.read_text() + '\n')
    with pytest.raises(ValueError):
        load(exported)


@pytest.mark.parametrize('mutation', ['missing', 'duplicate', 'wrong_id', 'four_clusters', 'scores'])
def test_corrupt_memberships_are_rejected_even_with_updated_file_hash(exported, mutation):
    def change(table):
        if mutation == 'missing':
            return table.iloc[1:]
        if mutation == 'duplicate':
            return pd.concat([table, table.iloc[[0]]])
        if mutation == 'wrong_id':
            table.loc[0, 'paper_id'] = 'P999'
        if mutation == 'four_clusters':
            table.loc[table.solution.eq('kmeans_k5') & table.cluster.eq(4), 'cluster'] = 3
        if mutation == 'scores':
            table.loc[0, 'cosine_silhouette'] = -.5
        return table
    change_assignments(exported, change)
    with pytest.raises(ValueError):
        load(exported)


def test_export_rejects_stale_same_size_fit(exported):
    args = dict(exported['export_args'])
    args['fit_input_ids'] = {name: 'stale' for name in pdf_topics.SOLUTIONS}
    with pytest.raises(ValueError, match='Stale PDF-text fit'):
        pdf_topics.export_pdf_topic_partitions(exported['destination'],
            exported['source_papers'], exported['embeddings'], **args)


def test_scope_filter_remaps_passages_and_preserves_original_paper_ids(tmp_path, monkeypatch):
    keys = [f'{i:064x}' for i in range(4)]
    papers = pd.DataFrame({'row': range(4), 'pdf_sha256': keys, 'paper_id': ['P001', 'P002', 'P003', 'P004']})
    vectors = np.eye(4)
    passages = pd.DataFrame({'row': [0, 1, 1, 2, 3], 'text': ['a', 'b', 'bb', 'c', 'd']})
    monkeypatch.setattr(pdf_topics, 'load_topic_corpus', lambda _: (papers, vectors, passages, {}))
    path = tmp_path / 'scope.json'
    write_json(path, {'schema_version': 1, 'papers': [{'pdf_sha256': keys[1], 'exclude': True, 'reason': 'scope'}]})
    selected, x, excerpts, _, _, _ = pdf_topics.load_pdf_topic_corpus(tmp_path, path)
    assert selected.paper_id.tolist() == ['P001', 'P003', 'P004']
    assert selected.row.tolist() == [0, 1, 2]
    assert excerpts.row.tolist() == [0, 1, 2]
    assert excerpts.text.tolist() == ['a', 'c', 'd']
    np.testing.assert_array_equal(x, vectors[[0, 2, 3]])


def test_topic_notebook_contains_no_clustering_or_citation_workflow():
    notebook = Path(__file__).resolve().parents[1] / 'Topic analysis PDFs.ipynb'
    cells = json.loads(notebook.read_text())['cells']
    code = '\n'.join(''.join(c['source']) for c in cells if c['cell_type'] == 'code')
    for forbidden in ('fit_partitions', 'KMeans(', 'leiden_sweep(', 'leiden_partition(',
                      'citation_results', 'citation_selected', 'canonical_corpus', '%run'):
        assert forbidden not in code
    assert 'load_pdf_topic_partitions(' in code


def test_duplicate_filter_is_optional_for_original_citation_scope(tmp_path, monkeypatch):
    keys = [f'{i:064x}' for i in range(3)]
    papers = pd.DataFrame({'row': range(3), 'pdf_sha256': keys,
                           'paper_id': ['P001', 'P002', 'P003']})
    vectors = np.eye(3)
    passages = pd.DataFrame({'row': [0, 1, 2], 'text': ['canonical', 'duplicate', 'other']})
    monkeypatch.setattr(pdf_topics, 'load_topic_corpus', lambda _: (papers.copy(), vectors, passages, {}))
    path = tmp_path / 'scope.json'
    write_json(path, {'schema_version': 1, 'papers': []})
    write_json(tmp_path / 'pdf_duplicates.json', {'schema_version': 1, 'duplicate_pdfs': [
        {'duplicate_key': keys[1], 'canonical_key': keys[0]}]})
    selected, x, excerpts, _, selection, _ = pdf_topics.load_pdf_topic_corpus(tmp_path, path)
    assert selected.paper_id.tolist() == ['P001', 'P003']
    assert excerpts.text.tolist() == ['canonical', 'other']
    assert excerpts.row.tolist() == [0, 1]
    np.testing.assert_array_equal(x, vectors[[0, 2]])
    scoped, _, _, _, scope, _ = pdf_topics.load_pdf_topic_corpus(tmp_path, path, deduplicate=False)
    assert scoped.paper_id.tolist() == ['P001', 'P002', 'P003']
    assert scope['selection_id'] == selection['scope_selection_id']
