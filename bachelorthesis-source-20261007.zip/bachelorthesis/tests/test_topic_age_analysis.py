"""Check scientific denominators, date validation and frozen-input joins."""
import json
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

from batill.topic_age_analysis import (
    analyze, checked_csv, load_paper_ages, period_labels, sha256,
    summarize_clusters, temporal_counts, validate_years,
)


def example():
    # Unequal period totals, a zero-count topic, and one unassigned citation isolate.
    frame = pd.DataFrame({
        'paper_id': ['a', 'b', 'c', 'd', 'e', 'f'],
        'cluster': [1, 2, 1, 1, 2, 0],
        'publication_year': [2000, 2009, 2020, 2021, 2022, 2023],
        'alternative_year': [2000, 2010, 2020, 2021, 2022, 2023],
    })
    frame['analysis'] = 'citations'
    frame['solution'] = 'citation_r1'
    frame['unit'] = 'canonical work'
    frame['assigned'] = frame.cluster.ne(0)
    frame['display_cluster'] = frame.cluster.map({0: 'Unassigned', 1: 'C1', 2: 'C2'})
    frame['topic_name'] = frame.cluster.map({0: 'Unassigned', 1: 'Topic A', 2: 'Topic B'})
    frame['reference_year'] = 2026
    frame['age_years'] = 2026 - frame.publication_year
    frame['canonical_key'] = frame.paper_id
    frame['is_duplicate_pdf'] = False
    frame['year_difference'] = frame.publication_year - frame.alternative_year
    return frame


PERIODS = [{'label': 'early', 'start': 2000, 'end': 2009},
           {'label': 'middle', 'start': 2010, 'end': 2019},
           {'label': 'late', 'start': 2020, 'end': 2026}]


def test_hand_computed_ages_and_shares():
    tables = analyze(example(), {'reference_year': 2026, 'periods': PERIODS,
                                 'comparison_periods': ['early', 'late']})
    a = tables['cluster_age_summary'].set_index('cluster').loc[1]
    assert a.papers == 3 and a.median_age == 6
    assert a.mean_age == pytest.approx((26 + 6 + 5) / 3)
    assert (a.q25_age, a.q75_age) == (5.5, 16)
    counts = tables['period_shares'].set_index(['cluster', 'period'])
    assert counts.loc[(1, 'early'), 'share_pct'] == 50
    assert counts.loc[(1, 'late'), 'share_pct'] == pytest.approx(200 / 3)
    assert counts.loc[(1, 'late'), 'period_all_papers'] == 4
    assert counts.loc[(1, 'late'), 'period_unassigned_papers'] == 1
    assert counts.loc[(1, 'late'), 'period_assigned_papers'] == 3
    assert np.isnan(counts.loc[(1, 'middle'), 'share_pct'])
    change = tables['period_changes'].set_index('cluster').loc[1]
    assert change.change_percentage_points == pytest.approx(100 / 6)
    assert tables['coverage'].unassigned_papers.iloc[0] == 1
    sensitivity = tables['year_sensitivity'].set_index('cluster').loc[1]
    assert not sensitivity.share_change_sign_agrees


def test_annual_grid_distinguishes_no_data_from_zero_share():
    annual = temporal_counts(example()).set_index(['cluster', 'start_year'])
    assert (1, 2026) in annual.index
    assert np.isnan(annual.loc[(1, 2001), 'share_pct'])
    assert annual.loc[(2, 2000), 'share_pct'] == 0
    # A year containing only an isolate still has no assigned-cluster denominator.
    assert np.isnan(annual.loc[(1, 2023), 'share_pct'])
    assert annual.loc[(1, 2023), 'period_unassigned_papers'] == 1


@pytest.mark.parametrize('bad', ['', None, 'unknown', 2020.5, np.inf, 1799, 2027])
def test_invalid_years_fail_instead_of_guessing(bad):
    with pytest.raises(ValueError, match='P_BAD'):
        validate_years(pd.Series([2020, bad]), pd.Series(['P_OK', 'P_BAD']), 2026)


def test_period_boundaries_and_overlaps():
    assert period_labels(pd.Series([2000, 2009, 2010, 2019, 2020, 2026]), PERIODS).tolist() == [
        'early', 'early', 'middle', 'middle', 'late', 'late']
    with pytest.raises(ValueError, match='exactly one'):
        period_labels(pd.Series([1999]), PERIODS)
    with pytest.raises(ValueError, match='exactly one'):
        period_labels(pd.Series([2000]), [*PERIODS, {'label': 'overlap', 'start': 2000, 'end': 2000}])


def test_changed_input_rejected(tmp_path):
    path = tmp_path / 'source.csv'
    path.write_text('paper_id,year\na,2020\n')
    spec = {'path': 'source.csv', 'sha256': sha256(path)}
    assert checked_csv(tmp_path, spec).year.iloc[0] == 2020
    path.write_text('paper_id,year\na,2021\n')
    with pytest.raises(ValueError, match='Frozen input'):
        checked_csv(tmp_path, spec)


def test_pdf_alias_join_preserves_both_units_and_named_clusters(tmp_path):
    def save(name, records):
        path = tmp_path / name
        pd.DataFrame(records).to_csv(path, index=False)
        return {'path': name, 'sha256': sha256(path)}
    node = dict(Key='canonical', paper_id='P1', openalex_id='W1', openalex_year=2010,
                query_year=2012, query_title='Canonical title', doi='test-doi')
    nodes = save('nodes.csv', [node])
    mapping = save('mapping.csv', [
        dict(Key=key, paper_id=pid, canonical_key='canonical', canonical_paper_id='P1', is_duplicate_pdf=alias)
        for key, pid, alias in [('canonical', 'P1', False), ('alias', 'P2', True)]])
    members = save('members.csv', [
        dict(solution='kmeans_k5', paper_id=pid, cluster=c, proposed_label=label,
             proposal_matched=True, pdf_sha256=key, title=pid)
        for key, pid, c, label in [('alias', 'P2', 1, 'Second'), ('canonical', 'P1', 0, 'First')]])
    profiles = save('profiles.csv', [dict(solution='kmeans_k5', cluster=c, papers=1,
        proposed_label=label, proposal_matched=True) for c, label in [(0, 'First'), (1, 'Second')]])
    config = {'reference_year': 2026, 'minimum_year': 1800, 'periods': PERIODS,
        'reviewed_nodes': nodes, 'pdf_to_work': mapping, 'sources': {'pdfs': {
            'source_notebook': 'source.ipynb', 'unit': 'PDF', 'expected_papers_per_solution': 2,
            'solutions': {'kmeans_k5': 2}, 'memberships': members, 'profiles': profiles}}}
    papers, _ = load_paper_ages(tmp_path, config)
    assert papers.paper_id.tolist() == ['P1', 'P2']
    assert papers.cluster.tolist() == [0, 1]
    assert papers.topic_name.tolist() == ['First', 'Second']
    assert papers.age_years.tolist() == [16, 16]
    assert papers.alternative_year.tolist() == [2012, 2012]
    assert papers.is_duplicate_pdf.sum() == 1
    # Even a deliberately rehashed mapping cannot silently drop one PDF.
    mapping_path = tmp_path / 'mapping.csv'
    pd.read_csv(mapping_path).iloc[:1].to_csv(mapping_path, index=False)
    config['pdf_to_work']['sha256'] = sha256(mapping_path)
    with pytest.raises(ValueError, match='Missing reviewed PDF/work identity'):
        load_paper_ages(tmp_path, config)
