"""Elite abstract review keeps external sources distinct and rejects stale evidence."""

import copy
import json

import numpy as np
import pandas as pd
import pytest

from batill.elite_abstract_cluster_examples import representative_papers
from batill.pdf_cluster_examples import membership_id
from batill.storage import file_hash, fingerprint, write_json


@pytest.fixture
def elite_review(tmp_path):
    records, choices = [], []
    labels = np.array([1, 1, 2, 2])
    for i, pid in enumerate('abcd'):
        abstract = f'Private equity study {pid}. Buyout evidence.'
        source_path = f'{pid}.json'
        is_external = i == 0
        kind = 'external_full_abstract' if is_external else 'pdf_abstract'
        source = {'pdf_sha256': pid, 'abstract': abstract,
                  'blocks': [{'id': 'block', 'page': 1, 'text': abstract}]}
        write_json(tmp_path / source_path, source)
        row = {'paper_id': pid, 'title': pid, 'pdf_sha256': pid,
               'source_filename': f'{pid}.pdf', 'embedding_text': pid + '\n\n' + abstract,
               'abstract': abstract, 'doi': '', 'is_short_description': 'False',
               'abstract_source_kind': kind, 'abstract_source_path': source_path,
               'abstract_source_sha256': file_hash(tmp_path / source_path),
               'abstract_source_url': 'https://example.org/abstract' if is_external else '',
               'abstract_source_record_id': pid if is_external else '',
               'abstract_spans': '[]' if is_external else json.dumps([
                   {'page': 1, 'block_id': 'block', 'start': 0, 'end': len(abstract)}]),
               'document_path': source_path, 'document_sha256': file_hash(tmp_path / source_path)}
        records.append(row)
        choices.append({**row, 'cluster': int(labels[i]),
            'embedding_text_sha256': fingerprint(row['embedding_text']),
            'abstract_sha256': fingerprint(abstract),
            'evidence': [
                {'source_field': 'abstract', 'excerpt': abstract[:abstract.index(' Buyout')],
                 'excerpt_start': 0, 'excerpt_end': abstract.index(' Buyout')},
                {'source_field': 'pdf_context' if i == 1 else 'abstract',
                 'page': 1, 'block_id': 'block', 'excerpt': 'Buyout evidence.',
                 'excerpt_start': abstract.index('Buyout'), 'excerpt_end': len(abstract)}]})
    papers = pd.DataFrame(records)
    vectors = np.array([[2., 0.], [1., .1], [0., 2.], [.1, 1.]])
    context = {'root': tmp_path, 'papers': papers,
               'source_manifest': {'input_id': 'vectors'},
               'input_hashes': {'catalog_manifest.json': 'catalog'},
               'solutions': {'leiden_r0.7': {'labels': labels}}}
    analysis = {'papers': papers, 'labels': labels, 'embeddings': vectors,
                'membership': pd.DataFrame({'paper_id': list('abcd'), 'cosine_silhouette': [.9] * 4})}
    settings = {'saved_partition': 'leiden_r0.7', 'resolution': .7}
    review = {'solution': 'leiden_r0.7', 'resolution': .7, 'embedding_input_id': 'vectors',
              'catalog_manifest_sha256': 'catalog', 'membership_id': membership_id(papers, labels),
              'focus': {'1': 'going private', '2': 'funds'}, 'papers': choices}
    return context, analysis, settings, review


def test_external_abstract_has_no_invented_pdf_page_and_vectors_are_unchanged(elite_review):
    vectors = elite_review[1]['embeddings'].copy()
    selected, evidence, diagnostics = representative_papers(*elite_review)
    assert len(selected) == 4 and len(evidence) == 8 and len(diagnostics) == 4
    external = evidence.loc[evidence.paper_id.eq('a')]
    assert external.page.isna().all() and external.block_id.isna().all()
    assert external.source_kind.eq('external_full_abstract').all()
    assert evidence.source_kind.eq('supplementary_pdf_context').sum() == 1
    np.testing.assert_array_equal(vectors, elite_review[1]['embeddings'])


def test_changed_abstract_cannot_keep_the_same_review(elite_review):
    context, analysis, settings, review = copy.deepcopy(elite_review)
    analysis['papers'].loc[0, 'abstract'] = 'Different content.'
    with pytest.raises(ValueError, match='abstract text'):
        representative_papers(context, analysis, settings, review)


def test_cached_source_changes_invalidate_the_review(elite_review):
    context, analysis, settings, review = elite_review
    (context['root'] / 'a.json').write_text('{}')
    with pytest.raises(ValueError, match='Cached abstract source changed'):
        representative_papers(context, analysis, settings, review)


def test_supplementary_pdf_quote_must_match_its_block(elite_review):
    context, analysis, settings, review = copy.deepcopy(elite_review)
    review['papers'][1]['evidence'][1]['excerpt'] = 'Unsupported statement.'
    with pytest.raises(ValueError, match='passage no longer matches'):
        representative_papers(context, analysis, settings, review)
