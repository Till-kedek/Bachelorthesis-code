"""Manual decisions must preserve unique works, evidence and graph direction."""
import pandas as pd
import pytest
from scipy.sparse import load_npz
from batill.citation_curation import apply_identity_review, export_reviewed_graph
from batill.storage import write_json, file_hash


def fixture_data():
    matches = pd.DataFrame({'Key':['a','b','bb'], 'paper_id':['P001','P002','P003'],
        'source_filename':['a.pdf','b.pdf','bb.pdf'], 'query_title':['Paper A','Paper B','Paper B'],
        'openalex_id':['WA','WB','WB'], 'openalex_title':['Paper A','Paper B','Paper B'],
        'openalex_doi':['10.1/a','10.1/b','10.1/b'], 'approved':[True,False,False],
        'match_status':['accepted','duplicate','duplicate'], 'reference_status':['available_nonempty','empty_provider_list','empty_provider_list']})
    works={'a':{'id':'WA','referenced_works':['WB']},'b':{'id':'WB','referenced_works':[]},'bb':{'id':'WB','referenced_works':[]}}
    aliases=matches[['Key','openalex_id']].assign(method='test')
    review={'duplicate_pdfs':[{'duplicate_key':'bb','canonical_key':'b'}], 'work_overrides':[]}
    return matches,works,aliases,review


def test_duplicates_map_to_one_approved_work():
    m,w,a,r=fixture_data()
    result,_,aliases,mapping=apply_identity_review(m,w,a,r)
    assert result.Key.tolist()==['a','b'] and result.approved.all()
    assert mapping.canonical_key.tolist()==['a','b','b']
    assert set(aliases.Key)=={'a','b'}
    assert len(m)==3 and not m.iloc[1].approved  # inputs remain unchanged


def test_changed_identity_rejected():
    m,w,a,r=fixture_data();m.loc[2,'openalex_id']='DifferentWork'
    with pytest.raises(ValueError,match='identities changed'):
        apply_identity_review(m,w,a,r)


def test_reviewed_graph_retains_evidence_and_direction(tmp_path):
    m,w,a,r=fixture_data();base=tmp_path/'base';base.mkdir()
    m.to_csv(base/'matches.csv',index=False);a.to_csv(base/'identity_aliases.csv',index=False)
    write_json(base/'resolved_works.json',w);write_json(base/'matching_settings.json',{})
    write_json(tmp_path/'pages.json',[{'source_key':'b','pdf_page':3,'text':'References: Author. Paper A.'}])
    r.update(selection_id='test',evidence_pages='pages.json',evidence_pages_sha256=file_hash(tmp_path/'pages.json'),manual_edges=[
        {'source_key':'b','target_key':'a','pdf_page':3,'approved':True,'normalized_excerpt':'author paper a'}])
    write_json(tmp_path/'review.json',r)
    api=type('API',(),{'network_requests':0,'used_cache_files':set()})()
    n,e,g,s,mapping=export_reviewed_graph(tmp_path,base,{'selection_id':'test'},api,review_file=tmp_path/'review.json')
    assert s['selected_pdfs']==3 and s['graph_work_nodes']==2 and s['unapproved_pdfs']==0
    assert s['manually_added_internal_edges']==1 and s['internal_citation_edges']==2
    assert load_npz(base/'reviewed/adjacency.npz').toarray().tolist()==[[0,1],[1,0]]
    assert g.edges['b','a']['citation_source']=='local_pdf_manual_review'
    # Saved evidence cannot be silently replaced or misquoted.
    r['manual_edges'][0]['normalized_excerpt']='not actually on page'
    write_json(tmp_path/'review.json',r)
    with pytest.raises(ValueError,match='excerpt'):
        export_reviewed_graph(tmp_path,base,{'selection_id':'test'},api,review_file=tmp_path/'review.json')
