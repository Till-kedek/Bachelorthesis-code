"""Regression checks for abstract IDs, source fields and evidence exports."""

import numpy as np
import pandas as pd
import pytest

from batill.abstract_topic_explorer import (
    analyse_partition, choose_partition, export_analysis, search_expression,
    supporting_papers,
)
from batill.storage import file_hash, read_json


def test_catalog_caches_memberships_and_detects_tampering(context, monkeypatch):
    import batill.abstract_topic_explorer as explorer
    from batill.storage import write_json

    root, input_id = context['root'], 'test-input'
    report = root / 'reports/abstract_clustering' / input_id
    report.mkdir(parents=True)
    for manifest_name, csv_name in (
        ('kmeans_sweep_manifest.json', 'kmeans_diagnostics.csv'),
        ('sweep_manifest.json', 'leiden_resolution_diagnostics.csv'),
    ):
        (report / csv_name).write_text('test diagnostics')
        write_json(report / manifest_name, {'input_id': input_id, 'papers': 4,
                   'diagnostics_sha256': file_hash(report / csv_name)})
    fits = []

    def fit(vectors, manifests):
        fits.append(1)
        return {'leiden_r0.45': {'method': 'Embedding Leiden', 'clusters': 2,
                'resolution': 0.45, 'seed': 42, 'seed_ARI': 1.0,
                'labels': np.array([1, 1, 2, 2]), 'silhouettes': np.ones(4)}}

    monkeypatch.setattr(explorer, '_fit_catalog', fit)
    args = (root, context['papers'], context['embeddings'], {'input_hashes': {}}, input_id)
    with pytest.raises(FileNotFoundError, match='Saved abstract catalog'):
        explorer._load_catalog(*args, build_missing=False)
    assert not fits
    evidence, first, _, _ = explorer._load_catalog(*args)
    _, second, _, _ = explorer._load_catalog(*args)
    assert len(fits) == 1
    np.testing.assert_array_equal(first['leiden_r0.45']['labels'], second['leiden_r0.45']['labels'])
    labels, settings = choose_partition({'solutions': second})
    assert settings['resolution'] == 0.45
    np.testing.assert_array_equal(labels, [1, 1, 2, 2])
    with (evidence / 'partitions.npz').open('ab') as stream:
        stream.write(b'changed')
    with pytest.raises(ValueError, match='checksum'):
        explorer._load_catalog(*args)


@pytest.fixture
def context(tmp_path):
    papers = pd.DataFrame({
        'paper_id': ['A', 'B', 'C', 'D'],
        'title': ['Private', 'Buyout evidence', 'Credit study', 'Credit evidence'],
        'abstract': ['equity buyout returns.', 'Private-equity buyout returns.',
                     'Credit markets lending.', 'Credit markets lending.'],
        'doi': '', 'year': '2020', 'journal': 'Journal',
        'document_type': 'Article', 'document_language': 'English',
        'abstract_word_count': 3,
    })
    papers['embedding_text'] = papers.title + '\n\n' + papers.abstract
    papers['text'] = papers.embedding_text
    vectors = np.array([[1., 0.], [.99, .01], [0., 1.], [.01, .99]])
    vectors /= np.linalg.norm(vectors, axis=1, keepdims=True)
    passages = pd.DataFrame([
        {'row': i, 'page': None, 'block_id': field, 'text': getattr(paper, field)}
        for i, paper in enumerate(papers.itertuples()) for field in ('title', 'abstract')
    ])
    evidence = tmp_path / 'source'
    evidence.mkdir()
    (evidence / 'assignments.csv').write_text('paper_id,cluster\nA,0\nB,0\nC,1\nD,1\n')
    return {'root': tmp_path, 'evidence': evidence, 'papers': papers,
            'embeddings': vectors, 'passages': passages,
            'solutions': {'kmeans_k2': {'labels': np.array([0, 0, 1, 1]),
                                      'method': 'K-means', 'seed': 42}},
            'partition_file': evidence / 'assignments.csv', 'input_hashes': {},
            'export_directory': 'outputs/topic_analysis_abstracts_v2'}


def test_saved_cluster_zero_is_included_in_evidence_and_denominators(context):
    labels, settings = choose_partition(context, source='saved', saved='kmeans_k2')
    labels[0] = 1
    assert context['solutions']['kmeans_k2']['labels'][0] == 0
    labels, settings = choose_partition(context, source='saved', saved='kmeans_k2')
    result = analyse_partition(context, labels, min_df=1)
    assert result['membership'].cluster.tolist() == [0, 0, 1, 1]
    assert result['summary'].papers.tolist() == [2, 2]
    assert result['unassigned'].empty
    term = result['terms'].query("cluster == 0 and term == 'buyout returns'").iloc[0]
    assert (term.inside_count, term.inside_n, term.outside_n) == (2, 2, 2)
    assert result['examples'].source_field.eq('abstract').all()


def test_search_does_not_bridge_title_and_abstract(context):
    result = analyse_partition(context, np.array([0, 0, 1, 1]), min_df=1)
    search = search_expression(result, 'private equity')
    support = supporting_papers(result, 'private equity', 0)
    assert search['Papers containing term'].tolist() == [1, 0]
    assert support.paper_id.tolist() == ['B']
    assert support.source_field.tolist() == ['abstract']
    assert 'page' not in support


def test_export_records_abstract_assignment_source_and_preserves_previous_runs(context):
    labels, settings = choose_partition(context, source='saved', saved='kmeans_k2')
    result = analyse_partition(context, labels, min_df=1)
    first = export_analysis(result, context, settings)
    second = export_analysis(result, context, settings)
    assert first != second and first.is_dir() and second.is_dir()
    assert first.parent == context['root'] / context['export_directory']
    manifest = read_json(first / 'run_manifest.json')
    assert manifest['source_partitions_sha256'] == file_hash(context['partition_file'])
    assert manifest['text_settings']['minimum_cluster_support'] == 'max(2, ceil(0 * cluster_size))'
    assert pd.read_csv(first / 'membership.csv').cluster.tolist() == [0, 0, 1, 1]
