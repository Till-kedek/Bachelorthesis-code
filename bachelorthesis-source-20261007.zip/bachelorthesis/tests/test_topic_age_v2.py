"""Year boundaries, original cluster IDs, within-bin denominators and zero cells."""

from pathlib import Path

import numpy as np
import pandas as pd
import pytest

from batill.storage import read_json
from batill.topic_age_v2 import _dated_memberships, bin_tables, bin_matrix


@pytest.fixture
def config():
    return read_json(Path(__file__).parents[1] / 'configs/topic-age-v2-inputs.json')


def abstract_papers(years):
    return pd.DataFrame({'paper_id': [f'A{i}' for i in range(len(years))],
                         'title': 'Paper', 'year': years})


def test_bins_match_readability_boundaries_and_kmeans_zero_is_assigned(config):
    years = [1999, 2000, 2009, 2010, 2019, 2020, 2026]
    labels = np.array([0, 1, 2, 3, 4, 0, 1])
    spec = next(s for s in config['partitions'] if s['analysis'] == 'abstracts' and s['solution'] == 'kmeans_k5')
    members = _dated_memberships(abstract_papers(years), labels, spec, config)
    assert members.period.tolist() == ['≤1999', '2000–2009', '2000–2009',
                                      '2010–2019', '2010–2019', '2020–2026', '2020–2026']
    assert members.assigned.all()
    np.testing.assert_array_equal(members.cluster, labels)
    counts, coverage = bin_tables(members, config['periods'])
    assert len(counts) == 20 and len(coverage) == 4
    assert counts.papers.sum() == 7
    np.testing.assert_allclose(counts.groupby('period').share_pct.sum(), 100)
    matrix = bin_matrix(counts, 'abstracts', 'kmeans_k5', config['periods'])
    assert matrix.index.tolist() == [p['label'] for p in config['periods']]
    assert matrix.loc['2020–2026', 'Cluster 0'] == 1
    assert matrix.loc['≤1999', 'Cluster 4'] == 0


def test_citation_isolates_do_not_make_a_sixth_cluster_or_enter_share_denominators(config):
    years = [2026, 2019, 2009, 2000, 1999, 1989]
    papers = abstract_papers(years).assign(pdf_sha256=list('abcdef'))
    nodes = papers.rename(columns={'pdf_sha256': 'Key', 'year': 'openalex_year'}).assign(doi='')
    # Deliberately scramble metadata and change the PDF-query dates.
    papers['year'] = 2020
    spec = config['partitions'][-1]
    members = _dated_memberships(papers, np.array([0, 1, 2, 3, 4, 5]), spec, config,
                                 nodes=nodes.iloc[::-1])
    assert members.publication_year.tolist() == years
    assert members.assigned.tolist() == [False, True, True, True, True, True]
    counts, coverage = bin_tables(members, config['periods'])
    assert counts.cluster.nunique() == 5 and 0 not in counts.cluster.values
    assert counts.papers.sum() == 5
    recent = counts.loc[counts.period.eq('2020–2026')]
    assert recent.papers.eq(0).all() and recent.share_pct.isna().all()
    audit = coverage.loc[coverage.period.eq('2020–2026')].iloc[0]
    assert (audit.period_all_papers, audit.period_assigned_papers, audit.period_unassigned_papers) == (1, 0, 1)
    older = counts.loc[counts.period.eq('2010–2019')]
    assert older.loc[older.cluster.eq(1), 'share_pct'].iloc[0] == 100
    assert older.loc[older.cluster.eq(2), 'share_pct'].iloc[0] == 0


@pytest.mark.parametrize('bad_year', [None, '', 2027, 2010.5, 1799])
def test_invalid_years_stop_instead_of_dropping_records(config, bad_year):
    spec = config['partitions'][2]
    with pytest.raises(ValueError, match='publication years'):
        _dated_memberships(abstract_papers([bad_year, 2000, 2010, 2020, 2026]),
                           np.arange(5), spec, config)


def test_six_clusters_are_rejected(config):
    with pytest.raises(ValueError, match='exactly five'):
        _dated_memberships(abstract_papers([2020] * 6), np.arange(6), config['partitions'][2], config)


def test_year_shares_use_each_cluster_total_and_plot_year_segments(config):
    from batill.topic_age_names import plot_named_bins
    import matplotlib.pyplot as plt

    spec = {'analysis': 'abstracts', 'solution': 'kmeans_k2', 'clusters': 2, 'label': 'Test'}
    members = _dated_memberships(abstract_papers([2020, 2021, 2010, 1999, 2000]),
                                 np.array([0, 0, 0, 1, 1]), spec, config)
    counts, _ = bin_tables(members, config['periods'], share_basis='cluster')
    np.testing.assert_allclose(counts.groupby('cluster').share_pct.sum(), 100)
    recent = counts.loc[counts.period.eq('2020–2026')].set_index('cluster')
    assert recent.loc[0, 'cluster_papers'] == 3
    assert recent.loc[0, 'share_pct'] == pytest.approx(200 / 3)
    assert recent.loc[1, 'share_pct'] == 0
    names = members[['analysis', 'solution', 'cluster', 'topic_name', 'display_cluster']].drop_duplicates()
    fig = plot_named_bins(counts, spec, config['periods'], names, share_basis='cluster')
    bars = fig.axes[1].containers
    assert len(bars) == 4
    np.testing.assert_allclose([[patch.get_width() for patch in container] for container in bars],
                              [[200 / 3, 0], [100 / 3, 0], [0, 50], [0, 50]])
    assert [text.get_text() for text in fig.axes[1].get_legend().get_texts()] == [p['label'] for p in config['periods']]
    plt.close(fig)


def test_cluster_year_shares_exclude_citation_isolates(config):
    papers = abstract_papers([2026, 2020, 2010, 1999]).assign(pdf_sha256=list('abcd'))
    nodes = papers.rename(columns={'pdf_sha256': 'Key', 'year': 'openalex_year'}).assign(doi='')
    spec = {'analysis': 'citations', 'solution': 'citation_test', 'clusters': 2, 'label': 'Test'}
    members = _dated_memberships(papers, np.array([0, 1, 1, 2]), spec, config, nodes=nodes)
    counts, coverage = bin_tables(members, config['periods'], share_basis='cluster')
    assert set(counts.cluster) == {1, 2}
    assert counts.groupby('cluster').cluster_papers.first().to_dict() == {1: 2, 2: 1}
    assert counts.loc[counts.period.eq('2000–2009'), 'share_pct'].eq(0).all()
    np.testing.assert_allclose(counts.groupby('cluster').share_pct.sum(), 100)
    assert coverage.period_unassigned_papers.sum() == 1
