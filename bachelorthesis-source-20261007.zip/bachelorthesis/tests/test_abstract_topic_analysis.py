"""Guard the handoff: exact abstract identities, original IDs, and no fallback fits."""
import json
from pathlib import Path

import numpy as np
import pandas as pd
import pytest
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_samples
from sklearn.metrics.pairwise import cosine_distances

import batill.abstract_topic_analysis as abstract_topics
from batill.graph_clustering import similarity_graph
from batill.storage import file_hash, fingerprint, write_json


@pytest.fixture
def exported(tmp_path, monkeypatch):
    vectors = np.repeat(np.eye(6), 3, axis=0)
    keys = [f'2-s2.0-{1000+i}' for i in range(len(vectors))]
    papers = pd.DataFrame({'paper_id': keys, 'title': ['Topic'] * len(keys),
        'abstract': ['Abstract source text.'] * len(keys), 'doi': [''] * len(keys),
        'year': ['2020'] * len(keys), 'journal': ['Journal'] * len(keys),
        'document_type': ['Article'] * len(keys), 'document_language': ['English'] * len(keys),
        'abstract_word_count': [3] * len(keys),
        'embedding_text': ['Topic\n\nAbstract source text.'] * len(keys)})
    papers['Key'] = papers.paper_id
    papers['Paper ID'] = papers.paper_id
    provenance = {'source_sha256': 'source-text-hash', 'input_hashes': {'embeddings.npy': 'vector-hash'}}
    monkeypatch.setattr(abstract_topics, 'load_abstract_topic_corpus',
        lambda *args: (papers, vectors, provenance))
    source = tmp_path / 'Clustering Abstracts.ipynb'
    source.write_text(json.dumps({'cells': [{'cell_type': 'code', 'source': ['source fit']}]}))
    model = KMeans(n_clusters=6, n_init=1, random_state=42).fit(vectors)
    km = {'model': model, 'labels': model.labels_, 'seed': 42,
          'silhouettes': silhouette_samples(cosine_distances(vectors), model.labels_, metric='precomputed')}
    leiden = {'labels': np.repeat(np.arange(1, 7), 3), 'resolution': .5, 'seed': 42, 'quality': 1.}
    destination = tmp_path / 'snapshot'
    input_id = abstract_topics.abstract_partition_input_id(keys, vectors)
    export_args = dict(kmeans_result=km, leiden_result=leiden,
        embedding_graph=similarity_graph(vectors, neighbours=2),
        fit_input_ids={name: input_id for name in abstract_topics.SOLUTIONS},
        run_dir=tmp_path, source_csv=tmp_path / 'abstracts.csv', source_notebook=source, settings={})
    abstract_topics.export_abstract_topic_partitions(destination, papers, vectors, **export_args)
    return dict(destination=destination, papers=papers, embeddings=vectors,
                provenance=provenance, source_papers=papers, export_args=export_args)


def load(fixture):
    return abstract_topics.load_abstract_topic_partitions(**{key: fixture[key] for key in (
        'destination', 'papers', 'embeddings', 'provenance')})


def change_manifest(fixture, change):
    path = fixture['destination'] / 'partition_manifest.json'
    manifest = json.loads(path.read_text())
    change(manifest)
    write_json(path, manifest)


def change_assignments(fixture, change):
    path = fixture['destination'] / 'assignments.csv'
    table = pd.read_csv(path, dtype={'paper_id': str})
    change(table).to_csv(path, index=False)
    change_manifest(fixture, lambda m: m.update(assignments_sha256=file_hash(path)))


def test_roundtrip_preserves_both_memberships_without_fitting(exported, monkeypatch):
    def forbidden(*args, **kwargs):
        raise AssertionError('Topic loading must never fit clusters')
    monkeypatch.setattr(KMeans, 'fit', forbidden)
    monkeypatch.setattr('batill.graph_clustering.leiden_partition', forbidden)
    solutions, manifest = load(exported)
    assert manifest['source_kind'] == 'abstract_text_embeddings'
    assert np.array_equal(solutions['kmeans_k6']['labels'], exported['export_args']['kmeans_result']['labels'])
    assert np.array_equal(solutions['embedding_leiden_k6']['labels'], np.repeat(np.arange(1, 7), 3))
    assert set(solutions['kmeans_k6']['labels']) == set(range(6))


def test_filtered_corpus_can_export_different_actual_cluster_counts(exported):
    """A fixed Leiden resolution need not keep six groups after subject filtering."""
    args = dict(exported['export_args'])
    vectors = exported['embeddings']
    model = KMeans(n_clusters=4, n_init=1, random_state=42).fit(vectors)
    args['kmeans_result'] = {'model': model, 'labels': model.labels_, 'seed': 42,
        'silhouettes': silhouette_samples(cosine_distances(vectors), model.labels_, metric='precomputed')}
    args['leiden_result'] = {**args['leiden_result'], 'labels': np.repeat(np.arange(1, 4), 6)}
    input_id = abstract_topics.abstract_partition_input_id(exported['papers'].paper_id, vectors)
    args['fit_input_ids'] = {name: input_id for name in ('kmeans_k4', 'embedding_leiden_k3')}
    abstract_topics.export_abstract_topic_partitions(exported['destination'],
        exported['source_papers'], vectors, **args)
    solutions, manifest = load(exported)
    assert set(solutions) == {'kmeans_k4', 'embedding_leiden_k3'}
    assert manifest['solutions']['kmeans_k4']['k'] == 4
    assert manifest['solutions']['embedding_leiden_k3']['k'] == 3
    np.testing.assert_array_equal(solutions['embedding_leiden_k3']['labels'], args['leiden_result']['labels'])


def test_assignment_rows_are_aligned_by_scopus_id_not_position(exported):
    before, _ = load(exported)
    change_assignments(exported, lambda table: table.sample(frac=1, random_state=7))
    after, _ = load(exported)
    for name in before:
        np.testing.assert_array_equal(before[name]['labels'], after[name]['labels'])


def test_missing_export_does_not_create_replacement_clusters(exported):
    (exported['destination'] / 'assignments.csv').unlink()
    with pytest.raises(FileNotFoundError, match='never creates replacement'):
        load(exported)


@pytest.mark.parametrize('mutation', ['citation', 'pdf', 'scope', 'vectors', 'checksum', 'method'])
def test_incompatible_provenance_is_rejected(exported, mutation):
    if mutation == 'citation':
        change_manifest(exported, lambda m: m.update(source_kind='direct_citations'))
    elif mutation == 'pdf':
        change_manifest(exported, lambda m: m.update(source_kind='pdf_text_embeddings'))
    elif mutation == 'scope':
        exported['provenance']['source_sha256'] = 'changed-source'
    elif mutation == 'vectors':
        exported['embeddings'] = exported['embeddings'].copy()
        exported['embeddings'][0, 0] = .9
    elif mutation == 'method':
        change_manifest(exported, lambda m: m['solutions']['embedding_leiden_k6']['graph'].update(kind='direct_citations'))
    else:
        path = exported['destination'] / 'assignments.csv'
        path.write_text(path.read_text() + '\n')
    with pytest.raises(ValueError):
        load(exported)


@pytest.mark.parametrize('mutation', ['missing', 'duplicate', 'wrong_id', 'five_clusters', 'scores'])
def test_corrupt_memberships_are_rejected_even_with_updated_file_hash(exported, mutation):
    def change(table):
        if mutation == 'missing':
            return table.iloc[1:]
        if mutation == 'duplicate':
            return pd.concat([table, table.iloc[[0]]])
        if mutation == 'wrong_id':
            table.loc[0, 'paper_id'] = 'P999'
        if mutation == 'five_clusters':
            table.loc[table.solution.eq('kmeans_k6') & table.cluster.eq(5), 'cluster'] = 4
        if mutation == 'scores':
            table.loc[0, 'cosine_silhouette'] = -.5
        return table
    change_assignments(exported, change)
    with pytest.raises(ValueError):
        load(exported)


def test_export_rejects_stale_same_size_fit(exported):
    args = dict(exported['export_args'])
    args['fit_input_ids'] = {name: 'stale' for name in abstract_topics.SOLUTIONS}
    with pytest.raises(ValueError, match='Stale abstract-text fit'):
        abstract_topics.export_abstract_topic_partitions(exported['destination'],
            exported['source_papers'], exported['embeddings'], **args)


def test_topic_notebook_contains_no_clustering_or_citation_workflow():
    notebook = Path(__file__).resolve().parents[1] / 'Topic analysis Abstracts.ipynb'
    cells = json.loads(notebook.read_text())['cells']
    code = '\n'.join(''.join(c['source']) for c in cells if c['cell_type'] == 'code')
    for forbidden in ('fit_partitions', 'KMeans(', 'leiden_sweep(', 'leiden_partition(',
                      'citation_results', 'citation_selected', 'canonical_corpus', 'load_pdf_topic', 'pdf_sha256', 'analysis_exclusions', '%run'):
        assert forbidden not in code
    assert 'load_abstract_topic_partitions(' in code


def test_abstract_evidence_has_real_ids_and_exact_source_offsets(exported):
    papers = exported['papers'].copy()
    papers['abstract'] = ['Opening text. Healthcare hospital outcomes. ' * 25] * len(papers)
    papers['embedding_text'] = papers.title + '\n\n' + papers.abstract
    solutions, _ = load(exported)
    fit = solutions['kmeans_k6']
    terms = pd.DataFrame([{'cluster': c, 'ranking': ranking, 'rank': 1, 'term': 'hospital'}
                         for c in range(6) for ranking in ('c_tf_idf', 'tfidf_contrast')])
    profiles, membership, examples = abstract_topics.describe_abstract_partition(
        papers, exported['embeddings'], fit, terms)
    assert len(profiles) == 6 and profiles.papers.sum() == len(papers)
    assert membership.paper_id.tolist() == papers.paper_id.tolist()
    np.testing.assert_array_equal(membership.cluster, fit['labels'])
    assert not {'pdf_sha256', 'source_filename', 'page', 'block_id'} & set(examples)
    for _, row in examples.iterrows():
        text = papers.set_index('paper_id').loc[row.paper_id, 'abstract']
        assert row.excerpt == text[row.excerpt_start:row.excerpt_end]
        assert row.abstract == text and len(row.excerpt) <= 600
        assert row.source_field == 'abstract' and row.term == 'hospital'


def test_names_are_invalidated_by_changed_abstract_text(exported, tmp_path):
    solutions, _ = load(exported)
    papers = exported['papers'].copy()
    fit = solutions['kmeans_k6']
    terms = pd.DataFrame([{'cluster': c, 'ranking': ranking, 'rank': 1,
                          'term': 'abstract', 'inside_count': 3, 'inside_n': 3,
                          'outside_count': 15, 'outside_n': 15}
                         for c in range(6) for ranking in ('c_tf_idf', 'tfidf_contrast')])
    profiles, _, examples = abstract_topics.describe_abstract_partition(
        papers, exported['embeddings'], fit, terms)
    for frame in (profiles, examples, terms):
        frame.insert(0, 'solution', 'kmeans_k6')
    proposals = profiles[['solution', 'cluster', 'membership_id']].copy()
    proposals['proposed_label'] = 'Recorded topic'
    proposals['status'] = 'proposed'
    destination = tmp_path / 'cards.md'
    matched = abstract_topics.write_abstract_review_cards(profiles, terms, examples, proposals, destination)
    assert matched.proposal_matched.all()
    papers.loc[0, 'embedding_text'] += ' changed content'
    changed, _, _ = abstract_topics.describe_abstract_partition(papers, exported['embeddings'], fit, terms)
    changed.insert(0, 'solution', 'kmeans_k6')
    result = abstract_topics.write_abstract_review_cards(changed, terms, examples, proposals, destination)
    assert result.proposal_matched.sum() == 5
    assert result.loc[result.cluster.eq(fit['labels'][0]), 'proposed_label'].item() == 'Name pending review'
