"""Protect abstract content and the cleaning audit's record accounting."""

import csv
from datetime import date
from pathlib import Path
import runpy

import pytest


MODULE = runpy.run_path(str(Path(__file__).resolve().parents[1] / "scripts/clean_abstracts.py"))


def test_scientific_text_is_preserved():
    text, notice = MODULE["clean_abstract"](
        "<p>M&amp;A\u00a0increased α: P <.001 and P >.05.\n"
        "No effect in non-PE firms.</p> Copyright © 2025 Publisher."
    )
    assert text == "M&A increased α: P <.001 and P >.05. No effect in non-PE firms."
    assert notice == "Copyright © 2025 Publisher."


@pytest.mark.parametrize("notice", ["Copyright: © 2024 INFORMS.", "Copyrights © 2020 by Yale.", "Copyright © Cambridge University Press 2019."])
def test_notice_prefix_is_not_left_in_analysis_text(notice):
    assert MODULE["clean_abstract"]("Investment outcomes. " + notice) == ("Investment outcomes.", notice)


def test_notice_only_is_not_an_abstract():
    notice = "Apart from any fair dealing for the purposes of research or private study, as permitted under the Copyright, Designs and Patents Act 1988. © Publisher."
    assert MODULE["clean_abstract"](notice) == ("", notice)


def test_audit_and_conservative_identity_handling(tmp_path):
    source = tmp_path / "source.csv"
    fields = [*MODULE["FIELDS"].values(), "Abstract", "References"]
    rows = []
    for eid, doi, abstract in [
        ("A", "https://doi.org/10.1234/TEST", "Investment improves outcomes. © 2025 Publisher."),
        ("B", "10.1234/test", "Investment improves outcomes. © 2026 Publisher."),
        ("C", "10.1234/test", "A different abstract about investment."),
        ("D", "", "[No abstract available]"),
    ]:
        row = dict.fromkeys(fields, "")
        row.update(EID=eid, DOI=doi, Abstract=abstract, Year="2025", Title=eid, References="x" * 150_000)
        rows.append(row)
    with source.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
    original = source.read_bytes()
    summary = MODULE["prepare"](source, tmp_path / "clean")
    assert source.read_bytes() == original
    assert summary["retained_rows"] == 1
    assert summary["exclusions"] == {"duplicate_doi": 2, "missing_abstract": 1}
    assert "shared_doi_different_abstract" not in summary["review_flags"]
    with (tmp_path / "clean/cleaning_audit.csv").open(newline="") as handle:
        audit = list(csv.DictReader(handle))
    assert len(audit) == 4
    assert audit[1]["duplicate_of"] == "A"
    assert audit[2]["duplicate_of"] == "A"
    assert audit[3]["reason"] == "missing_abstract"
    # Re-running produces the same artifacts.
    before = {p.name: p.read_bytes() for p in (tmp_path / "clean").iterdir()}
    MODULE["prepare"](source, tmp_path / "clean")
    assert before == {p.name: p.read_bytes() for p in (tmp_path / "clean").iterdir()}


def test_wrong_export_fails_before_writing(tmp_path):
    source = tmp_path / "wrong.csv"
    source.write_text("Title,Description\nExample,Text\n")
    with pytest.raises(ValueError, match="Missing Scopus columns"):
        MODULE["prepare"](source, tmp_path / "clean")
    assert not (tmp_path / "clean").exists()


def test_exclude_before_deduplication_and_keep_short_abstracts_and_errata(tmp_path):
    source = tmp_path / "source.csv"
    fields = [*MODULE["FIELDS"].values(), "Abstract"]
    year = date.today().year
    entries = [
        ("future", "10.1234/a", year + 1, "Article", "Future abstract."),
        ("retracted", "10.1234/b", year, "Retracted", "Retracted abstract."),
        ("missing", "10.1234/c", year, "Article", "[No abstract available]"),
        ("valid_a", "https://doi.org/10.1234/A", year, "Article", "Future abstract."),
        ("valid_b", "doi:10.1234/B", year, "Article", "Retracted abstract."),
        ("valid_c", "10.1234/c", year, "Article", "Brief abstract."),
        ("duplicate", "10.1234/a", year, "Article", "Different text, same DOI."),
        ("no_doi_1", "", year, "Article", "First short abstract."),
        ("no_doi_2", "", year, "Article", "Second short abstract."),
        ("erratum", "10.1234/e", year, "Erratum", "A correction."),
        ("same_text", "10.1234/z", year, "Article", "Brief abstract."),
    ]
    with source.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for eid, doi, pub_year, kind, abstract in entries:
            row = dict.fromkeys(fields, "")
            row.update(EID=eid, DOI=doi, Year=str(pub_year), Title=eid, Abstract=abstract)
            row["Document Type"] = kind
            writer.writerow(row)
    summary = MODULE["prepare"](source, tmp_path / "clean")
    assert summary["publication_year_cutoff"] == year
    assert summary["retained_rows"] == 6
    assert summary["exclusions"] == {
        "future_publication_year": 1, "retracted": 1, "missing_abstract": 1,
        "duplicate_doi": 1, "duplicate_cleaned_abstract": 1,
    }
    assert summary["review_flags"] == {"erratum": 1}
    with (tmp_path / "clean/cleaning_audit.csv").open(newline="") as handle:
        audit = {row["paper_id"]: row for row in csv.DictReader(handle)}
    assert audit["duplicate"]["duplicate_of"] == "valid_a"
    assert audit["same_text"]["duplicate_of"] == "valid_c"
    assert all(audit[key]["status"] == "kept" for key in ["valid_a", "valid_b", "valid_c", "no_doi_1", "no_doi_2", "erratum"])
