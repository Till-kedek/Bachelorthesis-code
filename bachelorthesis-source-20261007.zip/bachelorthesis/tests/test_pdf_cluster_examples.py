"""Content evidence must stay attached to its reviewed texts and memberships."""

import copy

import numpy as np
import pandas as pd
import pytest

from batill.pdf_cluster_examples import membership_id, representative_papers


@pytest.fixture
def reviewed_analysis():
    papers = pd.DataFrame({'row': range(4), 'paper_id': list('abcd'), 'title': list('ABCD'),
                           'pdf_sha256': list('ABCD'), 'text_sha256': list('1234'),
                           'source_filename': [f'{x}.pdf' for x in 'abcd']})
    labels = np.array([1, 1, 2, 2])
    passages = pd.DataFrame([{'row': i, 'page': 1, 'block_id': 'block', 'segment': 1,
                             'text': f'Private equity evidence for {pid}.'}
                            for i, pid in enumerate('abcd')])
    analysis = {'papers': papers, 'labels': labels, 'passages': passages,
                'embeddings': np.array([[1., 0.], [1., 0.], [0., 1.], [0., 1.]]),
                'membership': pd.DataFrame({'paper_id': list('abcd'), 'cosine_silhouette': [1.] * 4})}
    settings = {'source': 'saved', 'saved': 'leiden_k5', 'resolution': .95}
    review = {'solution': 'leiden_k5', 'resolution': .95,
              'membership_id': membership_id(papers, labels), 'focus': {'1': 'jobs', '2': 'funds'},
              'papers': [{**row, 'cluster': int(labels[i]),
                          'evidence': [{'page': 1, 'block_id': 'block', 'segment': 1,
                                        'excerpt': passages.iloc[i].text}]}
                         for i, row in enumerate(papers.to_dict('records'))]}
    return analysis, settings, review


def test_review_preserves_exact_papers_passages_and_excludes_self_similarity(reviewed_analysis):
    selected, evidence, diagnostics = representative_papers(*reviewed_analysis)
    assert selected.groupby('cluster').size().to_dict() == {1: 2, 2: 2}
    assert evidence.excerpt.tolist() == reviewed_analysis[0]['passages'].text.tolist()
    np.testing.assert_allclose(diagnostics.mean_within_cluster_cosine, 1)
    assert diagnostics.centrality_rank.eq(1).all()


def test_changed_partition_cannot_reuse_content_judgments(reviewed_analysis):
    analysis, settings, review = copy.deepcopy(reviewed_analysis)
    analysis['labels'] = np.array([2, 1, 1, 2])
    with pytest.raises(ValueError, match='exact saved'):
        representative_papers(analysis, settings, review)


def test_altered_quote_is_rejected_even_with_unchanged_ids(reviewed_analysis):
    analysis, settings, review = copy.deepcopy(reviewed_analysis)
    review['papers'][0]['evidence'][0]['excerpt'] = 'An unsupported result.'
    with pytest.raises(ValueError, match='passage no longer matches'):
        representative_papers(analysis, settings, review)
