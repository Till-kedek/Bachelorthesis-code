"""Behavior checks for the transparent rules defined in the screening notebook."""
import ast
import re
import unicodedata
from pathlib import Path

import nbformat
import pytest


@pytest.fixture(scope='module')
def rules():
    notebook = nbformat.read(Path(__file__).resolve().parents[1] / 'Abstract Screening.ipynb', as_version=4)
    namespace = {'re': re, 'unicodedata': unicodedata}
    matching = next(c.source for c in notebook.cells if c.cell_type == 'code' and 'def matching_text' in c.source)
    for node in ast.parse(matching).body:
        if ((isinstance(node, ast.FunctionDef) and node.name == 'matching_text')
                or (isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and
                    t.id in {'PHRASE', 'HYPHENS'} for t in node.targets))):
            exec(compile(ast.Module(body=[node], type_ignores=[]), '<notebook matching>', 'exec'), namespace)
    helper = next(c.source for c in notebook.cells if c.cell_type == 'code' and c.source.startswith('# ABSTRACT_MENTION_RULES'))
    exec(helper, namespace)
    return namespace


@pytest.mark.parametrize('text', [
    'We examine assets (private equity, real estate).',
    'We examine assets (e.g., venture capital, private equity, and hedge funds).',
    'Assets include stocks, private equity, and bonds.',
    'Assets include private equity and venture capital.',
    'Such as private equity, real estate and infrastructure.',
    'Alternative assets, which include private equity, venture capital, real estate, and infrastructure, offer diversification.',
    'Banks, private equity firms, hedge funds, and pension funds.',
    'Assets (venture capital (VC), private equity (PE), and real estate) diversify risk.',
    'Assets (PRIVATE–EQUITY; real estate).',
])
def test_detects_enumerations(rules, text):
    result = rules['abstract_mention_features'](text)
    assert result['pe_any_list_mention']
    assert all(d['list_evidence'] for d in result['details'] if d['is_list_mention'])


@pytest.mark.parametrize('text', [
    'Private equity (PE) increases productivity.',
    'We examine private equity and venture capital returns.',
    'We compare venture capital (VC) and private equity (PE) segments.',
    'Private equity, however, improves productivity.',
    'Using private equity, we examine performance and find strong effects.',
    'We examine private equity (including venture capital) and private debt. Private equity improves exports.',
    'Our topic (private equity) is relevant.',
    'Private equity firms, which invest in companies, provide financing.',
    'The paper examines firms, private equity influences exports, and findings are robust.',
    'The abstract contains no relevant phrase.',
    'Compensation of private equity fund managers typically consists of a fixed management fee and a performance-related carried interest.',
    'For-profit organisations, including private equity (PE) firms, have increasingly entered the market.',
    'Private equity funds intermediate investment and affect portfolio firm performance by actively engaging in operational, governance, and financial engineering.',
    'Using unique, detailed data on boards information sets and decisions for a large sample of private equity-backed firms.',
    'The larger the institutional distance between the portfolio company country and the private equity (PE) firm country, the lower the exit success.',
    'We examine private equity, including a literature review on venture capital relationships, buyout strategies and governance.',
])
def test_does_not_treat_comparisons_or_clauses_as_lists(rules, text):
    assert not rules['abstract_mention_features'](text)['pe_any_list_mention']


def test_any_list_mention_counts_but_evidence_preserves_other_mentions(rules):
    text = 'Private equity improves productivity. Assets include stocks, private equity, and bonds.'
    result = rules['abstract_mention_features'](text)
    assert result['pe_list_mention_count'] == 1
    assert result['pe_nonlist_mention_count'] == 1
    for detail in result['details']:
        assert rules['PHRASE'].fullmatch(text[detail['start_char']:detail['end_char']])
        if detail['is_list_mention']:
            assert text[detail['evidence_start_char']:detail['evidence_end_char']].strip() == detail['list_evidence']


def test_word_boundary_and_multiple_mentions(rules):
    analyze = rules['abstract_mention_features']
    exact = analyze('one two three four private equity')
    assert exact['pe_first_word_fraction'] == pytest.approx(2 / 3)
    assert exact['pe_only_last_third']
    assert not analyze('one two three private equity six')['pe_only_last_third']
    assert analyze('one two three four five six seven private equity')['pe_only_last_third']
    assert not analyze('private equity one two three four five six private equity')['pe_only_last_third']
    assert not analyze('No mention here.')['pe_only_last_third']
    assert analyze('one two three four private-equity')['pe_only_last_third']


def test_surviving_examples_follow_filters_and_precede_protected_title_diagnostic():
    notebook = nbformat.read(Path(__file__).resolve().parents[1] / 'Abstract Screening.ipynb', as_version=4)
    assert notebook.cells[-1].cell_type == 'code'
    assert notebook.cells[-1].source.startswith('# PROTECTED_TITLE_DIAGNOSTIC')
    inspection = next(i for i, c in enumerate(notebook.cells) if 'display(HTML(examples_html))' in c.source)
    preparation = next(i for i, c in enumerate(notebook.cells) if 'examples = needs_review.sample' in c.source)
    last_filter = next(i for i, c in enumerate(notebook.cells) if "'dropped_last_third'" in c.source)
    assert preparation > last_filter
    assert inspection > preparation and inspection < len(notebook.cells) - 1
