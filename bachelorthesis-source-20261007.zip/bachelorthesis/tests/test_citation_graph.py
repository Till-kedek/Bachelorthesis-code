"""Offline API fixtures: no real credentials, requests, PDFs or embedding inference."""
from types import SimpleNamespace

import networkx as nx
import numpy as np
import pandas as pd
import pytest
from scipy.sparse import load_npz

from batill.citation_graph import (
    citation_selection, resolve_papers, retrieve_references, export_citation_graph,
)
from batill.semantic_scholar import ScholarClient, ScholarError
from batill.storage import write_json


class Session:
    def __init__(self, responses):
        self.responses = iter(responses)
        self.headers, self.calls = {}, []

    def get(self, url, **kwargs):
        self.calls.append((url, kwargs))
        status, payload, headers = next(self.responses)
        return SimpleNamespace(status_code=status, headers=headers, json=lambda: payload)


def client(tmp_path, responses, **kwargs):
    session = Session(responses)
    sleeps = []
    api = ScholarClient('FAKE_SECRET', tmp_path, session=session,
                        sleep=sleeps.append, clock=lambda: 100., **kwargs)
    return api, session, sleeps


def test_cache_is_reusable_and_contains_no_key(tmp_path):
    api, session, _ = client(tmp_path, [(200, {'paperId': 'a'}, {})])
    assert api.paper('DOI:10.123/example')['paperId'] == 'a'
    assert len(session.calls) == 1
    api2, session2, _ = client(tmp_path, [])
    assert api2.paper('DOI:10.123/example')['paperId'] == 'a'
    assert not session2.calls
    assert api2.used_cache_files == api.used_cache_files
    assert 'FAKE_SECRET' not in next(tmp_path.glob('*.json')).read_text()
    assert session.headers['x-api-key'] == 'FAKE_SECRET'


def test_rate_limit_retry_and_auth_failure(tmp_path):
    api, session, sleeps = client(tmp_path, [(429, {}, {'Retry-After': '70'}), (200, {}, {})])
    api.paper('a')
    assert 70 in sleeps and len(session.calls) == 2
    api, session, _ = client(tmp_path / 'auth', [(401, {}, {})])
    with pytest.raises(ScholarError, match='check API key') as caught:
        api.paper('b')
    assert caught.value.status == 401 and len(session.calls) == 1
    assert not list((tmp_path / 'auth').glob('*.json'))


def test_reference_pagination_and_malformed_offsets(tmp_path):
    api, session, _ = client(tmp_path, [
        (200, {'data': [{'citedPaper': {'paperId': 'b'}}], 'next': 1}, {}),
        (200, {'data': [{'citedPaper': None}]}, {}),
    ])
    assert len(list(api.references('a'))) == 2
    assert [c[1]['params']['offset'] for c in session.calls] == [0, 1]
    api, _, _ = client(tmp_path / 'bad', [(200, {'data': [], 'next': 0}, {})])
    with pytest.raises(ScholarError, match='did not advance'):
        list(api.references('a'))


def test_rate_limit_backoff_persists_and_interrupted_run_resumes(tmp_path):
    api, session, sleeps = client(tmp_path, [
        (200, {'paperId': 'done'}, {}),
        (429, {}, {}), (429, {}, {}), (429, {}, {}),
    ], retries=2)
    api.paper('done')
    with pytest.raises(ScholarError, match='no paper was skipped') as caught:
        api.paper('pending')
    assert caught.value.status == 429
    assert sleeps.count(20) == 2
    assert 30 not in sleeps and 60 not in sleeps
    assert api.interval == 10.
    assert len(list(tmp_path.glob('*.json'))) == 1  # Never cache a 429 as missing metadata.
    resumed, session, _ = client(tmp_path, [(200, {'paperId': 'pending'}, {})])
    assert resumed.paper('done')['paperId'] == 'done'
    assert not session.calls
    assert resumed.paper('pending')['paperId'] == 'pending'
    assert len(session.calls) == 1


def test_rate_limit_keeps_slower_pace_after_success(tmp_path):
    api, _, sleeps = client(tmp_path, [
        (429, {}, {'Retry-After': '1'}), (200, {'paperId': 'a'}, {}),
        (200, {'paperId': 'b'}, {}),
    ])
    api.paper('a')
    api.paper('b')
    assert sleeps == [20, 4., 4.]
    assert api.interval == 4.


def test_live_successes_and_cache_hits_never_accelerate_requests(tmp_path):
    api, _, _ = client(tmp_path, [
        (429, {}, {}), (429, {}, {}), (429, {}, {}),
        *[(200, {'paperId': str(i)}, {}) for i in range(10)],
    ])
    api.paper('0')
    assert api.interval == 10.
    for _ in range(6):
        api.paper('0')
    assert api.interval == 10.
    intervals = []
    for i in range(1, 10):
        api.paper(str(i))
        intervals.append(api.interval)
    assert intervals == [10.] * 9


def test_new_throttling_can_slow_requests_further(tmp_path):
    api, _, _ = client(tmp_path, [
        (429, {}, {}), (200, {}, {}), (200, {}, {}),
        (429, {}, {}), (200, {}, {}),
    ])
    api.paper('a')
    api.paper('b')
    assert api.interval == 4.
    api.paper('c')
    assert api.interval == 8.


def selected():
    return pd.DataFrame([
        {'Key': 'a' * 64, 'paper_id': 'P001', 'query_title': 'Private equity and firm performance',
         'query_year': '2020', 'doi': '10.123/a'},
        {'Key': 'b' * 64, 'paper_id': 'P002', 'query_title': 'Buyouts and the labour market',
         'query_year': '2021', 'doi': ''},
        {'Key': 'c' * 64, 'paper_id': 'P003', 'query_title': 'Governance in private equity funds',
         'query_year': '2022', 'doi': ''},
    ])


class PapersAPI:
    used_cache_files = set()

    def __init__(self):
        self.candidates = {
            'a': {'paperId': 'a', 'title': 'Private equity and firm performance', 'year': 2020,
                  'externalIds': {'DOI': '10.123/a'}, 'referenceCount': 5},
            'b': {'paperId': 'b', 'title': 'Buyouts and the labour market', 'year': 2021, 'referenceCount': 0},
            'c': {'paperId': 'c', 'title': 'A completely different study', 'year': 2022},
        }

    def paper(self, identifier):
        return self.candidates.get(identifier.split('/')[-1])

    def search(self, title):
        if title.startswith('Buyouts'):
            return [self.candidates['b']]
        return [self.candidates['c']]

    def references(self, identifier):
        if identifier == 'a':
            yield [{'citedPaper': {'paperId': 'b', 'title': 'Buyouts'}},
                   {'citedPaper': {'paperId': 'b', 'title': 'Buyouts'}},
                   {'citedPaper': {'paperId': 'outside'}}]
            yield [{'citedPaper': None}, {'citedPaper': {'paperId': 'a'}}]
        else:
            yield []


def test_match_review_manual_override_and_conflicting_doi(tmp_path):
    api, papers = PapersAPI(), selected()
    matches = resolve_papers(api, papers, tmp_path)
    assert matches.approved.tolist() == [True, True, False]
    matches = resolve_papers(api, papers, tmp_path, overrides={'P003': 'c'}, auto_accept=False)
    assert matches.approved.tolist() == [False, False, True]
    matches = resolve_papers(api, papers, tmp_path, overrides={'P003': None})
    assert matches.iloc[2].match_status == 'manually_unmatched'
    api.candidates['a']['externalIds']['DOI'] = '10.123/different'
    matches = resolve_papers(api, papers, tmp_path)
    assert not matches.iloc[0].approved  # Same title/year cannot override a conflicting DOI.


def test_duplicate_indexed_identities_require_review(tmp_path):
    matches = resolve_papers(PapersAPI(), selected(), tmp_path, overrides={'P003': 'a'})
    assert matches.approved.tolist() == [False, True, False]
    assert matches.iloc[0].match_status == 'duplicate_s2_identity_review_required'
    with pytest.raises(ValueError, match='Unknown'):
        resolve_papers(PapersAPI(), selected(), tmp_path, overrides={'P999': 'a'})


def test_directed_graph_excludes_external_edges_keeps_unmatched_nodes(tmp_path):
    api, papers = PapersAPI(), selected()
    matches = resolve_papers(api, papers, tmp_path)
    status, refs = retrieve_references(api, papers, matches, tmp_path)
    nodes, edges, graph, summary = export_citation_graph(
        papers, matches, status, refs, tmp_path, {'selection_id': 'test'}, api)
    assert list(graph.edges) == [('a' * 64, 'b' * 64)]
    assert summary['selected_papers'] == 3 and summary['approved_matches'] == 2
    assert summary['reference_records_without_id'] == 1
    assert summary['isolated_nodes_in_observed_graph'] == 1
    assert status.iloc[0].reference_records == 5 and not status.iloc[0].reported_count_differs
    assert nodes.citations_received_within_selection.tolist() == [0, 1, 0]
    assert edges[['source_paper', 'target_paper']].values.tolist() == [['P001', 'P002']]
    np.testing.assert_array_equal(load_npz(tmp_path / 'adjacency.npz').toarray(),
                                  [[0, 1, 0], [0, 0, 0], [0, 0, 0]])
    assert nx.read_graphml(tmp_path / 'citation_graph.graphml').is_directed()
    with pytest.raises(ValueError, match='current selection'):
        export_citation_graph(papers.iloc[::-1], matches, status, refs, tmp_path, {}, api)


def test_reference_failure_preserves_partial_coverage(tmp_path):
    api, papers = PapersAPI(), selected()
    matches = resolve_papers(api, papers, tmp_path)

    def partial(identifier):
        yield [{'citedPaper': {'paperId': 'b'}}]
        raise ScholarError(0, 'Connection failed')

    api.references = partial
    status, refs = retrieve_references(api, papers, matches, tmp_path)
    assert status.status.tolist() == ['incomplete_http_0', 'incomplete_http_0']
    assert len(refs) == 2 and status.reference_records.tolist() == [1, 1]


def test_selection_uses_hash_exclusions_and_exact_bibliography(tmp_path):
    folder = tmp_path / 'embeddings'
    folder.mkdir()
    rows = [{'pdf_sha256': c * 64, 'title': 'Bad extracted title',
             'source_filename': f'Smith - 2020 - Private equity and firm performance{suffix}.pdf'}
            for c, suffix in [('a', ''), ('b', ' excluded')]]
    write_json(folder / 'manifest.json', {'rows': rows})
    np.savez(folder / 'embeddings.npz', embeddings=np.ones((2, 3)), pdf_sha256=[r['pdf_sha256'] for r in rows])
    exclusions = tmp_path / 'exclusions.json'
    write_json(exclusions, {'schema_version': 1, 'papers': [
        {'pdf_sha256': 'b' * 64, 'exclude': True, 'reason': 'scope'}]})
    bib = tmp_path / 'bib.csv'
    pd.DataFrame([{'Title': 'Private Equity and Firm Performance', 'DOI': 'https://doi.org/10.123/ABC',
                   'Publication Year': '2020'}]).to_csv(bib, index=False)
    papers, audit, selection = citation_selection(tmp_path, exclusions, [bib])
    assert papers.paper_id.tolist() == ['P001'] and selection['retained_papers'] == 1
    assert papers.iloc[0].doi == '10.123/abc'
    assert papers.iloc[0].query_title == 'Private Equity and Firm Performance'
    assert papers.iloc[0].query_year == '2020'
