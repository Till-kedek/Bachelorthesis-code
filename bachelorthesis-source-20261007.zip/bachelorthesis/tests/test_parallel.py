"""Synthetic worker tests: no GPUs, model downloads or project output writes."""
from concurrent.futures import ThreadPoolExecutor
from dataclasses import asdict
import os
from pathlib import Path
import subprocess
import sys
from types import SimpleNamespace

import numpy as np
import pytest

from batill import parallel
from batill.embedding import EmbeddingConfig, RuntimeConfig
from batill.pipeline import validate_outputs
from batill.storage import fingerprint, read_json, write_json


def plans_for(count):
    plans = []
    config = asdict(EmbeddingConfig(embedding_dimension=2))
    for index in range(count):
        segments = [{'text': 'x' * (5 + (index * 37 + s) % 200),
                     'token_count': 5 + (index * 37 + s) % 200,
                     'content_tokens': 5 + (index * 37 + s) % 200,
                     'sources': []} for s in range(1 + index % 3)]
        plan = {'pipeline_version': 3, 'pdf_sha256': f'pdf-{index}', 'Key': None,
                'source_filename': f'{index}.pdf', 'title': f'Paper {index}',
                'config': config, 'segments': segments}
        plan['id'] = fingerprint(plan)
        plans.append(plan)
    return plans


def save_inputs(root, plans):
    for plan in plans:
        write_json(root / 'prepared/inputs' / f"{plan['id']}.json", plan)
    write_json(root / 'prepared/manifest.json', {
        'inputs': [f"inputs/{p['id']}.json" for p in plans],
        'corpus_id': fingerprint([p['id'] for p in plans])})


@pytest.fixture
def fake_models(monkeypatch):
    loads = []
    def load(config, runtime=None):
        loads.append(runtime)
        return SimpleNamespace(
            tokenizer=SimpleNamespace(encode=lambda text, **kw: list(text)),
            max_seq_length=32768, _batill_embedding_config=asdict(config),
            _batill_runtime=asdict(runtime),
            encode=lambda texts, **kw: np.array([[0.6, 0.8] for _ in texts]))
    monkeypatch.setattr(parallel, 'load_model', load)
    monkeypatch.setattr('batill.embedding.version', lambda package: 'synthetic')
    monkeypatch.setitem(sys.modules, 'torch', SimpleNamespace(cuda=SimpleNamespace(device_count=lambda: 1)))
    return loads


def test_three_hundred_papers_assigned_once_deterministically():
    plans = plans_for(300)
    part = parallel.partition_papers(plans, 4)
    assert part == parallel.partition_papers(plans, 4)
    flattened = [key for group in part['assignments'] for key in group]
    assert len(flattened) == len(set(flattened)) == 300
    assert set(flattened) == {p['id'] for p in plans}
    costs = [sum(s['token_count'] for s in p['segments']) for p in plans]
    assert max(part['estimated_tokens']) - min(part['estimated_tokens']) <= max(costs)
    for group in part['assignments']:
        assert group == [p['id'] for p in plans if p['id'] in group]


def test_concurrent_workers_merge_and_cached_restart(tmp_path, fake_models):
    plans = plans_for(12)
    save_inputs(tmp_path, plans)
    parallel.prepare_workers(tmp_path, 4)
    # Simultaneous workers exercise isolated files. Model calls use tiny fake vectors.
    with ThreadPoolExecutor(max_workers=4) as pool:
        list(pool.map(lambda i: parallel.run_worker(tmp_path, 4, i, RuntimeConfig()), range(4)))
    assert len(fake_models) == 4
    assert not (tmp_path / 'embeddings').exists()  # Workers cannot publish a partial corpus.
    parallel.merge_workers(tmp_path, 4)
    assert validate_outputs(tmp_path)['papers'] == 12
    with np.load(tmp_path / 'embeddings/embeddings.npz', allow_pickle=False) as z:
        assert z['pdf_sha256'].tolist() == [p['pdf_sha256'] for p in plans]
    for worker in range(4):
        parallel.run_worker(tmp_path, 4, worker, RuntimeConfig())
    assert len(fake_models) == 4  # Complete caches require no model loads.


def test_missing_or_corrupt_worker_never_publishes(tmp_path, fake_models):
    plans = plans_for(4)
    save_inputs(tmp_path, plans)
    part = parallel.prepare_workers(tmp_path, 4)
    for worker in range(3):
        parallel.run_worker(tmp_path, 4, worker, RuntimeConfig())
    with pytest.raises(FileNotFoundError):
        parallel.merge_workers(tmp_path, 4)
    assert not (tmp_path / 'embeddings').exists()
    parallel.run_worker(tmp_path, 4, 3, RuntimeConfig())
    path = tmp_path / 'parallel' / part['id'] / 'worker-3/papers' / f"{part['assignments'][3][0]}.json"
    payload = read_json(path)
    payload['paper_vector'] = [1, 0]
    write_json(path, payload)
    with pytest.raises(ValueError, match='aggregation'):
        parallel.merge_workers(tmp_path, 4)
    assert not (tmp_path / 'embeddings').exists()


def test_empty_workers_do_not_load_models(tmp_path, fake_models):
    save_inputs(tmp_path, plans_for(1))
    parallel.prepare_workers(tmp_path, 4)
    for worker in range(4):
        parallel.run_worker(tmp_path, 4, worker, RuntimeConfig())
    assert len(fake_models) == 1
    parallel.merge_workers(tmp_path, 4)
    assert validate_outputs(tmp_path)['papers'] == 1


def test_worker_rejects_multiple_visible_gpus(tmp_path, fake_models, monkeypatch):
    save_inputs(tmp_path, plans_for(1))
    part = parallel.prepare_workers(tmp_path, 1)
    monkeypatch.setitem(sys.modules, 'torch', SimpleNamespace(cuda=SimpleNamespace(device_count=lambda: 4)))
    with pytest.raises(RuntimeError, match='exactly one'):
        parallel.run_worker(tmp_path, 1, 0, RuntimeConfig())
    assert not fake_models
    assert not (tmp_path / 'parallel' / part['id'] / 'worker-0/complete.json').exists()


def test_launcher_assigns_distinct_visible_devices(tmp_path, monkeypatch):
    save_inputs(tmp_path, plans_for(4))
    monkeypatch.setitem(sys.modules, 'torch', SimpleNamespace(cuda=SimpleNamespace(device_count=lambda: 4)))
    monkeypatch.setenv('CUDA_VISIBLE_DEVICES', 'GPU-a,GPU-b,GPU-c,GPU-d')
    captured = []
    monkeypatch.setattr(parallel, '_launch_commands', lambda cmds, envs, logs: captured.append((cmds, envs)))
    monkeypatch.setattr(parallel, 'merge_workers', lambda *args: 'merged')
    assert parallel.embed_parallel(tmp_path, workers=4) == 'merged'
    commands, environments = captured[0]
    assert [env['CUDA_VISIBLE_DEVICES'] for env in environments] == ['GPU-a', 'GPU-b', 'GPU-c', 'GPU-d']
    assert [cmd[cmd.index('--worker-index') + 1] for cmd in commands] == ['0', '1', '2', '3']


def test_real_lightweight_child_processes_receive_isolated_environments(tmp_path):
    commands = [[sys.executable, '-c', 'import os; print(os.environ["CUDA_VISIBLE_DEVICES"])'] for _ in range(4)]
    envs = [dict(os.environ, CUDA_VISIBLE_DEVICES=str(i)) for i in range(4)]
    paths = [tmp_path / f'{i}.log' for i in range(4)]
    parallel._launch_commands(commands, envs, paths)
    assert [p.read_text().strip() for p in paths] == ['0', '1', '2', '3']


def test_child_failure_terminates_peers(tmp_path, monkeypatch):
    real_popen = subprocess.Popen
    processes = []
    def capture(*a, **kw):
        process = real_popen(*a, **kw)
        processes.append(process)
        return process
    monkeypatch.setattr(parallel.subprocess, 'Popen', capture)
    commands = [[sys.executable, '-c', 'raise SystemExit(3)'],
                [sys.executable, '-c', 'import time; time.sleep(30)']]
    with pytest.raises(RuntimeError, match='worker failed'):
        parallel._launch_commands(commands, [dict(os.environ)] * 2, [tmp_path / 'a.log', tmp_path / 'b.log'])
    assert all(p.poll() is not None for p in processes)


@pytest.mark.parametrize('workers', [0, -1, True, 1.5])
def test_invalid_worker_counts(workers):
    with pytest.raises(ValueError, match='positive integer'):
        parallel.partition_papers(plans_for(3), workers)
