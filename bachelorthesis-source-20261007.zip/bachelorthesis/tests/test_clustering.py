"""Synthetic hierarchy checks, independent of corpus results and notebook execution."""
import numpy as np
import pytest

pytest.importorskip('scipy')
from scipy.cluster.hierarchy import fcluster
from batill.clustering import cosine_hierarchy, plot_hierarchy
from batill.clustering import cluster_hierarchy, hierarchy_tables, plot_cluster_hierarchy


def test_cosine_average_linkage_and_leaf_order():
    x = np.array([[1., 0.], [1., .03], [0., 1.], [.02, 1.]])
    original = x.copy()
    h = cosine_hierarchy(x)
    np.testing.assert_array_equal(x, original)
    assert sorted(h['order']) == list(range(4))
    np.testing.assert_allclose(h['distance'], 1 - h['similarity'], atol=1e-12)
    groups = fcluster(h['linkage'], t=.1, criterion='distance')
    assert groups[0] == groups[1] and groups[2] == groups[3] and groups[0] != groups[2]
    ordered_groups = groups[h['order']]
    assert np.count_nonzero(np.diff(ordered_groups)) == 1
    # With two leaves per group, the final average-linkage merge is the mean
    # of the four cross-group cosine distances.
    np.testing.assert_allclose(h['linkage'][-1, 2], h['distance'][:2, 2:].mean())


def test_plot_uses_identical_tree_and_matrix_coordinates():
    pytest.importorskip('matplotlib')
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    h = cosine_hierarchy(np.array([[1., 0.], [.9, .1], [0., 1.], [.1, .9]]))
    fig, axes = plot_hierarchy(h, ['P1', 'P2', 'P3', 'P4'], cut_distance=.2)
    try:
        fig.canvas.draw()
        a, b = axes['dendrogram'].get_position(), axes['heatmap'].get_position()
        np.testing.assert_allclose([a.x0, a.x1], [b.x0, b.x1], atol=1e-5)
        actual = axes['heatmap'].images[0].get_array()
        expected = h['similarity'][np.ix_(h['order'], h['order'])]
        np.testing.assert_allclose(actual.data, expected)
        assert np.array_equal(actual.mask, np.eye(4, dtype=bool))
        assert axes['heatmap'].images[0].get_clim() == (-1, 1)
        labels = [t.get_text() for t in axes['heatmap'].get_xticklabels()]
        assert labels == [f'P{i+1}' for i in h['order']]
    finally:
        plt.close(fig)


@pytest.mark.parametrize('x', [np.zeros((2, 3)), np.ones((1, 3)), np.array([[1, 0], [np.nan, 1]])])
def test_invalid_embeddings_rejected(x):
    with pytest.raises(ValueError):
        cosine_hierarchy(x)


def test_cluster_pair_means_representatives_and_contracted_tree():
    import pandas as pd
    from scipy.cluster.hierarchy import leaves_list
    h = cosine_hierarchy(np.array([[1., 0.], [1., .03], [0., 1.], [.02, 1.], [-1., 0.]]))
    c = cluster_hierarchy(h, max_clusters=3)
    assert len(c['members']) == 3
    np.testing.assert_array_equal(leaves_list(c['linkage']), np.arange(3))
    for i, a in enumerate(c['members']):
        for j, b in enumerate(c['members']):
            scores = [h['similarity'][x, y] for x in a for y in b if x != y]
            if scores:
                assert c['similarity'][i, j] == pytest.approx(np.mean(scores))
            else:
                assert np.isnan(c['similarity'][i, j])
    np.testing.assert_allclose(c['linkage'][:, 2], h['linkage'][-2:, 2])
    papers = pd.DataFrame({'Paper ID': [f'P{i}' for i in range(5)], 'Key': range(5),
                           'Title': [f'Title {i}' for i in range(5)],
                           'source_filename': ['example.pdf'] * 5, 'segments': [2] * 5})
    summary, membership = hierarchy_tables(h, c, papers)
    assert summary['Papers'].sum() == 5
    for i, members in enumerate(c['members']):
        assert all(f'P{j}: Title {j}' in summary.iloc[i]['Representative papers'] for j in members)
        assert set(membership.loc[membership.Cluster == f'C{i+1}', 'Key']) == set(members)


@pytest.mark.parametrize('k', [1, 3, 20])
def test_cluster_plot_handles_singletons_and_single_cluster(k):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    h = cosine_hierarchy(np.array([[1., 0.], [1., .03], [0., 1.], [.02, 1.], [-1., 0.]]))
    c = cluster_hierarchy(h, max_clusters=k)
    fig, axes = plot_cluster_hierarchy(c)
    try:
        fig.canvas.draw()
        np.testing.assert_allclose(axes['heatmap'].images[0].get_array().filled(np.nan),
                                   c['similarity'], equal_nan=True)
        expected = [f'C{i+1} (n={s})' for i, s in enumerate(c['sizes'])]
        assert [x.get_text() for x in axes['heatmap'].get_xticklabels()] == expected
        a, b = axes['dendrogram'].get_position(), axes['heatmap'].get_position()
        np.testing.assert_allclose([a.x0, a.x1], [b.x0, b.x1], atol=1e-5)
    finally:
        plt.close(fig)


def test_tied_cut_merges_are_not_arbitrarily_split():
    h = cosine_hierarchy(np.ones((5, 2)))
    c = cluster_hierarchy(h, max_clusters=3)
    assert len(c['members']) == 1
    assert c['similarity'][0, 0] == pytest.approx(1)
    with pytest.raises(ValueError):
        cluster_hierarchy(h, max_clusters=0)


def test_copyable_review_lists_all_small_members_and_three_large_representatives():
    import pandas as pd
    from batill.clustering import cluster_review_report
    summary = pd.DataFrame([
        {'Cluster': 'C1', 'Papers': 1, 'Representative papers': 'P0: Solo'},
        {'Cluster': 'C2', 'Papers': 2, 'Representative papers': 'P1: Pair A'},
        {'Cluster': 'C3', 'Papers': 4, 'Representative papers': 'P3: Main A\nP4: Main B\nP5: Main C'},
    ])
    members = pd.DataFrame({'Cluster': ['C1', 'C2', 'C2', 'C3', 'C3', 'C3', 'C3'],
        'Paper ID': [f'P{i}' for i in range(7)],
        'Title': ['Solo', 'Pair A', 'Pair B', 'Main A', 'Main B', 'Main C', 'Peripheral']})
    report = cluster_review_report(summary, members)
    assert 'P2: Pair B' in report and 'P0: Solo' in report
    assert 'C3 — 4 paper(s)' in report and 'P5: Main C' in report
    assert 'Peripheral' not in report
    assert 'not confirmed outliers' in report


def test_kmeans_selection_plot_preserves_scores_and_equal_axis_scales():
    import pandas as pd
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from batill.clustering import plot_kmeans_selection
    pdfs = pd.DataFrame({'k': [5, 3, 4], 'silhouette_best_fit': [.178, .207, .189],
                         'silhouette_mean': [.182, .208, .192]})
    abstracts = pd.DataFrame({'k': [3, 4, 5], 'silhouette_best_fit': [.05, .04, .06],
                              'silhouette_mean': [.06, .045, .058]})
    fig, axes = plot_kmeans_selection({'PDFs': pdfs, 'Abstracts': abstracts}, selected_k=5)
    np.testing.assert_array_equal(axes['best_fit'].lines[0].get_ydata(), [.207, .189, .178])
    np.testing.assert_array_equal(axes['mean'].lines[0].get_ydata(), [.208, .192, .182])
    np.testing.assert_array_equal(axes['mean'].lines[1].get_ydata(), [.06, .045, .058])
    assert axes['best_fit'].get_ylim() == axes['mean'].get_ylim()
    axes['mean'].set_ylim(-.1, .5)
    assert axes['best_fit'].get_ylim() == axes['mean'].get_ylim()
    assert any('5 clusters' in t.get_text() for t in axes['best_fit'].texts)
    plt.close(fig)
    with pytest.raises(ValueError, match='was not tested'):
        plot_kmeans_selection({'PDFs': pdfs}, selected_k=6)
