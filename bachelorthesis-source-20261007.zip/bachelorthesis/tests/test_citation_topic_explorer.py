"""Saved citation selection, graph provenance, and isolate-aware term evidence."""

import numpy as np
import pandas as pd
import pytest

from batill.citation_clustering import citation_network
from batill.citation_topic_explorer import (
    _saved_sweep, analyse_partition, choose_partition, export_analysis,
    load_context, partition_catalog, search_expression, supporting_papers,
)
from batill.storage import fingerprint, read_json, write_json


@pytest.fixture
def source(tmp_path):
    # An isolate first tests remapping passage rows after removing it from contrasts.
    nodes = pd.DataFrame({'Key': list('gabcdef'), 'paper_id': [f'P{i}' for i in range(7)],
                          'query_title': [f'Paper {i}' for i in range(7)]})
    edges = pd.DataFrame([('a', 'b'), ('a', 'c'), ('b', 'c'),
                          ('d', 'e'), ('d', 'f'), ('e', 'f')],
                         columns=['source_key', 'target_key'])
    papers = nodes.rename(columns={'Key': 'pdf_sha256', 'query_title': 'title'}).copy()
    papers['text'] = ['isolated zebra'] + ['hospital care'] * 3 + ['fund returns'] * 3
    papers['text_sha256'] = papers.text.map(fingerprint)
    passages = pd.DataFrame({'row': np.arange(7), 'page': 2, 'block_id': 'body',
                             'source_start': 0, 'text': papers.text})
    corpus = {'papers': papers, 'passages': passages, 'nodes': nodes,
              'network': citation_network(nodes, edges), 'input_id': 'current',
              'selection': {'selection_id': 'scope'},
              'input_hashes': {'graph/nodes.csv': 'graph-hash',
                               'embeddings/manifest.json': 'text-hash'}}
    sweep = tmp_path / 'outputs/citation_clustering/scope/with_manual'
    sweep.mkdir(parents=True)
    labels = np.array([0, 1, 1, 1, 2, 2, 2])
    rows = [dict(resolution=.9000000000000002, seed=seed, Key=node.Key,
                 paper_id=node.paper_id, citation_label=int(labels[i]))
            for seed in [42, 43, 44] for i, node in enumerate(nodes.itertuples())]
    # Input row order may differ; identity alignment must preserve the saved IDs.
    pd.DataFrame(rows).iloc[::-1].to_csv(sweep / 'all_seed_memberships.csv', index=False)
    pd.DataFrame([{'resolution': .9000000000000002, 'communities': 2,
                   'unassigned_isolates': 1, 'selected_seed': 42,
                   'modularity_gamma_1': .5, 'within_community_link_fraction': 1.,
                   'seed_stability_ARI_mean': 1.}]).to_csv(sweep / 'resolution_sweep.csv', index=False)
    provenance = sweep / 'resolution_1/leiden_0.95/run_manifest.json'
    write_json(provenance, {'selection_id': 'scope', 'include_manual_citations': True,
        'citation_graph_rule': 'binary undirected union; isolates unassigned',
        'embedding_manifest_sha256': 'text-hash', 'graph_files': {'nodes.csv': 'graph-hash'},
        'citation_seeds': [42, 43, 44], 'citation_resolution_sweep': [.9000000000000002]})
    return corpus, sweep, provenance


def test_saved_catalog_roundtrip_without_clustering(tmp_path, source, monkeypatch):
    corpus, _, _ = source

    def forbidden(*args, **kwargs):
        raise AssertionError('Saved citation loading must not fit any communities')

    monkeypatch.setattr('batill.citation_topic_explorer.load_citation_topic_corpus', lambda *a, **k: corpus)
    monkeypatch.setattr('batill.citation_topic_explorer.citation_leiden_sweep', forbidden)
    monkeypatch.setattr('leidenalg.find_partition', forbidden)
    context = load_context(tmp_path)
    catalog = partition_catalog(context)
    assert catalog.solution.tolist() == ['citation_r0.9']
    assert catalog.assigned.tolist() == [6] and catalog.unassigned.tolist() == [1]
    labels, settings = choose_partition(context)
    np.testing.assert_array_equal(labels, [0, 1, 1, 1, 2, 2, 2])
    labels[1] = 2
    assert context['solutions']['citation_r0.9']['labels'][1] == 1
    snapshot = context['evidence'] / 'resolution_0.9/assignments.csv'
    before = snapshot.read_bytes()
    loaded = load_context(tmp_path)
    assert snapshot.read_bytes() == before
    labels, _ = choose_partition(loaded)
    analysis = analyse_partition(loaded, labels, min_df=2)
    destination = export_analysis(analysis, loaded, settings)
    manifest = read_json(destination / 'run_manifest.json')
    assert manifest['partition_settings']['resolution'] == .9
    assert manifest['partition_settings']['source'] == 'saved'
    assert pd.read_csv(destination / 'membership.csv').cluster.tolist() == labels.tolist()


@pytest.mark.parametrize('field,value', [('communities', 3), ('selected_seed', 99),
                                       ('modularity_gamma_1', .8), ('seed_stability_ARI_mean', .5)])
def test_changed_sweep_diagnostics_are_rejected(source, field, value):
    corpus, sweep, provenance = source
    path = sweep / 'resolution_sweep.csv'
    rows = pd.read_csv(path)
    rows.loc[0, field] = value
    rows.to_csv(path, index=False)
    with pytest.raises(ValueError, match='diagnostics or selected seed'):
        _saved_sweep(corpus, sweep, provenance)


def test_graph_provenance_change_is_rejected(source):
    corpus, sweep, provenance = source
    corpus['input_hashes']['graph/nodes.csv'] = 'different'
    with pytest.raises(ValueError, match='graph or input scope'):
        _saved_sweep(corpus, sweep, provenance)


def test_isolates_are_excluded_from_search_but_preserved_in_membership(source):
    corpus, _, _ = source
    labels = np.array([0, 1, 1, 1, 2, 2, 2])
    analysis = analyse_partition(corpus, labels, min_df=2)
    assert analysis['membership'].cluster.tolist() == labels.tolist()
    assert analysis['unassigned'].paper_id.tolist() == ['P0']
    assert 'zebra' not in analysis['vocabulary']['terms']
    assert set(analysis['terms'].inside_n + analysis['terms'].outside_n) == {6}
    assert search_expression(analysis, 'hospital care')['Papers containing term'].tolist() == [3, 0]
    support = supporting_papers(analysis, 'hospital care', 1)
    assert support.paper_id.tolist() == ['P1', 'P2', 'P3']
    assert support.page.eq(2).all()
    assert not analysis['examples'].selection.str.contains('boundary').any()
