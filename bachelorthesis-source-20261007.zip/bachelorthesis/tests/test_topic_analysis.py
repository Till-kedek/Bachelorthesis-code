"""Small numerical checks for the topic evidence, without corpus or model downloads."""
import numpy as np
import pandas as pd
import pytest

from batill.topic_analysis import term_analyzer, build_vocabulary, topic_terms, partition_agreement, describe_partition, write_review_cards


def test_phrases_are_contiguous_and_stopwords_do_not_bridge():
    terms = list(term_analyzer('Private-equity funds in markets. Hospital care [FORMULA] 12 patients.'))
    assert 'private equity' in terms and 'hospital care' in terms
    assert 'funds markets' not in terms and 'markets hospital' not in terms
    assert 'formula' not in terms and 'care patients' not in terms


def test_term_scores_and_prevalence_match_hand_computation():
    papers = pd.DataFrame({'text': ['hospital care hospital', 'hospital care',
                                   'fund returns fund', 'fund returns']})
    vocabulary = build_vocabulary(papers, min_df=2, max_df=1.0)
    labels = np.array([1, 1, 2, 2])
    result = topic_terms(vocabulary, labels)
    row = result[(result.cluster == 1) & (result.ranking == 'c_tf_idf') & (result.term == 'hospital')].iloc[0]
    counts = vocabulary['counts'].toarray()
    column = list(vocabulary['terms']).index('hospital')
    total = counts[:2].sum()
    expected = counts[:2, column].sum() / total * np.log1p((counts.sum() / 2) / counts[:, column].sum())
    assert np.isclose(row.score, expected)
    assert row.inside_count == 2 and row.outside_count == 0
    assert row.inside_prevalence == 1 and row.prevalence_gap == 1
    contrast = result[(result.cluster == 1) & (result.ranking == 'tfidf_contrast') & (result.term == 'hospital')].iloc[0]
    assert np.isclose(contrast.score, vocabulary['tfidf'][:2, column].mean() - vocabulary['tfidf'][2:, column].mean())


def test_comparison_is_label_invariant():
    stats, matrix = partition_agreement([0, 0, 1, 1], [7, 7, 2, 2])
    assert stats['ARI'] == 1 and stats['matched_fraction'] == 1
    assert matrix.to_numpy().sum() == 4


def test_abstract_support_can_include_specific_phrases_without_changing_pdf_default():
    papers = pd.DataFrame({'text': ['hospital care'] * 3 + ['medical research'] * 47
                          + ['fund returns'] * 50})
    vocabulary = build_vocabulary(papers, min_df=3, max_df=.9)
    labels = np.array([0] * 50 + [1] * 50)
    strict = topic_terms(vocabulary, labels)
    relaxed = topic_terms(vocabulary, labels, min_cluster_fraction=0.0)
    assert 'hospital care' not in set(strict.term)
    rows = relaxed.loc[(relaxed.cluster == 0) & (relaxed.term == 'hospital care')]
    assert set(rows.ranking) == {'tfidf_contrast', 'c_tf_idf'}
    assert rows.inside_count.eq(3).all() and rows.inside_n.eq(50).all()
    assert rows.score.gt(0).all()


def test_evidence_matches_whole_terms_not_substrings():
    papers = pd.DataFrame({'paper_id': ['P1', 'P2', 'P3', 'P4'], 'pdf_sha256': list('abcd'),
        'title': ['Paper'] * 4, 'text': ['unused'] * 4})
    passage_rows = []
    for row in range(4):
        for block, text in [('a', 'background ' * 15), ('b', 'The first round of financing. ' * 8)]:
            passage_rows.append({'row': row, 'segment': 1, 'page': 1, 'block_id': block,
                                 'source_start': 0, 'text': text})
    terms = pd.DataFrame([{'cluster': c, 'ranking': rank, 'rank': 1, 'term': 'round'}
                          for c in (1, 2) for rank in ('tfidf_contrast', 'c_tf_idf')])
    _, _, examples = describe_partition(papers, np.array([[1., 0.], [1., 0.], [0., 1.], [0., 1.]]),
        pd.DataFrame(passage_rows), {'labels': np.array([1, 1, 2, 2]), 'silhouettes': np.ones(4)}, terms)
    assert set(examples.block_id) == {'b'}
    assert examples.excerpt.str.contains('round of financing').all()


def test_manual_names_cannot_attach_to_changed_memberships(tmp_path):
    profiles = pd.DataFrame([{'solution': 'kmeans_k2', 'cluster': 1, 'membership_id': 'current'}])
    proposals = pd.DataFrame([{'solution': 'kmeans_k2', 'cluster': 1, 'membership_id': 'old',
                              'proposed_label': 'Healthcare', 'status': 'provisional'}])
    with pytest.raises(ValueError, match='do not match'):
        write_review_cards(profiles, pd.DataFrame(), pd.DataFrame(), proposals, tmp_path / 'cards.md')


@pytest.mark.parametrize('label', ['', '   ', None])
def test_blank_name_is_not_a_matched_proposal(tmp_path, label):
    proposals = pd.DataFrame([{'solution': 'kmeans_k5', 'cluster': 0,
        'membership_id': 'current', 'proposed_label': label, 'status': 'provisional'}])
    with pytest.raises(ValueError, match='nonempty name'):
        write_review_cards(pd.DataFrame(), pd.DataFrame(), pd.DataFrame(),
                           proposals, tmp_path / 'cards.md', allow_unmatched=True)


def test_changed_membership_gets_review_card_without_old_name(tmp_path):
    profiles = pd.DataFrame([{'solution': 'leiden_k3', 'cluster': 1,
        'membership_id': 'current', 'papers': 2, 'mean_silhouette': 0.2,
        'negative_fraction': 0.0, 'ctfidf_terms': 'fund', 'contrast_terms': 'returns',
        'representatives': 'P1: Fund returns'}])
    proposals = pd.DataFrame([{'solution': 'leiden_k3', 'cluster': 1,
        'membership_id': 'old', 'proposed_label': 'Old topic', 'status': 'provisional'}])
    terms = pd.DataFrame([{'solution': 'leiden_k3', 'cluster': 1,
        'ranking': 'tfidf_contrast', 'rank': 1, 'term': 'returns',
        'inside_count': 2, 'inside_n': 2, 'outside_count': 0, 'outside_n': 2}])
    papers = pd.DataFrame(columns=['solution', 'cluster', 'selection'])
    destination = tmp_path / 'cards.md'

    result = write_review_cards(profiles, terms, papers, proposals, destination,
                                allow_unmatched=True)

    assert not result.proposal_matched.iloc[0]
    assert result.proposed_label.iloc[0] == 'Name pending review'
    card = destination.read_text()
    assert 'Name pending review' in card
    assert 'Old topic' not in card
