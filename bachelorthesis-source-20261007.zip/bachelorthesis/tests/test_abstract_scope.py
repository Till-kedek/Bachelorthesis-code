"""Protect subject screening and the ID-aligned handoff to existing analysis."""
import json
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

from batill.abstract_clustering import load_abstract_embeddings
from batill.abstract_scope import (
    ACTIVE_CONFIG, OVERRIDE_COLUMNS, activate_scope, build_scope_bundle,
    export_review_workbook, resolve_abstract_inputs, screen_abstracts,
)
from batill.storage import file_hash


@pytest.fixture
def rules():
    return json.loads((Path(__file__).parents[1] / 'configs/abstract_scope_rules.json').read_text())


def record(title='Private equity ownership', abstract='We study private equity ownership.', **changes):
    row = {'paper_id': '2-s2.0-1', 'title': title, 'abstract': abstract,
           'embedding_text': title + '\n\n' + abstract, 'journal': 'Finance Research',
           'document_type': 'Article'}
    return {**row, **changes}


@pytest.mark.parametrize('row, decision, reason', [
    (record(), 'keep', 'explicit_private_equity'),
    (record(title='Private–equity ownership of hospitals'), 'keep', 'explicit_private_equity'),
    (record(title='Leveraged buyouts', abstract='We study debt and leverage.'), 'keep', 'explicit_private_equity'),
    (record(title='Private equity in the chemical industry'), 'exclude', 'chemical'),
    (record(journal='Chemical Week'), 'exclude', 'chemical'),
    (record(journal="Jane's Defence Weekly"), 'exclude', 'trade_news'),
    (record(abstract='We compare private equity buyouts and venture capital funds.'), 'exclude', 'venture_capital'),
    (record(title='Venture capital and private equity'), 'exclude', 'venture_capital'),
    (record(journal='Venture Capital'), 'exclude', 'venture_capital'),
    (record(abstract='Private equity and VC funds.'), 'exclude', 'venture_capital'),
    (record(title='VCs and finance'), 'exclude', 'venture_capital'),
    (record(title='Market liquidity', abstract='We study bonds and the equity premium.'), 'exclude', 'no_explicit'),
    (record(title='Pension portfolios'), 'review', 'incidental'),
    (record(title='Private equity placements'), 'review', 'private_placement'),
    (record(title='Private equity for start-ups'), 'review', 'startup'),
    (record(document_type='Note'), 'review', 'nonresearch'),
    (record(abstract='We report patient survival, with no chemical context.', title='Private equity'), 'exclude', 'chemical'),
])
def test_scope_precedence_and_word_boundaries(rules, row, decision, reason):
    result = screen_abstracts(pd.DataFrame([row]), rules).iloc[0]
    assert result.decision == decision
    assert reason in result.reason
    assert result.embedding_text == row['embedding_text']


def test_mixed_option_requires_review_and_short_pe_papers_are_not_removed(rules):
    rules['exclude_any_vc_mention'] = False
    result = screen_abstracts(pd.DataFrame([record(abstract='Private equity and venture capital.')]), rules)
    assert result.iloc[0].decision == 'review'
    result = screen_abstracts(pd.DataFrame([record(abstract='A short PE abstract.')]), rules)
    assert result.iloc[0].decision == 'keep'


def test_reviewed_overrides_are_traceable_and_stale_decisions_fail(rules):
    source = pd.DataFrame([record(title='Specialist investment')])
    audit = screen_abstracts(source, rules)
    overrides = audit[OVERRIDE_COLUMNS].copy()
    overrides['decision'] = 'keep'
    overrides['reason'] = 'Manually reviewed: analysis concerns buyout funds.'
    reviewed = screen_abstracts(source, rules, overrides).iloc[0]
    assert reviewed.decision == 'keep' and reviewed.manual_override
    assert reviewed.automatic_decision == 'review'
    for field in ['title', 'journal', 'abstract']:
        changed = source.copy()
        changed.loc[0, field] += ' changed'
        with pytest.raises(ValueError, match='Stale override'):
            screen_abstracts(changed, rules, overrides)
    with pytest.raises(ValueError, match='Duplicate override'):
        screen_abstracts(source, rules, pd.concat([overrides, overrides]))
    with pytest.raises(ValueError, match='Unknown override'):
        screen_abstracts(source, rules, overrides.assign(paper_id='absent'))
    with pytest.raises(ValueError, match='nonempty reason'):
        screen_abstracts(source, rules, overrides.assign(reason=''))


@pytest.fixture
def parent_run(tmp_path):
    source, run = tmp_path / 'source.csv', tmp_path / 'original_run'
    run.mkdir()
    source_frame = pd.DataFrame([
        record(title=f'Private equity ownership {i}', paper_id=f'EID-{i}',
               abstract='We study private equity.' if i < 21 else 'Private equity and venture capital.',
               doi='', year='2020', document_language='English') for i in range(24)
    ])
    source_frame['embedding_text'] = source_frame.title + '\n\n' + source_frame.abstract
    source_frame['abstract_word_count'] = source_frame.abstract.str.split().str.len()
    source_frame.to_csv(source, index=False)
    selected = source_frame.sample(frac=1, random_state=52).reset_index(drop=True)
    selected.insert(0, 'embedding_row', np.arange(len(selected)))
    selected['token_count'] = np.arange(10, 34)
    selected['over_limit'] = False
    selected.to_csv(run / 'selected_papers.csv', index=False)
    selected[['embedding_row', 'paper_id']].to_csv(run / 'paper_ids.csv', index=False)
    selected[['paper_id', 'title', 'token_count', 'over_limit']].iloc[::-1].to_csv(run / 'token_lengths.csv', index=False)
    vectors = np.random.default_rng(42).normal(size=(24, 8)).astype(np.float32)
    vectors /= np.linalg.norm(vectors, axis=1, keepdims=True)
    np.save(run / 'embeddings.npy', vectors)
    summary = {'status': 'complete', 'run_mode': 'full', 'source_sha256': file_hash(source),
               'model': 'BAAI/bge-m3', 'input_column': 'embedding_text',
               'input_format': 'title + blank line + abstract', 'normalization': 'L2',
               'truncation': False, 'chunking': False, 'corpus_size': 24, 'selected_size': 24,
               'max_tokens': 8192, 'selected_over_limit': 0, 'corpus_over_limit': 0,
               'maximum_sample_tokens': 33, 'maximum_corpus_tokens': 33,
               'shape': [24, 8], 'dtype': 'float32', 'inference_seconds': 100.0}
    (run / 'run_summary.json').write_text(json.dumps(summary))
    return source, run, selected, vectors


def test_subset_roundtrip_preserves_source_vectors_metadata_and_reruns(parent_run, tmp_path, rules):
    source, run, selected, vectors = parent_run
    before = {p: file_hash(p) for p in [source, *run.iterdir()]}
    bundle, manifest, audit = build_scope_bundle(tmp_path, source, run, rules)
    papers, actual, provenance = load_abstract_embeddings(bundle / 'embedding_run', bundle / 'abstracts_clean.csv')
    mask = selected.paper_id.isin(audit.loc[audit.decision.eq('keep'), 'paper_id'])
    assert len(papers) == 21 and manifest['counts'] == {'keep': 21, 'exclude': 3}
    np.testing.assert_array_equal(actual, vectors[mask])
    assert papers.paper_id.tolist() == selected.loc[mask, 'paper_id'].tolist()
    assert papers.embedding_text.tolist() == selected.loc[mask, 'embedding_text'].tolist()
    assert papers.embedding_row.tolist() == list(range(21))
    assert provenance['maximum_corpus_tokens'] == int(papers.token_count.max())
    assert 'inference_seconds' not in provenance
    assert before == {p: file_hash(p) for p in before}
    activate_scope(tmp_path, bundle)
    assert resolve_abstract_inputs(tmp_path) == (bundle / 'embedding_run', bundle / 'abstracts_clean.csv')
    hashes = {p: file_hash(p) for p in bundle.rglob('*') if p.is_file()}
    assert build_scope_bundle(tmp_path, source, run, rules)[0] == bundle
    assert hashes == {p: file_hash(p) for p in hashes}
    # Clustering and topic loaders must see exactly the same source and vectors.
    from batill.abstract_topic_analysis import load_abstract_topic_corpus
    topic_papers, topic_vectors, _ = load_abstract_topic_corpus(*resolve_abstract_inputs(tmp_path))
    np.testing.assert_array_equal(topic_vectors, actual)
    assert topic_papers.paper_id.tolist() == papers.paper_id.tolist()
    # Activation checks the bundle; resolution rejects a subsequently corrupted matrix.
    np.save(bundle / 'embedding_run/embeddings.npy', actual[::-1])
    with pytest.raises(ValueError, match='changed'):
        resolve_abstract_inputs(tmp_path)
    with pytest.raises(ValueError, match='changed'):
        build_scope_bundle(tmp_path, source, run, rules)


def test_bad_parent_or_empty_scope_cannot_change_active_input(parent_run, tmp_path, rules):
    source, run, _, _ = parent_run
    pointer = tmp_path / ACTIVE_CONFIG
    pointer.parent.mkdir()
    pointer.write_text('existing pointer')
    strict = {**rules, 'trade_journals': ['Finance Research']}
    with pytest.raises(ValueError, match='Fewer than 20'):
        build_scope_bundle(tmp_path, source, run, strict)
    source.write_text(source.read_text() + '\n')
    with pytest.raises(ValueError, match='checksum'):
        build_scope_bundle(tmp_path, source, run, rules)
    assert pointer.read_text() == 'existing pointer'


def test_excel_treats_source_formula_prefixes_as_text(tmp_path, rules):
    from openpyxl import load_workbook
    audit = screen_abstracts(pd.DataFrame([record(title='=HYPERLINK("example") private equity')]), rules)
    destination = tmp_path / 'review.xlsx'
    export_review_workbook(audit, destination)
    workbook = load_workbook(destination)
    assert workbook['Keep']['D2'].data_type == 's'
    assert workbook['Keep'].max_row == 2
    assert workbook['Review'].max_row == 1
    workbook.close()
