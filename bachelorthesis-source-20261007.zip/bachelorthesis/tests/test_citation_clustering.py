"""Citation clustering must not fit to UMAP or double-count duplicate PDFs."""
import numpy as np
import pandas as pd
import pytest

from batill.citation_clustering import (
    citation_network, citation_leiden_sweep, citation_cluster_tables,
    partition_comparison, citation_umap_comparison, load_citation_corpus,
)
from batill.storage import write_json


def fixture():
    nodes = pd.DataFrame({'Key':list('abcdefg'), 'paper_id':[f'P{i:03}' for i in range(1,8)],
                          'query_title':[f'Title {s}' for s in 'abcdefg']})
    pairs = [('a','b'),('b','a'),('a','c'),('b','c'),('d','e'),('d','f'),('e','f')]
    edges = pd.DataFrame(pairs,columns=['source_key','target_key']).assign(citation_source='openalex')
    edges.loc[0,'citation_source']='local_pdf_manual_review'
    return nodes,edges


def test_binary_union_isolates_and_manual_sensitivity():
    n,e=fixture();g=citation_network(n,e)
    assert g['diagnostics']['directed_citations']==7
    assert g['diagnostics']['undirected_links']==6
    assert g['diagnostics']['isolated_works']==1
    assert g['adjacency'][0,1]==1  # mutual references do not double weight a link
    assert citation_network(n,e,include_manual=False)['adjacency'][0,1]==1
    with pytest.raises(ValueError,match='duplicate'):
        citation_network(n,pd.concat([e,e.iloc[:1]]))


def test_two_communities_and_unassigned_isolate():
    n,e=fixture();g=citation_network(n,e)
    diagnostics,results=citation_leiden_sweep(g,[1.0],seeds=(42,43))
    labels=results[1.0]['labels']
    assert labels.tolist()==[1,1,1,2,2,2,0]
    assert diagnostics.iloc[0].communities==2
    assert diagnostics.iloc[0].seed_stability_ARI_mean==1
    summary,membership=citation_cluster_tables(n,g,results[1.0])
    assert summary.Works.tolist()==[3,3]
    assert membership.iloc[-1]['Citation community']=='Unassigned (no links)'
    assert membership.within_community_degree.tolist()==[2,2,2,2,2,2,0]


def test_agreement_excludes_only_citation_unassigned_not_kmeans_zero():
    metrics,overlap=partition_comparison([1,1,2,2,0],[0,0,1,1,2])
    assert metrics['ARI']==1 and metrics['AMI']==1 and metrics['compared_works']==4
    assert overlap.to_numpy().sum()==4 and overlap.shape==(2,2)
    with pytest.raises(ValueError,match='same'):
        partition_comparison([1,2],[1])


def test_plot_reuses_exact_umap_coordinates_by_hash():
    n,_=fixture();papers=pd.DataFrame({'Key':list('gfedcba'), 'UMAP 1':np.arange(7), 'UMAP 2':np.arange(7)+10})
    before=papers.copy(deep=True)
    fig,frame,pairs=citation_umap_comparison(n,papers,[1,1,1,2,2,2,0],[4,4,4,9,9,9,9],text_name='test',resolution=1)
    assert frame['UMAP 1'].tolist()==[6,5,4,3,2,1,0]
    assert len(frame)==7 and len(pairs)==2
    assert sum(len(trace.x) for trace in fig.data)==14
    assert list(fig.layout.xaxis.range)==list(fig.layout.xaxis2.range)
    pd.testing.assert_frame_equal(papers,before)


def test_loader_matches_canonical_rows_and_rejects_stale_selection(tmp_path):
    papers=pd.DataFrame({'Key':['b','dup','a'],'Paper ID':['P002','P003','P001']})
    pd.DataFrame({'Key':['a','b'],'paper_id':['P001','P002'],'approved':[True,True]}).to_csv(tmp_path/'nodes.csv',index=False)
    pd.DataFrame({'source_key':['a'],'target_key':['b']}).to_csv(tmp_path/'edges.csv',index=False)
    pd.DataFrame({'Key':['a','b','dup'],'canonical_key':['a','b','b']}).to_csv(tmp_path/'pdf_to_work.csv',index=False)
    write_json(tmp_path/'run_manifest.json',{'selection_id':'current'})
    nodes,_,mapping=load_citation_corpus(tmp_path,papers,'current')
    assert nodes.embedding_row.tolist()==[2,0] and nodes.pdf_count.tolist()==[1,2]
    assert len(mapping)==3
    with pytest.raises(ValueError,match='selections differ'):
        load_citation_corpus(tmp_path,papers,'old')
    with pytest.raises(ValueError,match='exactly'):
        load_citation_corpus(tmp_path,papers.iloc[:2],'current')


def test_empty_graph_and_invalid_sweep_fail_clearly():
    n,e=fixture();g=citation_network(n,e.iloc[:0])
    with pytest.raises(ValueError,match='No citation'):
        citation_leiden_sweep(g,[1])
    with pytest.raises(ValueError,match='unique'):
        citation_leiden_sweep(citation_network(n,e),[1,1])
