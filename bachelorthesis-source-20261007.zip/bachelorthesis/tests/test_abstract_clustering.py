"""Protect abstract/vector identity and reject incomplete or mixed embedding runs."""

import json
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

from batill.abstract_clustering import load_abstract_embeddings
from batill.storage import file_hash


@pytest.fixture
def abstract_run(tmp_path):
    run = tmp_path / 'full_run'
    run.mkdir()
    source = tmp_path / 'abstracts_clean.csv'
    papers = pd.DataFrame({
        'paper_id': [f'2-s2.0-{i}' for i in range(8)],
        'title': [f'Title {i}' for i in range(8)],
        'abstract': [f'Abstract {i}' for i in range(8)],
        'doi': ['', *[f'10.1234/{i}' for i in range(1, 8)]],
        'year': ['2020'] * 8, 'journal': ['Journal'] * 8,
        'document_type': ['Article'] * 8, 'document_language': ['English'] * 8,
        'abstract_word_count': [2] * 8,
    })
    papers.loc[0, 'title'] = ''  # The embedding runner allows a missing title.
    papers['embedding_text'] = ['\n\n'.join(p for p in (t, a) if p)
                                for t, a in zip(papers.title, papers.abstract)]
    papers.to_csv(source, index=False)
    # Deliberately save a different order: the matrix/ID tables are authoritative.
    selected = papers.iloc[[4, 2, 1, 0, 3, 7, 6, 5]].reset_index(drop=True)
    selected.insert(0, 'embedding_row', np.arange(8))
    selected['token_count'] = np.arange(10, 18)
    selected['over_limit'] = False
    selected.to_csv(run / 'selected_papers.csv', index=False)
    selected[['embedding_row', 'paper_id']].to_csv(run / 'paper_ids.csv', index=False)
    selected[['paper_id', 'title', 'token_count', 'over_limit']].iloc[::-1].to_csv(
        run / 'token_lengths.csv', index=False)
    # The analysis reads dimensions from the run, rather than hardcoding 1024.
    vectors = np.random.default_rng(42).normal(size=(8, 5)).astype(np.float32)
    vectors /= np.linalg.norm(vectors, axis=1, keepdims=True)
    np.save(run / 'embeddings.npy', vectors)
    summary = {
        'status': 'complete', 'run_mode': 'full', 'source_sha256': file_hash(source),
        'model': 'BAAI/bge-m3', 'input_column': 'embedding_text',
        'input_format': 'title + blank line + abstract', 'normalization': 'L2',
        'truncation': False, 'chunking': False, 'corpus_size': 8, 'selected_size': 8,
        'max_tokens': 8192, 'selected_over_limit': 0, 'corpus_over_limit': 0,
        'maximum_sample_tokens': 17, 'maximum_corpus_tokens': 17,
        'shape': [8, 5], 'dtype': 'float32',
    }
    (run / 'run_summary.json').write_text(json.dumps(summary))
    return run, source, vectors, selected


def edit_summary(run, **changes):
    path = run / 'run_summary.json'
    path.write_text(json.dumps({**json.loads(path.read_text()), **changes}))


def test_load_preserves_saved_vector_order_source_text_and_metadata(abstract_run):
    run, source, vectors, selected = abstract_run
    before = {path: file_hash(path) for path in [source, *run.iterdir()]}
    papers, loaded, provenance = load_abstract_embeddings(run, source)
    np.testing.assert_array_equal(loaded, vectors)
    assert papers.Key.tolist() == selected.paper_id.tolist()
    assert papers['Paper ID'].tolist() == selected.paper_id.tolist()
    assert papers.embedding_text.tolist() == selected.embedding_text.tolist()
    assert papers.Title.tolist() == selected.title.tolist()
    assert papers.text_preview.tolist() == selected.abstract.tolist()
    assert 'source_filename' not in papers and 'segments' not in papers
    assert provenance['shape'] == [8, 5]
    assert before == {path: file_hash(path) for path in before}


@pytest.mark.parametrize('changes, message', [
    ({'run_mode': 'sample'}, 'completed full'),
    ({'status': 'embedding'}, 'completed full'),
    ({'shape': [8, 1024]}, 'shape'),
    ({'selected_size': 7}, 'counts'),
    ({'chunking': True}, 'setting'),
    ({'normalization': 'none'}, 'setting'),
    ({'source_sha256': 'bad'}, 'checksum'),
    ({'maximum_sample_tokens': 16}, 'token audit'),
])
def test_rejects_incompatible_run_summary(abstract_run, changes, message):
    run, source, _, _ = abstract_run
    edit_summary(run, **changes)
    with pytest.raises(ValueError, match=message):
        load_abstract_embeddings(run, source)


@pytest.mark.parametrize('damage', ['nan', 'zero', 'unnormalized', 'missing_row', 'integer'])
def test_rejects_invalid_vectors(abstract_run, damage):
    run, source, vectors, _ = abstract_run
    if damage == 'nan':
        vectors[0, 0] = np.nan
    elif damage == 'zero':
        vectors[0] = 0
    elif damage == 'unnormalized':
        vectors[0] *= 2
    elif damage == 'missing_row':
        vectors = vectors[:-1]
    else:
        vectors = vectors.astype(int)
    np.save(run / 'embeddings.npy', vectors)
    with pytest.raises(ValueError, match='Embedding|embeddings'):
        load_abstract_embeddings(run, source)


@pytest.mark.parametrize('filename, damage, message', [
    ('paper_ids.csv', 'reorder_ids', 'ID order'),
    ('selected_papers.csv', 'duplicate_id', 'unique'),
    ('selected_papers.csv', 'reorder_rows', 'embedding_row'),
    ('selected_papers.csv', 'changed_text', 'metadata or text'),
    ('selected_papers.csv', 'missing_column', 'missing columns'),
    ('token_lengths.csv', 'changed_tokens', 'token audit'),
    ('token_lengths.csv', 'over_limit', 'over-limit'),
    ('token_lengths.csv', 'missing_id', 'cover exactly'),
])
def test_rejects_misalignment_and_stale_metadata(abstract_run, filename, damage, message):
    run, source, _, _ = abstract_run
    path = run / filename
    table = pd.read_csv(path, dtype=str, keep_default_na=False)
    if damage == 'reorder_ids':
        table['paper_id'] = table.paper_id.iloc[::-1].tolist()
    elif damage == 'duplicate_id':
        table.loc[0, 'paper_id'] = table.loc[1, 'paper_id']
    elif damage == 'reorder_rows':
        table = table.iloc[::-1]
    elif damage == 'changed_text':
        table.loc[0, 'embedding_text'] += ' changed'
    elif damage == 'missing_column':
        table = table.drop(columns='token_count')
    elif damage == 'changed_tokens':
        table.loc[0, 'token_count'] = '99'
    elif damage == 'over_limit':
        table.loc[0, 'over_limit'] = 'True'
    else:
        table.loc[0, 'paper_id'] = 'unknown'
    table.to_csv(path, index=False)
    with pytest.raises(ValueError, match=message):
        load_abstract_embeddings(run, source)


def test_moved_run_and_missing_files(abstract_run, tmp_path):
    run, source, _, _ = abstract_run
    moved = tmp_path / 'archive' / 'renamed_run'
    moved.parent.mkdir()
    run.rename(moved)
    assert len(load_abstract_embeddings(moved, source)[0]) == 8
    (moved / 'paper_ids.csv').unlink()
    with pytest.raises(FileNotFoundError, match='configured paths'):
        load_abstract_embeddings(moved, source)


def test_hierarchy_and_leiden_tables_accept_abstract_metadata(abstract_run):
    from batill.clustering import cosine_hierarchy, cluster_hierarchy, hierarchy_tables
    from batill.graph_clustering import similarity_graph, leiden_tables

    run, source, _, _ = abstract_run
    papers, vectors, _ = load_abstract_embeddings(run, source)
    hierarchy = cosine_hierarchy(vectors, optimal_ordering=False)
    groups = cluster_hierarchy(hierarchy, max_clusters=3)
    summary, membership = hierarchy_tables(hierarchy, groups, papers)
    assert summary.Papers.sum() == len(papers)
    assert set(membership.Key) == set(papers.Key)
    assert 'segments' not in membership and 'source_filename' not in membership
    assert membership.set_index('Key').doi.to_dict() == papers.set_index('Key').doi.to_dict()
    graph = similarity_graph(vectors, neighbours=2)
    _, members = leiden_tables(graph, {'labels': groups['labels']}, papers)
    assert set(members.Key) == set(papers.Key)


def test_disabling_optimal_ordering_preserves_hierarchy_partitions():
    from batill.clustering import cosine_hierarchy, cluster_hierarchy
    from sklearn.metrics import adjusted_rand_score

    vectors = np.random.default_rng(92).normal(size=(30, 9))
    original = cosine_hierarchy(vectors)
    faster = cosine_hierarchy(vectors, optimal_ordering=False)
    np.testing.assert_allclose(original['linkage'][:, 2:], faster['linkage'][:, 2:])
    for k in (2, 5, 15):
        a, b = [cluster_hierarchy(h, k)['labels'] for h in (original, faster)]
        assert adjusted_rand_score(a, b) == 1.0


def test_notebook_reuses_only_distances_from_current_embeddings(abstract_run, tmp_path):
    """Reloading an equally sized corpus must not reuse stale pairwise matrices."""
    from sklearn.metrics.pairwise import cosine_distances, cosine_similarity

    run, source, _, _ = abstract_run
    papers, vectors, _ = load_abstract_embeddings(run, source)
    notebook = json.loads((Path(__file__).parents[1] / 'Clustering Abstracts.ipynb').read_text())
    namespace = dict(papers=papers, embeddings=vectors, keys=papers.Key.to_numpy(),
                     np=np, pd=pd, RANDOM_STATE=42, TOP_N=3, ROOT=tmp_path,
                     cosine_distances=cosine_distances, cosine_similarity=cosine_similarity,
                     display=lambda *args, **kwargs: None)

    def cell(index):
        exec(compile(''.join(notebook['cells'][index]['source']), f'cell_{index}', 'exec'), namespace)

    cell(5)
    cell(16)
    cell(38)
    assert namespace['similarities'] is namespace['hierarchy']['similarity']
    assert namespace['distance_matrix'] is namespace['hierarchy']['distance']
    newer = vectors.copy()
    newer[0] *= -1
    namespace['embeddings'] = newer
    cell(16)
    cell(38)
    assert namespace['distance_matrix'] is not namespace['hierarchy']['distance']
    np.testing.assert_allclose(namespace['similarities'], cosine_similarity(newer), atol=1e-6)
    np.testing.assert_allclose(namespace['distance_matrix'], cosine_distances(newer), atol=1e-6)
