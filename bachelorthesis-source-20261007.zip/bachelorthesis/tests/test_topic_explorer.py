"""Focused checks for the imported PDF topic explorer."""

import numpy as np
import pandas as pd

from batill.topic_explorer import choose_partition, search_expression, supporting_papers


def test_expression_search_counts_papers_and_occurrences_without_crossing_blocks():
    analysis = {
        'papers': pd.DataFrame({'paper_id': ['P1', 'P2'], 'title': ['First', 'Second']}),
        'labels': np.array([1, 2]),
        'passages': pd.DataFrame([
            {'row': 0, 'page': 1, 'block_id': 'a', 'text': 'Private-equity and private equity.'},
            {'row': 1, 'page': 2, 'block_id': 'b', 'text': 'Private'},
            {'row': 1, 'page': 2, 'block_id': 'c', 'text': 'equity appears separately.'},
        ]),
        'search_cache': {},
    }

    counts = search_expression(analysis, 'private equity')
    support = supporting_papers(analysis, 'private equity', cluster=1)

    assert counts['Total occurrences'].tolist() == [2, 0]
    assert counts['Papers containing term'].tolist() == [1, 0]
    assert support.paper_id.tolist() == ['P1']
    assert support.occurrences.tolist() == [2]
    assert support.page.tolist() == [1]


def test_saved_partition_is_copied_and_fit_kmeans_uses_positive_ids():
    context = {'partitions': {'saved_example': np.array([1, 1, 2, 2])},
               'metrics': pd.DataFrame(columns=['solution']),
               'embeddings': np.array([[1., 0.], [.9, .1], [0., 1.], [.1, .9]])}

    saved, settings = choose_partition(context, saved='saved_example')
    saved[0] = 2
    fitted, fit_settings = choose_partition(context, source='fit', method='kmeans',
                                            k=2, seed=42, n_init=2)

    assert context['partitions']['saved_example'][0] == 1
    assert settings['source'] == 'saved'
    assert set(fitted) == {1, 2}
    assert fit_settings['source'] == 'fit'
