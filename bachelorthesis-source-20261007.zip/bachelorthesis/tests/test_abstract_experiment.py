"""Pinned experimental memberships must not silently change corpus or ID order."""
import numpy as np
import pandas as pd
import pytest
from sklearn.metrics import silhouette_samples
from sklearn.metrics.pairwise import cosine_distances

from batill.abstract_experiment import load_saved_experiment
from batill.abstract_topic_analysis import abstract_partition_input_id
from batill.storage import file_hash, read_json, write_json


@pytest.fixture
def experiment(tmp_path, monkeypatch):
    import batill.abstract_experiment as loader
    folder = tmp_path / 'experiment'
    folder.mkdir()
    papers = pd.DataFrame({'paper_id': [f'A{i}' for i in range(12)], 'text': 'Abstract'})
    vectors = np.repeat(np.eye(6), 2, axis=0)
    labels = np.repeat(np.arange(6), 2)
    scores = silhouette_samples(cosine_distances(vectors), labels, metric='precomputed')
    np.savez(folder / 'partitions.npz', paper_ids=papers.paper_id.to_numpy(dtype=str),
             kmeans_k6=labels, kmeans_k6__silhouettes=scores)
    papers[['paper_id']].assign(experiment_retained=True).to_csv(folder / 'experiment_decisions.csv', index=False)
    pd.DataFrame([{'solution': 'kmeans_k6', 'clusters': 6, 'method': 'K-means', 'seed': 11}]).to_csv(folder / 'partition_summary.csv', index=False)
    papers[['paper_id']].assign(solution='kmeans_k6', cluster=labels).to_csv(folder / 'all_assignments.csv', index=False)
    write_json(folder / 'input_manifest.json', {'artifacts_sha256': {}})
    write_json(folder / 'clustering_manifest.json', {
        'papers': 12, 'input_id': abstract_partition_input_id(papers.paper_id, vectors),
        'experiment_input_manifest_sha256': file_hash(folder / 'input_manifest.json'),
        'artifact_sha256': {p.name: file_hash(p) for p in folder.iterdir() if p.is_file()}})
    spec = {'directory': 'experiment', 'papers': 12,
            'clustering_manifest_sha256': file_hash(folder / 'clustering_manifest.json')}
    monkeypatch.setattr(loader, 'load_abstract_topic_corpus', lambda *args: (papers, vectors, {}))
    return tmp_path, folder, spec, labels


def test_loads_exact_six_cluster_memberships_including_zero(experiment):
    root, _, spec, labels = experiment
    context = load_saved_experiment(root, spec, ['kmeans_k6'])
    assert list(context['solutions']) == ['kmeans_k6']
    np.testing.assert_array_equal(context['solutions']['kmeans_k6']['labels'], labels)
    assert len(context['papers']) == 12


def test_changed_pinned_manifest_is_rejected(experiment):
    root, folder, spec, _ = experiment
    (folder / 'clustering_manifest.json').write_text('{}')
    with pytest.raises(ValueError, match='manifest changed'):
        load_saved_experiment(root, spec, ['kmeans_k6'])


def test_reordered_ids_are_rejected_even_after_rehashing(experiment):
    root, folder, spec, labels = experiment
    np.savez(folder / 'partitions.npz', paper_ids=np.array([f'A{i}' for i in reversed(range(12))]),
             kmeans_k6=labels, kmeans_k6__silhouettes=np.ones(12))
    manifest = read_json(folder / 'clustering_manifest.json')
    manifest['artifact_sha256']['partitions.npz'] = file_hash(folder / 'partitions.npz')
    write_json(folder / 'clustering_manifest.json', manifest)
    spec['clustering_manifest_sha256'] = file_hash(folder / 'clustering_manifest.json')
    with pytest.raises(ValueError, match='paper order changed'):
        load_saved_experiment(root, spec, ['kmeans_k6'])


def test_missing_solution_does_not_refit_or_fall_back(experiment):
    root, _, spec, _ = experiment
    with pytest.raises(ValueError, match='Missing or unsupported'):
        load_saved_experiment(root, spec, ['kmeans_k5'])
