"""Recorded identity decisions must not silently follow changed search results."""
import copy

import pandas as pd
import pytest

from batill.citation_review import apply_match_review
from batill.storage import write_json


def fixture(tmp_path):
    matches = pd.DataFrame([{'Key': c * 64, 'paper_id': f'P{i:03d}',
        'query_title': f'Paper {c}', 'doi': '', 's2_id': c * 40,
        'approved': False, 'match_status': 'needs_review', 's2_title': f'Paper {c}',
        's2_doi': '', 's2_year': 2020, 's2_url': '', 'reference_count': 1,
        'citation_count': 2, 'title_similarity': 1.0} for i, c in enumerate('ab', 1)])
    rows = []
    for i, row in matches.iterrows():
        rows.append({'pdf_sha256': row.Key, 'paper_id': row.paper_id,
            'expected_query_title': row.query_title, 'expected_doi': row.doi,
            'expected_s2_id': row.s2_id, 'decision': 'accept' if i == 0 else 'hold',
            'category': 'accepted_version_proxy' if i == 0 else 'wrong_candidate',
            'version_status': 'same_work_version_not_verified' if i == 0 else 'not_applicable',
            'reason': 'Verified title and authors' if i == 0 else 'Different authors',
            'chosen_candidate': {'paperId': 'c' * 40, 'title': 'Paper a', 'year': 2019,
                                 'externalIds': {'DOI': '10.123/WORK'}, 'referenceCount': 8}})
    config = {'schema_version': 1, 'papers': rows}
    path = tmp_path / 'review.json'
    write_json(path, config)
    return matches, config, path


def test_applies_review_without_changing_raw_rows_or_order(tmp_path):
    raw, config, path = fixture(tmp_path)
    original = raw.copy(deep=True)
    reviewed, audit = apply_match_review(raw, path)
    pd.testing.assert_frame_equal(raw, original)
    assert reviewed.Key.tolist() == raw.Key.tolist()
    assert reviewed.approved.tolist() == [True, False]
    assert reviewed.s2_id.tolist() == ['c' * 40, 'b' * 40]
    assert reviewed.iloc[0].s2_doi == '10.123/work'
    assert reviewed.iloc[0].reference_count == 8
    assert reviewed.iloc[0].review_version_status == 'same_work_version_not_verified'
    assert audit.decision.tolist() == ['accept', 'hold']
    assert reviewed.attrs['review_config_id']


@pytest.mark.parametrize('column,value', [('s2_id', 'd' * 40), ('doi', '10.123/changed'),
                                         ('query_title', 'Another paper')])
def test_stale_review_is_rejected(tmp_path, column, value):
    raw, _, path = fixture(tmp_path)
    raw.loc[0, column] = value
    with pytest.raises(ValueError, match='Stale review'):
        apply_match_review(raw, path)


def test_ignores_excluded_papers_but_rejects_duplicate_approved_identities(tmp_path):
    raw, config, path = fixture(tmp_path)
    result, audit = apply_match_review(raw.iloc[:1], path)
    assert len(result) == 1
    assert audit.iloc[1].decision == 'not_in_current_selection'
    config['papers'][1]['decision'] = 'accept'
    config['papers'][1]['version_status'] = 'same_work_version_not_verified'
    write_json(path, config)
    with pytest.raises(ValueError, match='duplicate approved'):
        apply_match_review(raw, path)
    config['papers'].append(copy.deepcopy(config['papers'][0]))
    write_json(path, config)
    with pytest.raises(ValueError, match='Duplicate or invalid'):
        apply_match_review(raw, path)
