"""Selected-PDF identities, exact fitted catalog, and stale-result protection."""
import numpy as np
import pandas as pd
import pytest
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_samples
from sklearn.metrics.pairwise import cosine_distances
from threadpoolctl import threadpool_limits
from batill import selected_abstract_topics as sat
from batill.abstract_topic_analysis import abstract_partition_input_id
from batill.graph_clustering import similarity_graph, leiden_sweep
from batill.storage import write_json


@pytest.fixture
def catalog_args(tmp_path,monkeypatch):
    papers=pd.DataFrame({'paper_id':[f'P{i:03}' for i in range(1,9)],
                         'Key':[f'hash-{i}' for i in range(8)],
                         'title':['Buyout study']*4+['Hospital study']*4,
                         'abstract':['Investor equity returns.']*4+['Patient care outcomes.']*4,
                         'doi':'','year':'2020'})
    papers['embedding_text']=papers.title+'\n\n'+papers.abstract
    papers['text']=papers.embedding_text
    papers['abstract_word_count']=3
    papers['journal']=''
    papers['document_language']='English'
    papers['document_type']='Article'
    x=np.array([[1,.01],[1,.02],[1,.03],[1,.04],[.01,1],[.02,1],[.03,1],[.04,1]])
    x/=np.linalg.norm(x,axis=1,keepdims=True)
    run=tmp_path/'run';run.mkdir();source=tmp_path/'source.csv';papers.to_csv(source,index=False)
    write_json(run/'run_summary.json',{'status':'complete'})
    for name in ['Clustering Elite Papers Abstracts.ipynb','Clustering Abstracts.ipynb']:
        (tmp_path/name).write_text('{}')
    provenance={'input_hashes':{'source':'test'},'representation_id':'selected-title-abstract'}
    monkeypatch.setattr(sat,'load_selected_embeddings',lambda *args:(papers.copy(),x.copy(),provenance))
    monkeypatch.setattr(sat,'resolve_selected_run',lambda root:(run,source))
    with threadpool_limits(limits=1):
        model=KMeans(n_clusters=2,n_init=10,random_state=11).fit(x)
    graph=similarity_graph(x,neighbours=3)
    diagnostics,leiden=leiden_sweep(graph,[.5],seeds=[42,43])
    input_id=abstract_partition_input_id(papers.Key,x)
    return {'root':tmp_path,'papers':papers,'embeddings':x,'run_dir':run,'source_csv':source,
            'kmeans_results':{2:{'model':model,'labels':model.labels_,'seed':11,'seed_aris':[1.],
                                 'silhouettes':silhouette_samples(cosine_distances(x),model.labels_,metric='precomputed')}},
            'leiden_results':leiden,'graph':graph,
            'fit_input_ids':{'kmeans':input_id,'leiden':input_id},
            'kmeans_diagnostics':pd.DataFrame({'k':[2]}),'leiden_diagnostics':diagnostics,
            'settings':{'k_values':[2],'kmeans_seeds':[11],'n_init':10,'leiden_resolutions':[.5]}}


def test_roundtrip_keeps_exact_saved_labels_and_cluster_zero(catalog_args):
    args=catalog_args
    folder,manifest=sat.export_catalog(**args,selected_k=2)
    context=sat.load_context(args['root'])
    assert context['preferred_partitions']==['kmeans_k2']
    assert context['papers'].Key.tolist()==args['papers'].Key.tolist()
    for name in context['solutions']:
        labels,_=sat.choose_partition(context,name)
        expected=(args['kmeans_results'][2]['labels'] if name=='kmeans_k2'
                  else args['leiden_results'][.5]['labels'])
        np.testing.assert_array_equal(labels,expected)
    result=sat.analyse_partition(context,args['kmeans_results'][2]['labels'],min_df=1)
    assert set(result['membership'].cluster)=={0,1}
    assert result['summary'].papers.sum()==8
    assert result['unassigned'].empty
    labels,_=sat.choose_partition(context,'kmeans_k2');labels[:]=42
    assert 42 not in context['solutions']['kmeans_k2']['labels']
    with (folder/'partitions.npz').open('ab') as f:f.write(b'changed')
    with pytest.raises(ValueError,match='checksum'):
        sat.load_context(args['root'])


def test_rejects_stale_inputs_before_export(catalog_args):
    args=catalog_args
    with pytest.raises(ValueError,match='Stale'):
        sat.export_catalog(**{**args,'fit_input_ids':{'kmeans':'old','leiden':'old'}})
    reordered=args['papers'].iloc[::-1].reset_index(drop=True)
    identity=abstract_partition_input_id(reordered.Key,args['embeddings'])
    with pytest.raises(ValueError,match='authenticated'):
        sat.export_catalog(**{**args,'papers':reordered,
                              'fit_input_ids':{'kmeans':identity,'leiden':identity}})


def test_rejects_changed_labels_incomplete_sweeps_and_unfitted_choice(catalog_args):
    args=catalog_args
    with pytest.raises(ValueError,match='complete configured sweeps'):
        sat.export_catalog(**{**args,'settings':{**args['settings'],'k_values':[2,3]}})
    with pytest.raises(ValueError,match='already fitted'):
        sat.export_catalog(**args,selected_k=6)
    args['kmeans_results'][2]['labels']=1-args['kmeans_results'][2]['labels']
    with pytest.raises(ValueError,match='fitted model'):
        sat.export_catalog(**args)


def test_topic_loader_never_fits_a_missing_catalog(catalog_args):
    with pytest.raises(FileNotFoundError,match='export cell'):
        sat.load_context(catalog_args['root'])
    context={'papers':catalog_args['papers'], 'solutions':{'one':{
        'clusters':1,'labels':np.zeros(8,dtype=int),'method':'Embedding Leiden'}}}
    with pytest.raises(ValueError,match='no interpretable'):
        sat.choose_partition(context,'one')


def test_saved_notebook_outputs_do_not_change_source_identity(tmp_path):
    from batill.storage import write_json
    path=tmp_path/'notebook.ipynb'
    notebook={'cells':[{'cell_type':'code','source':['x = 1\n'],'outputs':[],'execution_count':None}]}
    write_json(path,notebook);before=sat.notebook_source_hash(path)
    notebook['cells'][0].update(outputs=[{'output_type':'stream','name':'stdout','text':'1'}],execution_count=1)
    write_json(path,notebook);assert sat.notebook_source_hash(path)==before
    notebook['cells'][0]['source']=['x = 2\n'];write_json(path,notebook)
    assert sat.notebook_source_hash(path)!=before


def test_export_computes_diagnostics_in_hierarchy_precision(catalog_args,monkeypatch):
    original=sat.cosine_distances
    observed=[]
    def distances(vectors):
        observed.append(vectors.dtype)
        return original(vectors)
    monkeypatch.setattr(sat,'cosine_distances',distances)
    args=catalog_args
    # Float32 is the actual saved BGE-M3 dtype; fitted diagnostics use the
    # float64 hierarchy. The source check below still authenticates the inputs.
    vectors=args['embeddings'].astype(np.float32)
    args['embeddings']=vectors
    provenance={'input_hashes':{'source':'test'},'representation_id':'selected-title-abstract'}
    monkeypatch.setattr(sat,'load_selected_embeddings',lambda *a:(args['papers'].copy(),vectors.copy(),provenance))
    identity=abstract_partition_input_id(args['papers'].Key,vectors)
    args['fit_input_ids']={'kmeans':identity,'leiden':identity}
    args['graph']=similarity_graph(vectors,neighbours=3)
    with threadpool_limits(limits=1):
        model=KMeans(n_clusters=2,n_init=10,random_state=11).fit(vectors)
    args['kmeans_results'][2].update(model=model,labels=model.labels_,silhouettes= silhouette_samples(original(vectors.astype(float)),model.labels_,metric='precomputed'))
    sat.export_catalog(**args)
    assert observed==[np.dtype('float64')]
