"""Exercise the standalone notebook's scientific and data-selection edge cases."""
from pathlib import Path
import re
import unicodedata

import nbformat
import numpy as np
import pandas as pd
import pytest
from bs4 import BeautifulSoup


@pytest.fixture(scope='module')
def functions():
    textstat = pytest.importorskip('textstat')
    import nltk
    root = Path(__file__).resolve().parents[1]
    nltk.data.path.insert(0, str(root / '.venv/nltk_data'))
    try:
        nltk.data.find('corpora/cmudict')
    except LookupError:
        pytest.skip('Install the notebook pronunciation dictionary to test scoring.')
    textstat.set_lang('en_US')
    namespace = dict(re=re, pd=pd, np=np, unicodedata=unicodedata,
                     BeautifulSoup=BeautifulSoup, textstat=textstat)
    notebook = nbformat.read(root / 'Verbal_Complexity.ipynb', as_version=4)
    for cell in notebook.cells:
        if set(cell.metadata.get('tags', [])) & {'date_functions', 'score_functions'}:
            exec(compile(cell.source, 'Verbal_Complexity.ipynb', 'exec'), namespace)
    return namespace


def test_bins_keep_1999_and_decade_boundaries(functions):
    f = functions['time_bin']
    assert [f(y) for y in [1989, 1999, 2000, 2009, 2010, 2026, None]] == [
        '≤1999', '≤1999', '2000–2009', '2000–2009', '2010–2019', '2020–2026', 'Unknown year']


def test_openalex_is_the_only_year_source(functions):
    frame = pd.DataFrame({
        'paper_id': ['P001', 'P002'], 'openalex_year': ['1999', '2020'],
        'query_year': [2000, 2019], 'pdf_year': [2001, 2018],
    })
    result = functions['assign_openalex_years'](frame)
    assert result.year.tolist() == [1999, 2020]
    assert result.period.tolist() == ['≤1999', '2020–2026']
    assert result.year_source.eq('openalex_year').all()
    assert 'year' not in frame  # The input table is not modified.


@pytest.mark.parametrize('invalid', [None, 'unknown', 2020.5, np.inf, 0, -1])
def test_invalid_openalex_years_never_fall_back(functions, invalid):
    frame = pd.DataFrame({'paper_id': ['P001'], 'openalex_year': [invalid],
                          'query_year': [2020]})
    with pytest.raises(ValueError, match='P001'):
        functions['assign_openalex_years'](frame)


def test_prose_excludes_structure_math_and_back_matter(functions):
    def block(i, kind, text, **kwargs):
        return dict(id=str(i), type=kind, text=text, include=True, page=1, section=[], **kwargs)
    document = {'blocks': [
        block(0, 'Text', 'The author and her university.'),
        block(1, 'SectionHeader', 'Abstract'),
        block(2, 'Text', 'Investors earn returns.', html='<p>Investors <math>x+y</math> earn returns.</p>'),
        block(3, 'Table', 'This is not prose.'),
        block(4, 'Footnote', 'A footnote.'),
        block(5, 'SectionHeader', 'References'),
        block(6, 'Text', 'Smith 2020. A reference.'),
    ]}
    text, audit, opening = functions['prepare_prose'](document)
    assert text == 'Investors earn returns.'
    assert opening and sum(b['retained'] for b in audit) == 1


def test_repeated_complex_words_and_empty_text(functions):
    score = functions['score_prose']
    text = 'Institutional investors evaluate institutional investments. Institutional investors evaluate institutional investments.'
    result = score(text)
    assert result['complex_word_count'] > functions['textstat'].difficult_words(text, 3, unique=True)
    assert np.isclose(result['fog'], .4 * (result['words_per_sentence'] + result['complex_word_pct']))
    assert np.isnan(score('')['fog'])
    assert np.isnan(score('')['flesch_reading_ease'])


def test_flesch_matches_hand_counted_simple_text(functions):
    result = functions['score_prose']('The cat sat on the mat. The dog ran to the pond.')
    assert result['word_count'] == 12
    assert result['sentence_count'] == 2
    assert result['syllable_count'] == 12
    assert result['syllables_per_word'] == 1
    assert result['flesch_reading_ease'] == pytest.approx(206.835 - 1.015 * 6 - 84.6)
    # Valid Reading Ease values can exceed 100: never clip to that display range.
    assert result['flesch_reading_ease'] > 100


def test_flesch_decreases_with_sentence_length_and_keeps_negative_values(functions):
    score = functions['score_prose']
    shorter = score('The cat sat on the mat. The dog ran to the pond.')
    longer = score('The cat sat on the mat and the dog ran to the pond.')
    assert longer['flesch_reading_ease'] < shorter['flesch_reading_ease']
    difficult = score(' '.join(['Institutional internationalization'] * 80) + '.')
    assert difficult['flesch_reading_ease'] < 0
    assert difficult['flesch_reading_ease'] == pytest.approx(
        206.835 - 1.015 * difficult['words_per_sentence'] - 84.6 * difficult['syllables_per_word'])
