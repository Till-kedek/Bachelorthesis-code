"""Reviewed Scopus examples reject stale membership, text and provenance."""

import copy

import numpy as np
import pandas as pd
import pytest

from batill.abstract_final_cluster_examples import (
    METADATA_FIELDS, membership_id, representative_papers,
)
from batill.storage import file_hash, fingerprint


@pytest.fixture
def final_review(tmp_path):
    records, choices = [], []
    labels = np.array([0, 0, 1, 1])
    for i in range(4):
        abstract = f'Private equity study {i}. Buyout evidence.'
        row = dict.fromkeys(METADATA_FIELDS, '')
        row.update(paper_id=f'2-s2.0-{i}', title=f'Title {i}', year='2020',
                   authors='Author A.', source_record=str(i), abstract=abstract,
                   embedding_text=f'Title {i}\n\n{abstract}')
        records.append(row)
        cut = abstract.index(' Buyout')
        choices.append({**{k: row[k] for k in METADATA_FIELDS}, 'paper_id': row['paper_id'],
            'cluster': int(labels[i]), 'embedding_text_sha256': fingerprint(row['embedding_text']),
            'abstract_sha256': fingerprint(abstract), 'evidence': [
                {'source_field': 'abstract', 'excerpt': abstract[:cut],
                 'excerpt_start': 0, 'excerpt_end': cut},
                {'source_field': 'abstract', 'excerpt': abstract[cut + 1:],
                 'excerpt_start': cut + 1, 'excerpt_end': len(abstract)}]})
    papers = pd.DataFrame(records)
    papers.to_csv(tmp_path / 'abstracts_clean.csv', index=False)
    vectors = np.array([[2., 0.], [1., .1], [0., 2.], [.1, 1.]])
    hashes = {'abstracts_clean.csv': file_hash(tmp_path / 'abstracts_clean.csv')}
    context = {'root': tmp_path, 'papers': papers, 'embeddings': vectors.copy(),
               'input_id': 'vectors', 'input_hashes': hashes,
               'solutions': {'kmeans_k2': {'labels': labels.copy()}}}
    analysis = {'papers': papers, 'labels': labels, 'embeddings': vectors,
                'membership': pd.DataFrame({'paper_id': papers.paper_id,
                                             'cosine_silhouette': [.9, -.1, .9, .9]})}
    settings = {'source': 'saved', 'saved': 'kmeans_k2', 'method': 'K-means', 'clusters': 2}
    review = {'solution': 'kmeans_k2', 'embedding_input_id': 'vectors', 'input_hashes': hashes,
              'source_csv': 'abstracts_clean.csv', 'membership_id': membership_id(papers, labels),
              'focus': {'0': 'buyouts', '1': 'funds'}, 'papers': choices}
    return context, analysis, settings, review


def test_scopus_ids_cluster_zero_and_boundary_papers_are_retained(final_review):
    before = final_review[1]['embeddings'].copy()
    selected, evidence, diagnostics = representative_papers(*final_review)
    assert selected.groupby('cluster').size().to_dict() == {0: 2, 1: 2}
    assert len(evidence) == 8 and evidence.page.isna().all() and evidence.block_id.isna().all()
    assert selected.cosine_silhouette.lt(0).sum() == 1
    assert diagnostics.paper_id.tolist() == final_review[0]['papers'].paper_id.tolist()
    np.testing.assert_array_equal(before, final_review[1]['embeddings'])
    expected_cosine = 1 / np.sqrt(1.01)
    np.testing.assert_allclose(diagnostics.mean_within_cluster_cosine, expected_cosine)


@pytest.mark.parametrize('change', ['labels', 'vectors', 'text', 'metadata', 'quote', 'duplicates'])
def test_stale_or_inconsistent_review_is_rejected(final_review, change):
    context, analysis, settings, review = copy.deepcopy(final_review)
    if change == 'labels':
        analysis['labels'][[0, 2]] = analysis['labels'][[2, 0]]
    elif change == 'vectors':
        analysis['embeddings'][0, 0] += 1
    elif change == 'text':
        analysis['papers'].loc[0, 'abstract'] = 'Different text.'
    elif change == 'metadata':
        analysis['papers'].loc[0, 'title'] = 'Wrong citation'
    elif change == 'quote':
        review['papers'][0]['evidence'][0]['excerpt'] = 'Unsupported content.'
    else:
        review['papers'][1] = copy.deepcopy(review['papers'][0])
    with pytest.raises(ValueError):
        representative_papers(context, analysis, settings, review)


def test_changed_source_csv_invalidates_unchanged_in_memory_review(final_review):
    (final_review[0]['root'] / 'abstracts_clean.csv').write_text('changed')
    with pytest.raises(ValueError, match='source CSV changed'):
        representative_papers(*final_review)


def test_fitted_partition_cannot_claim_a_saved_review(final_review):
    final_review[2]['source'] = 'fit'
    with pytest.raises(ValueError, match='saved K-means memberships'):
        representative_papers(*final_review)
