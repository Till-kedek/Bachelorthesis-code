"""Protect the saved citation handoff, canonical units, isolates and text evidence."""
import copy
import json

import numpy as np
import pandas as pd
import pytest

from batill.citation_clustering import citation_network
from batill.citation_topic_analysis import (
    save_citation_topic_partition, load_citation_topic_partition,
    describe_citation_topics, write_citation_review_cards,
    import_existing_citation_partition,
)
from batill.storage import file_hash, fingerprint, write_json
from batill.topic_analysis import build_vocabulary, topic_terms


@pytest.fixture
def corpus():
    nodes = pd.DataFrame({'Key': list('abcdefg'), 'paper_id': [f'P{i}' for i in range(7)],
                          'query_title': [f'Title {k}' for k in 'abcdefg']})
    edges = pd.DataFrame([('a', 'b'), ('a', 'c'), ('b', 'c'), ('c', 'd'), ('d', 'e'), ('e', 'f'), ('f', 'd')],
                         columns=['source_key', 'target_key'])
    papers = nodes.rename(columns={'Key': 'pdf_sha256', 'query_title': 'title'}).copy()
    papers['text'] = ['hospital care evidence ' * 12] * 3 + ['fund returns evidence ' * 12] * 3 + ['isolated zebra']
    papers['text_sha256'] = papers.text.map(fingerprint)
    passages = pd.DataFrame({'row': np.arange(7), 'page': 2, 'block_id': 'body',
                             'source_start': 4, 'text': papers.text})
    return {'papers': papers, 'nodes': nodes, 'network': citation_network(nodes, edges),
            'passages': passages, 'input_id': 'current', 'input_hashes': {'graph/nodes.csv': 'hash'},
            'selection': {'selection_id': 'scope'}}


def save(path, corpus, labels=None):
    return save_citation_topic_partition(path, corpus,
        np.array([1, 1, 1, 2, 2, 2, 0]) if labels is None else labels,
        resolution=1, seed=43, fit_input_id='current', source_evidence={'origin': 'fixture'})


def test_roundtrip_aligns_by_key_without_fitting(tmp_path, corpus, monkeypatch):
    def forbidden(*args, **kwargs):
        raise AssertionError('No new communities')
    monkeypatch.setattr('batill.citation_clustering.citation_leiden_sweep', forbidden)
    monkeypatch.setattr('leidenalg.find_partition', forbidden)
    manifest = save(tmp_path, corpus)
    table = pd.read_csv(tmp_path / 'assignments.csv').iloc[::-1]
    table.to_csv(tmp_path / 'assignments.csv', index=False)
    manifest['assignments_sha256'] = file_hash(tmp_path / 'assignments.csv')
    write_json(tmp_path / 'partition_manifest.json', manifest)
    labels, _ = load_citation_topic_partition(tmp_path, corpus)
    assert labels.tolist() == [1, 1, 1, 2, 2, 2, 0]


@pytest.mark.parametrize('field,value', [('source_kind', 'pdf_text_embeddings'),
    ('input_id', 'stale'), ('selection_id', 'other'), ('include_manual', False),
    ('assignment_id', 'wrong'), ('communities', 6), ('unassigned', 0)])
def test_rejects_wrong_partition_provenance(tmp_path, corpus, field, value):
    manifest = save(tmp_path, corpus)
    manifest[field] = value
    write_json(tmp_path / 'partition_manifest.json', manifest)
    with pytest.raises(ValueError):
        load_citation_topic_partition(tmp_path, corpus)


def test_rejects_tampered_csv_duplicate_keys_and_wrong_ids(tmp_path, corpus):
    manifest = save(tmp_path, corpus)
    path = tmp_path / 'assignments.csv'
    original = pd.read_csv(path)
    for field, value in [('cluster', 2), ('pdf_sha256', 'b'), ('paper_id', 'Wrong')]:
        table = original.copy()
        table.loc[0, field] = value
        table.to_csv(path, index=False)
        with pytest.raises(ValueError, match='checksum'):
            load_citation_topic_partition(tmp_path, corpus)
        manifest['assignments_sha256'] = file_hash(path)
        write_json(tmp_path / 'partition_manifest.json', manifest)
        with pytest.raises(ValueError):
            load_citation_topic_partition(tmp_path, corpus)
        # Restore manifest for next independent tamper case.
        manifest = save(tmp_path, corpus)


@pytest.mark.parametrize('labels', [[1, 1, 1, 2, 2, 2, 2], [0, 1, 1, 2, 2, 2, 0],
                                   [1, 1, 1, 3, 3, 3, 0], [1, 1, 1]])
def test_isolates_and_original_consecutive_ids_required(tmp_path, corpus, labels):
    with pytest.raises(ValueError):
        save(tmp_path, corpus, np.array(labels))


def test_missing_export_and_stale_fit_fail_without_fallback(tmp_path, corpus):
    with pytest.raises(FileNotFoundError, match='no reclustering'):
        load_citation_topic_partition(tmp_path, corpus)
    with pytest.raises(ValueError, match='Stale'):
        save_citation_topic_partition(tmp_path, corpus, np.array([1, 1, 1, 2, 2, 2, 0]),
            resolution=1, seed=43, fit_input_id='old', source_evidence={})


def evidence(corpus):
    labels = np.array([1, 1, 1, 2, 2, 2, 0])
    vocabulary = build_vocabulary(corpus['papers'].loc[labels > 0], min_df=2, max_df=.9)
    terms = topic_terms(vocabulary, labels[labels > 0])
    profiles, membership, examples = describe_citation_topics(corpus, labels, terms)
    for frame in (profiles, membership, examples, terms):
        frame.insert(0, 'solution', 'citation_r1')
    return profiles, membership, examples, terms, vocabulary


def test_graph_representatives_boundaries_offsets_and_isolate_exclusion(corpus):
    profiles, membership, examples, terms, vocabulary = evidence(corpus)
    assert profiles.papers.tolist() == [3, 3]
    assert len(membership) == 7 and membership.cluster.tolist()[-1] == 0
    assert 'zebra' not in vocabulary['terms'] and set(terms.inside_n + terms.outside_n) == {6}
    assert set(examples.loc[examples.selection.str.contains('boundary'), 'paper_id']) == {'P2', 'P3'}
    for _, row in examples.iterrows():
        index = corpus['papers'].paper_id.tolist().index(row.paper_id)
        text = corpus['passages'].iloc[index].text
        assert row.excerpt == text[row.excerpt_start:row.excerpt_end]
        assert row.page == 2 and row.source_start == 4
    # c has the most incoming citations among its equally internally connected peers.
    assert profiles.iloc[0].representatives.splitlines()[0].startswith('P2:')
    again = evidence(corpus)[2]
    pd.testing.assert_frame_equal(examples, again)


def test_changed_text_rejects_old_name_and_disconnected_groups_have_no_boundary(tmp_path, corpus):
    # Remove the inter-community link while preserving all nonisolated vertices.
    edges = pd.DataFrame([('a', 'b'), ('a', 'c'), ('b', 'c'), ('d', 'e'), ('e', 'f'), ('f', 'd')],
                         columns=['source_key', 'target_key'])
    corpus['network'] = citation_network(corpus['nodes'], edges)
    profiles, _, examples, terms, _ = evidence(corpus)
    assert not examples.selection.str.contains('boundary').any()
    proposals = profiles[['solution', 'cluster', 'membership_id']].assign(proposed_label='Old name', status='Proposed')
    corpus['papers'].loc[0, 'text_sha256'] = 'changed'
    changed, _, examples, terms, _ = evidence(corpus)
    result = write_citation_review_cards(changed, terms, examples, proposals, tmp_path / 'cards.md')
    assert result.proposal_matched.tolist() == [False, True]
    assert result.proposed_label.iloc[0] == 'Name pending review'
    assert 'No external citation links.' in (tmp_path / 'cards.md').read_text()


def test_historical_adoption_requires_authenticated_labels_and_selected_seed(tmp_path, corpus):
    source = tmp_path / 'resolution_1'
    comparison = source / 'leiden_1'
    comparison.mkdir(parents=True)
    labels = [1, 1, 1, 2, 2, 2, 0]
    table = corpus['nodes'][['Key', 'paper_id']].assign(citation_label=labels)
    table.to_csv(source / 'work_membership.csv', index=False)
    coordinates = comparison / 'umap_coordinates_and_labels.csv'
    table.assign(**{'Citation community': [f'C{c}' if c else 'Unassigned (no links)' for c in labels]}).to_csv(coordinates, index=False)
    runs = table.assign(resolution=1., seed=43)
    runs.to_csv(tmp_path / 'all_seed_memberships.csv', index=False)
    corpus['input_hashes']['embeddings/manifest.json'] = 'embedding_hash'
    write_json(comparison / 'run_manifest.json', {
        'selection_id': 'scope', 'include_manual_citations': True,
        'graph_files': {'nodes.csv': 'hash'}, 'embedding_manifest_sha256': 'embedding_hash',
        'coordinates_and_labels_sha256': file_hash(coordinates), 'citation_resolution': 1.,
        'citation_selected_seed': 43, 'versions': {}})
    destination = tmp_path / 'snapshot'
    manifest = import_existing_citation_partition(destination, corpus, source, comparison)
    assert manifest['seed'] == 43 and manifest['communities'] == 2
    runs.loc[0, 'citation_label'] = 2
    runs.to_csv(tmp_path / 'all_seed_memberships.csv', index=False)
    with pytest.raises(ValueError, match='selected citation seed'):
        import_existing_citation_partition(destination, corpus, source, comparison)
