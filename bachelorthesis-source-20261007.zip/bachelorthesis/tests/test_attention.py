"""Tiny random CPU tensors: verify the adapter without loading a model."""
from types import SimpleNamespace
import pytest

torch = pytest.importorskip("torch")
from batill.attention import repeated_kv_sdpa


@pytest.mark.parametrize("mask_kind", ["causal", "padding", "bidirectional"])
def test_repeated_attention_matches_explicit_reference(mask_kind):
    generator = torch.Generator().manual_seed(71)
    query = torch.randn(2, 8, 7, 4, generator=generator, dtype=torch.float64)
    key = torch.randn(2, 2, 7, 4, generator=generator, dtype=torch.float64)
    value = torch.randn(2, 2, 7, 4, generator=generator, dtype=torch.float64)
    allowed = torch.ones(2, 1, 7, 7, dtype=torch.bool)
    if mask_kind != "bidirectional":
        allowed = allowed.tril()
    if mask_kind == "padding":
        allowed[:, :, :, -1] = False
    mask = allowed if mask_kind == "padding" else None
    causal = mask_kind != "bidirectional"
    output, weights = repeated_kv_sdpa(SimpleNamespace(is_causal=causal), query, key, value, mask, scaling=0.3)
    repeated_key = key[:, :, None].expand(2, 2, 4, 7, 4).reshape(2, 8, 7, 4)
    repeated_value = value[:, :, None].expand(2, 2, 4, 7, 4).reshape(2, 8, 7, 4)
    scores = (query @ repeated_key.transpose(-2, -1)) * 0.3
    reference = (scores.masked_fill(~allowed, float('-inf')).softmax(-1) @ repeated_value).transpose(1, 2)
    torch.testing.assert_close(output, reference, rtol=1e-10, atol=1e-10)
    assert weights is None


def test_transformers_registers_causal_mask_with_adapter():
    pytest.importorskip("transformers")
    from batill.attention import register_repeated_kv_attention
    from transformers import AttentionInterface, AttentionMaskInterface
    from transformers.masking_utils import sdpa_mask
    register_repeated_kv_attention()
    assert AttentionInterface()["batill_sdpa_repeat_kv"] is repeated_kv_sdpa
    assert AttentionMaskInterface()["batill_sdpa_repeat_kv"] is sdpa_mask
