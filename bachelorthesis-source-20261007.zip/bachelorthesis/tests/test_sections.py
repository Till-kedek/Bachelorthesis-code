"""Section preparation tests with synthetic text and tokenizer only."""

from dataclasses import replace

from batill.embedding import EmbeddingConfig, prepare_inputs, embedding_config_dict
from batill.sections import group_sections


class Tokenizer:
    def encode(self, text, add_special_tokens=True):
        return list(text) + [0]


def block(text, kind='Text', level=1):
    return {'id': text, 'text': text, 'type': kind, 'html': f'<h{level}>{text}</h{level}>',
            'section': [text], 'page': 1, 'include': True}


def paper():
    return {'title': 'Paper', 'source_filename': 'paper.pdf', 'pdf_sha256': 'test', 'blocks': [
        block('Paper', 'SectionHeader'), block('Abstract', 'SectionHeader', 4), block('Abstract prose'),
        block('1. Introduction', 'SectionHeader', 4), block('Intro prose'),
        block('2. Data', 'SectionHeader', 4), block('Data prose'),
        block('2.1. Sample', 'SectionHeader', 1), block('Sample prose'),
        block('3. Results', 'SectionHeader', 2), block('Results prose')]}


def test_short_papers_also_use_sections_and_subsections_stay_together():
    doc = paper()
    config = EmbeddingConfig(chunking='sections', max_tokens=2048, instruction='Topics')
    segments = prepare_inputs(doc, Tokenizer(), config)
    assert len(segments) == 3
    assert 'Abstract prose' in segments[0]['text'] and 'Intro prose' in segments[0]['text']
    assert 'Sample prose' in segments[1]['text'] and 'Results prose' not in segments[1]['text']
    assert [s['section_group'] for s in segments] == [0, 1, 2]
    assert all(s['text'].startswith('Instruct: Topics\nQuery: Title: Paper\n\n') for s in segments)
    assert len(prepare_inputs(doc, Tokenizer(), replace(config, chunking='adaptive'))) == 1


def test_oversized_sections_preserve_all_source_characters():
    doc = paper()
    doc['blocks'][6]['text'] = 'Long paragraph. ' * 100
    segments = prepare_inputs(doc, Tokenizer(), EmbeddingConfig(
        chunking='sections', max_tokens=256, instruction='Topics'))
    assert all(s['token_count'] <= 256 for s in segments)
    assert sum(s['section_group'] == 1 for s in segments) > 1
    for b in doc['blocks']:
        sources = [r for s in segments for r in s['sources'] if r['block_id'] == b['id']]
        assert ''.join(b['text'][r['start']:r['end']] for r in sources) == b['text']
    assert [r['block_id'] for s in segments for r in s['sources']][0] == 'Paper'


def test_unnumbered_and_missing_headings_are_flagged():
    blocks = [block('Introduction', 'SectionHeader'), block('Intro'),
              block('Data', 'SectionHeader'), block('Sample', 'SectionHeader', 2), block('Prose')]
    groups, flags = group_sections(blocks, 'Paper')
    assert len(groups) == 2 and len(groups[1]['blocks']) == 3
    assert 'unnumbered_heading_levels_need_review' in flags
    groups, flags = group_sections([block('Only prose')], 'Paper')
    assert len(groups) == 1 and 'no_section_boundaries_detected' in flags


def test_roman_sections_and_legacy_config_identity():
    blocks = [block('I. Introduction', 'SectionHeader'), block('Intro'),
              block('II. Data', 'SectionHeader'), block('Data')]
    assert len(group_sections(blocks, 'Paper')[0]) == 2
    assert 'chunking' not in embedding_config_dict(EmbeddingConfig())
    assert embedding_config_dict(EmbeddingConfig(chunking='sections'))['chunking'] == 'sections'
