"""Source boundaries, manual review, missingness, and immutable preparation."""
import json
import numpy as np
import pandas as pd
import pytest
from batill import selected_abstracts as sa
from batill.storage import file_hash


def block(text, kind='Text', page=1, number=0):
    return {'id': f'/page/{page-1}/{kind}/{number}', 'type': kind,
            'page': page, 'text': text, 'include': True}


def test_heading_is_only_a_candidate_and_toc_is_not_an_abstract():
    prose = 'We examine investor returns and financing decisions. ' * 8
    doc = {'blocks': [block('Abstract 5', 'TableOfContents'),
                     block('A B S T R A C T', 'SectionHeader', number=1),
                     block(prose, number=2), block('Author address', 'Footnote', number=3),
                     block('Keywords: financing', number=4), block('Introduction', number=5)]}
    result = sa.extract_abstract(doc)
    assert result['status'] == 'review'
    assert result['raw_abstract'] == prose
    assert 'abstract_boundary_requires_review' in result['flags']


def test_opening_narrative_never_becomes_a_ready_abstract():
    doc = {'blocks': [block('Private equity has grown in recent years. ' * 12),
                     block('Methods', 'SectionHeader', number=1)]}
    assert sa.extract_abstract(doc)['status'] == 'review'


def test_same_doi_validation_keeps_pdf_text_not_reference_text():
    pdf = 'We study PRIVATE equity financing and investor returns. ' * 10
    doc = {'blocks': [block('Abstract', 'SectionHeader'), block(pdf, number=1),
                     block('Keywords: returns', number=2)]}
    result = sa.match_pdf_abstract(doc, pdf.lower())
    assert result['status'] == 'ready' and result['match_score'] == 1
    assert result['raw_abstract'] == pdf
    assert sa.match_pdf_abstract(doc, 'Unrelated hospital patient results. ' * 40) is None


def test_source_spans_reject_overlap_wrong_page_and_out_of_bounds():
    doc = {'blocks': [block('exact text')]}
    valid = {'block_id': doc['blocks'][0]['id'], 'page': 1, 'start': 0, 'end': 5}
    assert sa.span_text(doc, [valid]) == 'exact'
    for invalid in ({**valid, 'end': 99}, {**valid, 'page': 2}, {**valid, 'start': -1}):
        with pytest.raises(ValueError, match='Invalid'):
            sa.span_text(doc, [invalid])
    with pytest.raises(ValueError, match='Overlapping'):
        sa.span_text(doc, [valid, valid])


@pytest.fixture
def preparation_inputs(tmp_path, monkeypatch):
    doc = {'blocks': [block('Actual title', 'SectionHeader'),
                     block('We analyse financing and buyouts. ' * 12, number=1),
                     block('Methods', 'SectionHeader', number=2)]}
    path = tmp_path / 'document.json'
    path.write_text(json.dumps(doc))
    papers = pd.DataFrame([{'paper_id':'P001', 'pdf_sha256':'pdf-hash', 'Key':'pdf-hash',
                           'title':'filename.pdf', 'doi':'10.1/example',
                           'reviewed_version_title':'Reviewed title'}])
    monkeypatch.setattr(sa, 'load_selected_documents', lambda root:
                        (papers, {'pdf-hash':(doc,path)}, None, {}, {}))
    monkeypatch.setattr(sa, '_cleaners', lambda root: (lambda text:text.strip(), lambda text:(text.strip(),'')))
    source = tmp_path / 'data/abstracts/abstracts_clean.csv'
    source.parent.mkdir(parents=True)
    pd.DataFrame(columns=['paper_id','doi','abstract']).to_csv(source,index=False)
    decision = {'document_sha256':file_hash(path),'reason':'Reviewed source boundaries',
                'action':'select_spans','spans':[sa._span(doc['blocks'][1])],
                'title_spans':[sa._span(doc['blocks'][0])]}
    return tmp_path, doc, decision


def test_review_preserves_pdf_identity_exact_input_and_missing_report(preparation_inputs):
    root,doc,decision=preparation_inputs
    ready,audit,provenance=sa.prepare_selected_abstracts(root,overrides={'pdf-hash':decision})
    assert ready.paper_id.tolist()==['P001'] and ready.Key.tolist()==['pdf-hash']
    assert ready.embedding_text.iloc[0]=='Actual title\n\n'+doc['blocks'][1]['text'].strip()
    assert ready.title_source.iloc[0]=='reviewed_pdf_spans'
    missing={**decision,'action':'no_abstract','spans':[]}
    ready,audit,provenance=sa.prepare_selected_abstracts(root,overrides={'pdf-hash':missing})
    assert ready.empty and audit.status.tolist()==['missing'] and provenance['missing_abstracts']==1
    folder,_=sa.save_preparation(root,ready,audit,provenance)
    assert pd.read_csv(folder/'missing_abstracts.csv').paper_id.tolist()==['P001']
    assert pd.read_csv(folder/'extraction_review_needed.csv').empty
    (folder/'missing_abstracts.csv').write_text('tampered')
    with pytest.raises(ValueError,match='changed unexpectedly'):
        sa.save_preparation(root,ready,audit,provenance)


def test_review_rejects_stale_and_unknown_documents(preparation_inputs):
    root,_,decision=preparation_inputs
    with pytest.raises(ValueError,match='Stale'):
        sa.prepare_selected_abstracts(root,overrides={'pdf-hash':{**decision,'document_sha256':'old'}})
    with pytest.raises(ValueError,match='unknown'):
        sa.prepare_selected_abstracts(root,overrides={'excluded-pdf':decision})


def test_damaged_abstract_stays_review_not_missing(preparation_inputs):
    root,_,decision=preparation_inputs
    ready,audit,provenance=sa.prepare_selected_abstracts(root,overrides={
        'pdf-hash':{**decision,'action':'needs_review','reason':'Scrambled extraction'}})
    assert ready.empty and audit.status.tolist()==['review']
    assert provenance['review_abstracts']==1 and provenance['missing_abstracts']==0


def install_supplement(root, kind='publisher_short_description'):
    from batill.storage import write_json
    origin=root/'publisher.txt';origin.write_text('Published short description.')
    path=root/'supplement.json'
    write_json(path,{'paper_id':'P001','pdf_sha256':'pdf-hash','source_kind':kind,
                     'source_url':'https://example.org/article','source_record_id':'10.1/example',
                     'doi':'10.1/example','retrieved_utc':'2026-10-06T00:00:00Z',
                     'abstract':origin.read_text(),'origin_path':'publisher.txt','origin_sha256':file_hash(origin)})
    write_json(root/'configs/selected_abstracts_supplements.json',{'pdf-hash':{
        'paper_id':'P001','source_kind':kind,'source_path':'supplement.json',
        'source_sha256':file_hash(path),'identity_review':'Exact publication reviewed; inclusion authorized.'}})
    return path


@pytest.mark.parametrize('kind', ['external_full_abstract','publisher_short_description'])
def test_approved_supplement_replaces_missing_pdf_and_retains_source(preparation_inputs,kind):
    root,_,decision=preparation_inputs
    install_supplement(root,kind)
    ready,audit,p=sa.prepare_selected_abstracts(root,overrides={
        'pdf-hash':{**decision,'action':'no_abstract','spans':[]}})
    assert ready.paper_id.tolist()==['P001']
    assert ready.abstract.iloc[0]=='Published short description.'
    assert ready.abstract_spans.iloc[0]=='[]'
    assert ready.abstract_source_kind.iloc[0]==kind
    assert bool(ready.is_short_description.iloc[0])==(kind=='publisher_short_description')
    assert p['missing_abstracts']==0
    folder,_=sa.save_preparation(root,ready,audit,p)
    assert len(pd.read_csv(folder/'supplementary_abstracts.csv'))==1


def test_supplement_rejects_changed_cached_record_and_origin(preparation_inputs):
    root,_,decision=preparation_inputs
    path=install_supplement(root);original=path.read_text()
    path.write_text(original+' ')
    with pytest.raises(ValueError,match='source checksum'):
        sa.prepare_selected_abstracts(root)
    path.write_text(original)
    (root/'publisher.txt').write_text('Different publication text')
    with pytest.raises(ValueError,match='original source checksum'):
        sa.prepare_selected_abstracts(root)


def test_supplement_rejects_wrong_doi(preparation_inputs):
    from batill.storage import read_json,write_json
    root,_,_=preparation_inputs
    path=install_supplement(root);record=read_json(path);record['doi']='10.1/other';write_json(path,record)
    config=root/'configs/selected_abstracts_supplements.json';spec=read_json(config)
    spec['pdf-hash']['source_sha256']=file_hash(path);write_json(config,spec)
    with pytest.raises(ValueError,match='DOI differs'):
        sa.prepare_selected_abstracts(root)
