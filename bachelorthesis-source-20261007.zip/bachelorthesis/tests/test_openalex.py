"""Offline tests for citation identity, direction, missingness and safe caching."""
import networkx as nx
import pandas as pd
import pytest
from scipy.sparse import load_npz
from batill.openalex import OpenAlexClient, resolve_works, export_graph


def work(identifier, doi, title, refs=()):
    return {'id': identifier, 'doi': doi, 'display_name': title, 'publication_year': 2020,
            'authorships': [], 'referenced_works': list(refs) if refs is not None else None}


class API:
    used_cache_files = set()
    network_requests = 0
    def __init__(self, works, found=()):
        self.works, self.found = works, found
    def by_dois(self, dois):
        return self.works
    def search(self, title):
        return list(self.found)


def papers():
    return pd.DataFrame([
        {'Key': 'a', 'paper_id': 'P001', 'query_title': 'Private Equity and Healthcare Quality',
         'query_year': '2020', 'doi': '10.1/a', 'approved_version_doi': ''},
        {'Key': 'b', 'paper_id': 'P002', 'query_title': 'Private Equity and Hospital Employment',
         'query_year': '2020', 'doi': '10.1/b', 'approved_version_doi': '10.1/b-version'},
        {'Key': 'c', 'paper_id': 'P003', 'query_title': 'An Unmatched Paper Without Identifiers',
         'query_year': '2020', 'doi': '', 'approved_version_doi': ''}])


def test_direction_versions_external_refs_and_coverage(tmp_path):
    p = papers()
    api = API({'10.1/a': work('WA', '10.1/a', p.iloc[0].query_title, ['WB-version', 'Outside', 'WA']),
               '10.1/b': work('WB', '10.1/b', p.iloc[1].query_title),
               '10.1/b-version': work('WB-version', '10.1/b-version', p.iloc[1].query_title, ['WA'])})
    m, works, aliases = resolve_works(api, p, tmp_path)
    nodes, edges, graph, summary = export_graph(m, works, aliases, tmp_path, {'selection_id': 'test'}, api)
    assert edges[['source_paper_id', 'target_paper_id']].values.tolist() == [['P001', 'P002']]
    assert summary['edges_using_version_alias'] == 1
    assert summary['approved_empty_reference_lists'] == 1
    assert summary['unapproved_pdfs'] == 1
    assert graph.number_of_nodes() == 3
    assert not graph.has_edge('b', 'a')  # alternate versions are not pooled
    assert load_npz(tmp_path / 'adjacency.npz').toarray().tolist() == [[0, 1, 0], [0, 0, 0], [0, 0, 0]]
    assert nx.read_graphml(tmp_path / 'citation_graph.graphml').has_edge('a', 'b')
    assert len(pd.read_csv(tmp_path / 'all_references.csv')) == 3


def test_duplicate_pdf_identities_are_held(tmp_path):
    p = papers().iloc[:2].copy()
    p.loc[1, ['doi', 'query_title']] = ['10.1/a', p.iloc[0].query_title]
    api = API({'10.1/a': work('WA', '10.1/a', p.iloc[0].query_title)})
    m, _, _ = resolve_works(api, p, tmp_path)
    assert not m.approved.any()
    assert m.match_status.eq('duplicate_work_identity_review_required').all()


def test_mismatched_doi_title_is_not_accepted(tmp_path):
    p = papers().iloc[:1]
    m, _, _ = resolve_works(API({'10.1/a': work('WA', '10.1/a', 'A Study of Astronomy')}), p, tmp_path)
    assert not m.approved.any()
    assert m.iloc[0].match_status == 'doi_title_needs_review'


def test_title_search_requires_year_and_no_competitor(tmp_path):
    p = papers().iloc[2:]
    exact = work('WC', '', p.iloc[0].query_title)
    api = API({}, [exact])
    m, _, _ = resolve_works(api, p, tmp_path)
    assert m.approved.all()
    exact['publication_year'] = 2019
    m, _, _ = resolve_works(api, p, tmp_path)
    assert not m.approved.any()
    exact['publication_year'] = 2020
    api.found = [exact, {**exact, 'id': 'OtherVersion'}]
    m, _, _ = resolve_works(api, p, tmp_path)
    assert not m.approved.any()


def test_null_references_are_missing_not_empty(tmp_path):
    p = papers().iloc[:1]
    api = API({'10.1/a': work('WA', '10.1/a', p.iloc[0].query_title, None)})
    m, works, aliases = resolve_works(api, p, tmp_path)
    _, _, _, s = export_graph(m, works, aliases, tmp_path, {'selection_id': 'test'}, api)
    assert s['approved_missing_reference_lists'] == 1
    assert s['approved_empty_reference_lists'] == 0


def test_cache_batches_and_no_persisted_credentials(tmp_path):
    class Session:
        def __init__(self):
            self.headers, self.calls = {}, 0
        def get(self, url, params, timeout):
            self.calls += 1
            return type('Response', (), {'status_code': 200, 'json': lambda _: {'meta': {'count': 0}, 'results': []}})()
    session = Session()
    api = OpenAlexClient(tmp_path, 'private-test-key', session=session)
    dois = [f'10.1234/{i}' for i in range(201)]
    api.by_dois(dois)
    api.by_dois(dois)
    assert session.calls == 3
    assert session.headers['Authorization'] == 'Bearer private-test-key'
    assert all('private-test-key' not in p.read_text() for p in tmp_path.glob('*.json'))


def test_429_stops_without_caching_error(tmp_path):
    class Session:
        headers = {}
        def get(self, *args, **kwargs):
            return type('Response', (), {'status_code': 429})()
    with pytest.raises(RuntimeError, match='HTTP 429'):
        OpenAlexClient(tmp_path, session=Session()).by_dois(['10.1/a'])
    assert not list(tmp_path.glob('*.json'))


def test_conflicting_alias_not_assigned(tmp_path):
    p = papers().iloc[:2]
    api = API({'10.1/a': work('WA', '10.1/a', p.iloc[0].query_title, ['Shared']),
               '10.1/b': work('WB', '10.1/b', p.iloc[1].query_title)})
    m, works, aliases = resolve_works(api, p, tmp_path)
    aliases = pd.concat([aliases, pd.DataFrame([{'Key': key, 'openalex_id': 'Shared', 'method': 'test'} for key in ['a', 'b']])])
    _, edges, _, _ = export_graph(m, works, aliases, tmp_path, {'selection_id': 'test'}, api)
    assert edges.empty
    assert len(pd.read_csv(tmp_path / 'ambiguous_aliases.csv')) == 2


def test_paginated_duplicate_provider_doi_is_held(tmp_path):
    class Session:
        headers = {}
        def get(self, url, params, timeout):
            item = work('WA' if 'page' not in params else 'WA2', '10.1/a', 'Same title')
            return type('Response', (), {'status_code': 200, 'json': lambda _: {'meta': {'count': 2}, 'results': [item]}})()
    api = OpenAlexClient(tmp_path, session=Session())
    assert api.by_dois(['10.1/a']) == {}
    assert api.ambiguous_dois == {'10.1/a'}
    assert api.network_requests == 2
