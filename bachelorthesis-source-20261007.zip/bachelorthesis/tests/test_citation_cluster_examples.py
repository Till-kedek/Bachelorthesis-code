"""Citation examples use graph links, retain isolates and preserve degree ties."""

import copy

import numpy as np
import pandas as pd
import pytest
from scipy.sparse import csr_matrix

from batill.citation_cluster_examples import representative_papers
from batill.pdf_cluster_examples import membership_id


@pytest.fixture
def reviewed_citation():
    papers = pd.DataFrame({'row': range(6), 'paper_id': list('abcdef'), 'title': list('ABCDEF'),
                           'pdf_sha256': list('ABCDEF'), 'text_sha256': list('123456'),
                           'source_filename': [f'{x}.pdf' for x in 'abcdef']})
    labels = np.array([1, 0, 1, 1, 2, 2])
    directed = csr_matrix((np.ones(5), ([0, 2, 3, 4, 0], [2, 3, 0, 5, 4])), shape=(6, 6))
    adjacency = directed.maximum(directed.T)
    members = pd.DataFrame({'paper_id': list('abcdef'), 'cluster': labels,
                            'citation_degree': [3, 0, 2, 2, 2, 1],
                            'within_community_degree': [2, 0, 2, 2, 1, 1],
                            'external_link_fraction': [1/3, 0, 0, 0, 1/2, 0]})
    assigned = papers.loc[labels > 0].copy().reset_index(drop=True)
    assigned['row'] = range(len(assigned))
    passages = pd.DataFrame([{'row': i, 'page': 1, 'block_id': 'block', 'segment': 1,
                             'text': f'Private equity evidence for {pid}.'}
                            for i, pid in enumerate(assigned.paper_id)])
    context = {'papers': papers, 'input_id': 'reviewed-graph',
               'network': {'adjacency': adjacency, 'directed': directed}}
    analysis = {'papers': assigned, 'labels': labels[labels > 0], 'passages': passages,
                'membership': members}
    settings = {'source': 'saved', 'saved': 'citation_r0.9', 'resolution': .9}
    review = {'solution': 'citation_r0.9', 'resolution': .9,
              'membership_id': membership_id(assigned, labels[labels > 0]),
              'full_membership_id': membership_id(papers, labels),
              'citation_input_id': context['input_id'], 'focus': {'1': 'health', '2': 'funds'},
              'papers': [{**row, 'cluster': int(labels[labels > 0][i]),
                          'evidence': [{'page': 1, 'block_id': 'block', 'segment': 1,
                                        'excerpt': passages.iloc[i].text}]}
                         for i, row in enumerate(assigned.to_dict('records')) if row['paper_id'] != 'd']}
    return context, analysis, settings, review


def test_graph_diagnostics_keep_isolates_and_ties_without_using_embeddings(reviewed_citation):
    selected, evidence, diagnostics = representative_papers(*reviewed_citation)
    assert selected.groupby('cluster').size().to_dict() == {1: 2, 2: 2}
    assert evidence.paper_id.tolist() == ['a', 'c', 'e', 'f']
    isolated = diagnostics.set_index('paper_id').loc['b']
    assert not isolated.assigned and not isolated.selected and pd.isna(isolated.internal_degree_rank)
    assert diagnostics.loc[diagnostics.assigned, 'internal_degree_rank'].eq(1).all()
    assert diagnostics.set_index('paper_id').loc['a', 'external_link_fraction'] == pytest.approx(1/3)


def test_changed_graph_cannot_reuse_review_even_when_memberships_are_equal(reviewed_citation):
    context, analysis, settings, review = copy.deepcopy(reviewed_citation)
    context['input_id'] = 'different-graph'
    with pytest.raises(ValueError, match='citation graph'):
        representative_papers(context, analysis, settings, review)
